/**
 * Niakofa Circles — LiveKit media-plane token issuance.
 *
 * This is the ONLY place the server touches the media plane. It never sees
 * audio/video bytes — it mints a short-lived, room-scoped LiveKit access
 * token and hands back the LiveKit server URL. The client then connects
 * directly to the LiveKit SFU with that token.
 *
 * Publish permission is derived the same way the room UI derives it —
 * `canPublishCircleMedia(role, media_publish_policy)` — so "open" Circles
 * let host/co-host/speaker/listener all publish camera+mic, and "moderated"
 * Circles restrict publish to host/co-host/speaker. This mirrors migration
 * 0109_circle_media_publish_policy.sql; if that policy ever diverges from
 * the mesh path's gating in audio-circle-room.tsx, tokens and UI would
 * disagree, so any change to canPublishCircleMedia must be made once in
 * circleMediaPolicy.ts and consumed from both places (already true here).
 *
 * Requires env: LIVEKIT_API_KEY, LIVEKIT_API_SECRET, LIVEKIT_URL
 * (the ws(s):// URL clients use to connect — see infra/livekit/livekit.yaml).
 */
import { Router } from "express";
import { AccessToken } from "livekit-server-sdk";
import {
  db,
  audioCircleSessionsTable,
  audioCircleParticipantsTable,
} from "@workspace/db";
import { eq, and, isNull } from "drizzle-orm";
import { requireAuth, requireApproved } from "../middlewares/auth";
import { generalApiLimiter } from "../middlewares/rate-limit";
import { canPublishCircleMedia } from "../lib/circleMediaPolicy";
import { logger } from "../lib/logger";

const router = Router();

// Kept short: a leaked token should stop being useful quickly. The client
// re-requests a token on reconnect, so this does not need to outlive a
// single media session.
const TOKEN_TTL_SECONDS = 60 * 60 * 4; // 4 hours

function roomNameForSession(sessionId: number): string {
  // Namespaced so a stale/replayed token from another Niakofa environment
  // (e.g. staging) can never resolve to a real production room.
  return `niakofa-circle-${sessionId}`;
}

router.post(
  "/audio-circle-sessions/:id/media-token",
  requireAuth,
  requireApproved,
  generalApiLimiter,
  async (req, res) => {
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;
    const livekitUrl = process.env.LIVEKIT_URL;
    if (!apiKey || !apiSecret || !livekitUrl) {
      // Explicit 503, not a 500 — this is a deployment/config gap, not a bug.
      // Callers (selectMediaTransportKind / the room page) should fall back
      // to the mesh transport when they see this rather than retry-loop.
      return res.status(503).json({ error: "LiveKit is not configured on this environment" });
    }

    const sessionId = parseInt(String(req.params.id ?? ""), 10);
    if (isNaN(sessionId)) return res.status(400).json({ error: "Invalid id" });
    const userId = req.authenticatedUserId!;

    const [session] = await db
      .select()
      .from(audioCircleSessionsTable)
      .where(eq(audioCircleSessionsTable.id, sessionId))
      .limit(1);
    if (!session || session.status !== "live") {
      return res.status(404).json({ error: "Session not live" });
    }

    const [participant] = await db
      .select({ role: audioCircleParticipantsTable.role })
      .from(audioCircleParticipantsTable)
      .where(
        and(
          eq(audioCircleParticipantsTable.session_id, sessionId),
          eq(audioCircleParticipantsTable.user_id, userId),
          isNull(audioCircleParticipantsTable.left_at),
        ),
      )
      .limit(1);
    if (!participant) {
      // Mirrors the mesh path: you must already be a joined participant
      // (POST .../join) before you can pick up a media token.
      return res.status(403).json({ error: "Join the circle before requesting a media token" });
    }

    const canPublish = canPublishCircleMedia(
      participant.role as "host" | "co_host" | "speaker" | "listener",
      (session.media_publish_policy as "open" | "moderated") ?? "open",
    );

    const at = new AccessToken(apiKey, apiSecret, {
      identity: String(userId),
      ttl: TOKEN_TTL_SECONDS,
    });
    at.addGrant({
      room: roomNameForSession(sessionId),
      roomJoin: true,
      // Every active participant can always SEE and HEAR the room; only
      // canPublish gates whether their own mic/camera tracks go out. This
      // is the open-media policy enforced server-side, not just in the UI.
      canPublish,
      canPublishData: true, // reactions / active-speaker pings over LiveKit data channel
      canSubscribe: true,
    });

    let token: string;
    try {
      token = await at.toJwt();
    } catch (err) {
      logger.error({ err, sessionId, userId }, "circle-media-token: failed to mint LiveKit token");
      return res.status(500).json({ error: "Failed to mint media token" });
    }

    return res.json({
      media_url: livekitUrl,
      media_token: token,
      room_name: roomNameForSession(sessionId),
      can_publish: canPublish,
      expires_in: TOKEN_TTL_SECONDS,
    });
  },
);

export default router;
