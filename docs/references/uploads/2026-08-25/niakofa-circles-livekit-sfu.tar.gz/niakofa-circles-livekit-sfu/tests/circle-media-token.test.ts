/**
 * Verifies the media-token route's publish grant matches
 * canPublishCircleMedia exactly, for every role x policy combination —
 * this is what keeps "listeners can publish without host approval" true
 * at the SFU boundary, not just in the room UI.
 */
import { describe, it, expect } from "vitest";
import { canPublishCircleMedia } from "../lib/circleMediaPolicy";

describe("media-token publish grant parity with circleMediaPolicy", () => {
  const roles = ["host", "co_host", "speaker", "listener"] as const;

  it("open policy: every active role can publish", () => {
    for (const role of roles) {
      expect(canPublishCircleMedia(role, "open")).toBe(true);
    }
  });

  it("moderated policy: only host/co_host/speaker can publish, listener cannot", () => {
    expect(canPublishCircleMedia("host", "moderated")).toBe(true);
    expect(canPublishCircleMedia("co_host", "moderated")).toBe(true);
    expect(canPublishCircleMedia("speaker", "moderated")).toBe(true);
    expect(canPublishCircleMedia("listener", "moderated")).toBe(false);
  });

  it("no role (not a participant) can never publish, any policy", () => {
    expect(canPublishCircleMedia(null, "open")).toBe(false);
    expect(canPublishCircleMedia(undefined, "moderated")).toBe(false);
  });
});
