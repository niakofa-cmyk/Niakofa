/**
 * Regression contract for the LiveKit transport. The core promise under
 * test: publishing/unpublishing a camera track never republishes,
 * reacquires, or otherwise touches the mic track. This is the exact bug
 * class ("video starts -> audio crashes") this transport exists to close
 * off structurally.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// The app's real test suite runs under jsdom (see vitest.config.ts), which
// provides MediaStream natively. This lightweight polyfill only exists so
// this file can also run under plain Node for a quick sanity check.
if (typeof (globalThis as any).MediaStream === "undefined") {
  (globalThis as any).MediaStream = class {
    private tracks: any[];
    constructor(tracks: any[] = []) { this.tracks = [...tracks]; }
    addTrack(t: any) { this.tracks.push(t); }
    removeTrack(t: any) { this.tracks = this.tracks.filter((x) => x !== t); }
    getTracks() { return this.tracks; }
  };
}

const publishTrack = vi.fn().mockResolvedValue(undefined);
const unpublishTrack = vi.fn();
const setMicrophoneEnabled = vi.fn().mockResolvedValue(undefined);
const getTrackPublication = vi.fn().mockReturnValue({ track: {} });

const fakeMicTrack = { mediaStreamTrack: { kind: "audio" }, stop: vi.fn() };
const fakeCamTrack = { mediaStreamTrack: { kind: "video" }, stop: vi.fn() };

vi.mock("livekit-client", () => {
  class RoomMock {
    on = vi.fn().mockReturnThis();
    connect = vi.fn().mockResolvedValue(undefined);
    disconnect = vi.fn();
    localParticipant = {
      publishTrack,
      unpublishTrack,
      setMicrophoneEnabled,
      getTrackPublication,
    };
  }
  return {
    Room: RoomMock,
    RoomEvent: {
      ConnectionStateChanged: "connectionStateChanged",
      Reconnecting: "reconnecting",
      Reconnected: "reconnected",
      Disconnected: "disconnected",
      TrackSubscribed: "trackSubscribed",
      TrackUnsubscribed: "trackUnsubscribed",
      ParticipantDisconnected: "participantDisconnected",
    },
    ConnectionState: { Connected: "connected", Connecting: "connecting", Reconnecting: "reconnecting", Disconnected: "disconnected" },
    Track: { Source: { Microphone: "microphone", Camera: "camera" } },
    createLocalTracks: vi.fn(async (opts: { audio?: boolean; video?: boolean }) => {
      if (opts.audio) return [fakeMicTrack];
      if (opts.video) return [fakeCamTrack];
      return [];
    }),
  };
});

import { LiveKitCircleTransport } from "../lib/livekitCircleTransport";

describe("LiveKitCircleTransport", () => {
  beforeEach(() => {
    publishTrack.mockClear();
    unpublishTrack.mockClear();
    setMicrophoneEnabled.mockClear();
    getTrackPublication.mockClear();
  });

  it("publishes mic once, then camera separately, without re-publishing mic", async () => {
    const transport = new LiveKitCircleTransport();
    await transport.join(
      { circleSessionId: 1, selfUserId: 1, mediaUrl: "wss://example", mediaToken: "tok", videoEnabled: false },
      {},
    );

    await transport.publishLocalMedia({ video: false });
    expect(publishTrack).toHaveBeenCalledTimes(1);
    expect(publishTrack).toHaveBeenCalledWith(fakeMicTrack, { source: "microphone" });

    // Enabling camera afterwards must add exactly one more publish call
    // (the camera) and must NOT call publishTrack for the mic again.
    await transport.addVideoTrack();
    expect(publishTrack).toHaveBeenCalledTimes(2);
    expect(publishTrack).toHaveBeenLastCalledWith(fakeCamTrack, { source: "camera" });
  });

  it("stopping the camera does not touch the mic publication", async () => {
    const transport = new LiveKitCircleTransport();
    await transport.join(
      { circleSessionId: 1, selfUserId: 1, mediaUrl: "wss://example", mediaToken: "tok", videoEnabled: true },
      {},
    );
    await transport.publishLocalMedia({ video: true });
    transport.stopVideoTracks();

    expect(unpublishTrack).toHaveBeenCalledTimes(1);
    expect(unpublishTrack).toHaveBeenCalledWith(fakeCamTrack, true);
    expect(setMicrophoneEnabled).not.toHaveBeenCalled();
    // Mic was only ever published once, at the start.
    expect(publishTrack.mock.calls.filter((c) => c[1]?.source === "microphone")).toHaveLength(1);
  });

  it("throws a clear error when joined without a media token", async () => {
    const transport = new LiveKitCircleTransport();
    await expect(
      transport.join({ circleSessionId: 1, selfUserId: 1, videoEnabled: false }, {}),
    ).rejects.toThrow(/media URL and token/);
  });
});
