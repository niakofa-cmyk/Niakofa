import {
  Room,
  RoomEvent,
  Track,
  ConnectionState,
  createLocalTracks,
  type LocalTrack,
  type RemoteParticipant,
  type RemoteTrack,
  type RemoteTrackPublication,
} from "livekit-client";
import type {
  CircleMediaTransport,
  JoinMediaSessionOptions,
  MediaConnectionState,
  MediaTransportCallbacks,
} from "./circleMediaTransport";

/**
 * Production SFU transport for Niakofa Circles.
 *
 * This is what actually removes the "video crashes audio" failure mode,
 * structurally rather than by patching around it: mic and camera are two
 * independent LiveKit track publications. Publishing, unpublishing, or
 * losing the camera track never touches the audio track's publication,
 * its RTP sender, or triggers renegotiation of the audio transceiver —
 * because with an SFU there is exactly one PeerConnection between this
 * client and the LiveKit server, and LiveKit's client SDK manages
 * per-track renegotiation internally instead of the app hand-rolling
 * perfect-negotiation across N mesh peer connections.
 *
 * The room stays the control plane (Niakofa REST/WS: roles, moderation,
 * who's allowed to publish). This class is only ever handed a room-scoped
 * token by the server — see routes/circle-media-token.ts — and never
 * decides publish policy itself beyond what that token already grants.
 */
export class LiveKitCircleTransport implements CircleMediaTransport {
  readonly kind = "livekit" as const;

  private room: Room | null = null;
  private callbacks: MediaTransportCallbacks = {};
  private state: MediaConnectionState = "idle";
  private micTrack: LocalTrack | null = null;
  private camTrack: LocalTrack | null = null;
  private remoteStreams = new Map<string, MediaStream>();

  private setState(state: MediaConnectionState) {
    this.state = state;
    this.callbacks.onConnectionStateChange?.(state);
  }

  async join(opts: JoinMediaSessionOptions, callbacks: MediaTransportCallbacks): Promise<void> {
    this.callbacks = callbacks;
    if (!opts.mediaUrl || !opts.mediaToken) {
      throw new Error("LiveKit requires a short-lived media URL and token (call /media-token first).");
    }

    const room = new Room({
      adaptiveStream: true,
      dynacast: true,
      // Keep default video quality low-to-moderate for a many-tile Circle;
      // simulcast lets LiveKit downgrade per-subscriber automatically.
      publishDefaults: { simulcast: true, dtx: true },
    });
    this.room = room;

    room.on(RoomEvent.ConnectionStateChanged, (s: ConnectionState) => {
      const mapped: MediaConnectionState =
        s === ConnectionState.Connected ? "connected" :
        s === ConnectionState.Connecting ? "connecting" :
        s === ConnectionState.Reconnecting ? "reconnecting" :
        s === ConnectionState.Disconnected ? "lost" : "connecting";
      this.setState(mapped);
    });

    room.on(RoomEvent.Reconnecting, () => this.setState("reconnecting"));
    room.on(RoomEvent.Reconnected, () => this.setState("connected"));
    room.on(RoomEvent.Disconnected, () => this.setState("ended"));

    room.on(
      RoomEvent.TrackSubscribed,
      (track: RemoteTrack, _pub: RemoteTrackPublication, participant: RemoteParticipant) => {
        const userId = participant.identity;
        let stream = this.remoteStreams.get(userId);
        if (!stream) {
          stream = new MediaStream();
          this.remoteStreams.set(userId, stream);
        }
        stream.addTrack(track.mediaStreamTrack);
        // Re-emit so the UI always sees the up-to-date combined stream for
        // this participant, whether this event was their mic or camera.
        callbacks.onRemoteStream?.(userId, stream);
      },
    );

    room.on(
      RoomEvent.TrackUnsubscribed,
      (track: RemoteTrack, _pub: RemoteTrackPublication, participant: RemoteParticipant) => {
        const userId = participant.identity;
        const stream = this.remoteStreams.get(userId);
        stream?.removeTrack(track.mediaStreamTrack);
        // Only tell the UI the participant's stream fully ended once they
        // have no tracks left at all (camera-off must not look like they
        // left the call while their mic is still live).
        if (stream && stream.getTracks().length === 0) {
          this.remoteStreams.delete(userId);
          callbacks.onRemoteStreamEnded?.(userId);
        }
      },
    );

    room.on(RoomEvent.ParticipantDisconnected, (participant: RemoteParticipant) => {
      this.remoteStreams.delete(participant.identity);
      callbacks.onRemoteStreamEnded?.(participant.identity);
    });

    this.setState("connecting");
    await room.connect(opts.mediaUrl, opts.mediaToken, { autoSubscribe: true });
    this.setState("connected");
  }

  /**
   * Publishes mic (+ optionally camera) as independent tracks. Calling this
   * again with `video: true` after audio is already published only adds a
   * camera track — it does NOT reacquire or republish the microphone.
   */
  async publishLocalMedia(opts: { video: boolean }): Promise<MediaStream> {
    const room = this.room;
    if (!room) throw new Error("LiveKit transport not joined");

    if (!this.micTrack) {
      const [mic] = await createLocalTracks({ audio: true, video: false });
      this.micTrack = mic;
      await room.localParticipant.publishTrack(mic, { source: Track.Source.Microphone });
    }

    if (opts.video && !this.camTrack) {
      await this.addVideoTrack();
    }

    const stream = new MediaStream(
      [this.micTrack, this.camTrack].filter((t): t is LocalTrack => !!t).map((t) => t.mediaStreamTrack),
    );
    this.callbacks.onLocalStream?.(stream);
    return stream;
  }

  /**
   * Camera-only acquisition and publish. This is the operation that used
   * to destabilize the mesh's audio transceiver — here it is provably
   * independent: getUserMedia only requests video, and publishTrack adds
   * a brand-new LiveKit track publication that shares nothing with the
   * mic's publication or its underlying RTCRtpSender.
   */
  async addVideoTrack(): Promise<MediaStream> {
    const room = this.room;
    if (!room) throw new Error("LiveKit transport not joined");
    if (this.camTrack) {
      const stream = new MediaStream(
        [this.micTrack, this.camTrack].filter((t): t is LocalTrack => !!t).map((t) => t.mediaStreamTrack),
      );
      return stream;
    }
    const [cam] = await createLocalTracks({ audio: false, video: true });
    this.camTrack = cam;
    await room.localParticipant.publishTrack(cam, { source: Track.Source.Camera });
    const stream = new MediaStream(
      [this.micTrack, this.camTrack].filter((t): t is LocalTrack => !!t).map((t) => t.mediaStreamTrack),
    );
    this.callbacks.onLocalStream?.(stream);
    return stream;
  }

  stopVideoTracks(): void {
    const room = this.room;
    if (!room || !this.camTrack) return;
    const pub = room.localParticipant.getTrackPublication(Track.Source.Camera);
    if (pub) room.localParticipant.unpublishTrack(this.camTrack, true);
    this.camTrack.stop();
    this.camTrack = null;
    const stream = new MediaStream(this.micTrack ? [this.micTrack.mediaStreamTrack] : []);
    this.callbacks.onLocalStream?.(stream);
  }

  setMicEnabled(enabled: boolean): void {
    this.room?.localParticipant.setMicrophoneEnabled(enabled).catch(() => {});
  }

  setVideoEnabled(enabled: boolean): void {
    if (enabled) {
      this.addVideoTrack().catch((err) => {
        // Camera failure must not touch the mic publication — surface the
        // error to the UI and leave audio exactly as it was.
        this.callbacks.onConnectionStateChange?.(this.state);
        throw err;
      });
    } else {
      this.stopVideoTracks();
    }
  }

  getConnectionState(): MediaConnectionState {
    return this.state;
  }

  getLocalStream(): MediaStream | null {
    const tracks = [this.micTrack, this.camTrack].filter((t): t is LocalTrack => !!t);
    return tracks.length ? new MediaStream(tracks.map((t) => t.mediaStreamTrack)) : null;
  }

  destroy(): void {
    this.micTrack?.stop();
    this.camTrack?.stop();
    this.micTrack = null;
    this.camTrack = null;
    this.remoteStreams.clear();
    this.room?.disconnect();
    this.room = null;
    this.setState("ended");
  }
}
