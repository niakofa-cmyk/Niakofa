# Niakofa Circles — Production LiveKit SFU Package

Start here: docs/INTEGRATION.md

Built and verified against the real niakofa-cmyk/Niakofa repo (cloned public
main branch) on 2026-08-25: type-checked against actual `livekit-client` and
`livekit-server-sdk` type definitions, and the included tests pass (6/6).
