# Niakofa Circles — LiveKit SFU Integration

## What's in this package
```
lib/livekitCircleTransport.ts      Real LiveKit client transport (was a stub — see below)
routes/circle-media-token.ts       Server-side LiveKit token minting (new route)
infra/livekit/livekit.yaml         Self-hosted LiveKit config
infra/livekit/docker-compose.yml   Self-hosted LiveKit deployment
tests/livekitCircleTransport.contract.test.ts   Proves audio/video track independence
tests/circle-media-token.test.ts                Proves publish-grant policy parity
```

## What was already true in the repo before this package
Worth being precise about, since some of this may already match claims from
an earlier package you were sent:
- `artifacts/pay-it-forward/src/lib/audioCircleWebRTC.ts` already has the
  mesh hardening (perfect-negotiation, `replaceTrack`, ICE-before-SDP
  handling). The "video crashes audio" mesh bug is already patched there.
- `artifacts/pay-it-forward/src/pages/audio-circle-room.tsx` already gates
  the camera button with `canPublishCircleMedia(me?.role, session?.media_publish_policy ?? "open")`
  (line ~656, ~3539) — **listeners can already turn on camera without host
  approval today**, on the default `open` policy from migration
  `0109_circle_media_publish_policy.sql`.
- `circleMediaTransport.ts` / `meshCircleTransport.ts` define a clean
  `CircleMediaTransport` seam so the room UI doesn't need to know whether
  it's talking to the mesh or an SFU.
- `livekitCircleTransport.ts` existed but was an intentional 24-line stub
  that throws `"LiveKit transport is not configured"` — this package
  replaces it with a real implementation.

So the one thing genuinely missing for a production SFU was: a working
LiveKit client transport, and a server-side token route. Both are now in
this package and pass their tests (see below).

## Steps

### 1. Install dependencies
```bash
cd artifacts/pay-it-forward && npm install livekit-client
cd ../api-server && npm install livekit-server-sdk
```

### 2. Copy files
```
lib/livekitCircleTransport.ts   -> artifacts/pay-it-forward/src/lib/livekitCircleTransport.ts   (overwrite the stub)
routes/circle-media-token.ts    -> artifacts/api-server/src/routes/circle-media-token.ts          (new file)
tests/*                         -> alongside their respective existing test folders
```

### 3. Register the new route
In `artifacts/api-server/src/routes/index.ts`, next to the existing
`audioCirclesRouter` / `circleHeartbeatRouter` registration:
```ts
import circleMediaTokenRouter from "./circle-media-token";
// ...
router.use(circleMediaTokenRouter);
```

### 4. Set environment variables
LiveKit Cloud (fastest path — no infra to run):
```
LIVEKIT_URL=wss://your-project.livekit.cloud
LIVEKIT_API_KEY=...
LIVEKIT_API_SECRET=...
```
Self-hosted: `docker compose -f infra/livekit/docker-compose.yml up -d`,
then point `LIVEKIT_URL` at `wss://your-domain:7880`.

If these env vars are unset, `/audio-circle-sessions/:id/media-token`
returns `503`. `selectMediaTransportKind()` in `circleMediaTransport.ts`
already exists for choosing mesh vs. LiveKit — treat a `503` from this
route the same way: fall back to the mesh transport rather than failing
the join.

### 5. Wire the room page to request a token and use the transport seam
`audio-circle-room.tsx` currently instantiates `AudioCircleMesh` directly
(`meshRef`, line ~829) rather than going through `MeshCircleTransport`/
`LiveKitCircleTransport`. This is a real 4,500-line production file with
its own device-picker, recording, and moderation logic built around
`meshRef.current`, so we did not rewrite it blind in this package —
that's exactly the kind of change that should go through your own PR
review with real two-device testing, not an unreviewed autonomous diff.
Concretely, the swap is:

```ts
// where meshRef is currently created directly:
const kind = selectMediaTransportKind({
  expectedSpeakers: ..., expectedListeners: ...,
});
const transport: CircleMediaTransport =
  kind === "livekit"
    ? new LiveKitCircleTransport()
    : new MeshCircleTransport((args) => new AudioCircleMesh(args));

if (kind === "livekit") {
  const { media_url, media_token } = await fetch(
    `${base}/audio-circle-sessions/${sessionId}/media-token`,
    { headers: { Authorization: `Bearer ${authToken}` } },
  ).then(r => r.json());
  await transport.join({ circleSessionId: sessionId, selfUserId: myUserId, mediaUrl: media_url, mediaToken: media_token, videoEnabled: wantsVideo }, callbacks);
} else {
  await transport.join({ circleSessionId: sessionId, selfUserId: myUserId, videoEnabled: wantsVideo, iceServers, subscribeToSignal }, callbacks);
}
// replace meshRef.current.X calls with transport.X — the interface is a 1:1 match
// (publishLocalMedia, addVideoTrack, setMicEnabled, setVideoEnabled, destroy, etc.)
```
Everywhere the file does `meshRef.current?.setMicEnabled(...)`,
`meshRef.current.addVideoTrack()`, etc. becomes `transportRef.current?.setMicEnabled(...)`
unchanged — that's the point of the seam already in the repo.

## Manual test matrix (run on two real devices before shipping)
1. Host joins, audio connects.
2. Host enables camera — audio must stay connected, participant sees video.
3. Listener (no host approval) enables camera — host and other listeners see it, audio stays up.
4. Host turns camera off — audio continues.
5. Deny camera permission — audio continues, UI shows "camera unavailable."
6. One participant on cellular data, one on Wi-Fi — verify TURN relay works.

## Automated tests included
```bash
npx vitest run livekitCircleTransport.contract.test.ts circle-media-token.test.ts
```
Both pass against the real `livekit-client` / `livekit-server-sdk` type
definitions (verified while building this package: 3/3 and 3/3 tests
green, plus a clean `tsc --noEmit` on both new source files).
