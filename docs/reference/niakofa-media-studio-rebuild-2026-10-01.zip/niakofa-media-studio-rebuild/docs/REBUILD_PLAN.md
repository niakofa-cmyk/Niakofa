# Niakofa Media Studio / Moments Rebuild

## Product pathway

`Create a Spark` is now a direct creation doorway:

`Create a Spark → full-screen live camera → capture/record → edit → effects → text/stickers/music/templates → audience → Share Spark`

There is no intermediate "Choose how to start" page.

## Reference ZIP patterns incorporated

The supplied Compose/Snapchat clone was inspected as a donor-pattern reference. Useful patterns adapted for Niakofa include:

- full-screen camera-first creation
- camera flip
- torch/flash affordance
- circular shutter
- vertical immersive video viewing
- bottom action rail
- creator identity overlay
- dark media canvas
- Stories/Spotlight-style sequential playback
- photo/video capture as one creation surface

The donor app is not copied as a second application and its mock data/storage is not connected to Niakofa.

## Canonical Niakofa palette

The current Niakofa root already defines the cyan-on-navy system:

- cyan `#00cfff`
- navy `#08182b`
- light ink `#edf8ff`
- muted `#9bb0c3`
- coral `#f17862`
- gold `#e7b650`

This package makes the Media Studio explicitly consume that language. Purple is reserved for creative/effect accents.

## Family Story rule

The current repository's Family Vault supports media assets, but the existing `KeepForMyFamilyDialog` intentionally preserves only caption text from a Moment. The rebuild therefore treats >60-second media as a **Family Story candidate** and exposes an explicit preservation choice. A production media-preservation endpoint must be added/certified before the actual video bytes are copied into Family Vault.

## Production safety

Do not enable a new media backend or silently change Moment retention. Reuse Niakofa's existing authorized media pipeline. Keep Community/Moment, Exchange Spark, and Family media authorization boundaries separate.
