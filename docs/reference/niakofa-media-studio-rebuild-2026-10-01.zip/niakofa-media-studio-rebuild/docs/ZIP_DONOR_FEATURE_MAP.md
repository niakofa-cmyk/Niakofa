# Supplied ZIP → Niakofa mapping

| Donor capability | Niakofa implementation direction |
|---|---|
| Camera-first screen | `NiakofaSparkStudio` full-screen camera |
| Front/back switch | Existing browser camera constraints + switch action |
| Flash/torch | Existing `getCapabilities().torch` path |
| Circular shutter | Studio shutter |
| Spotlight vertical playback | Existing Moments snap feed + immersive viewer |
| Creator footer/actions | Existing Moments author/action rail |
| Stories | Niakofa Moments/Sparks semantics, not copied Snapchat terminology |
| Memories | Niakofa Family Vault / Legacy semantics |
| Filters | Studio effect filters |
| Stickers | Studio sticker tool |
| Text | Studio text overlay |
| Music | Existing Niakofa music/right-attestation path |
| Templates | Existing Niakofa template system |
| Multiple clips | Existing six-item camera sequence |
| 60-second camera cap | Existing camera contract |
| Longer composed media | Family Story candidate, explicit preservation only |
