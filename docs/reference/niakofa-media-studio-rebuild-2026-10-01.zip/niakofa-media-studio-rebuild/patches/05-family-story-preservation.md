# Family Story preservation rule

A Spark/Moment remains an expiring Community object unless the user explicitly preserves it.

When the composed media duration is **greater than 60 seconds**, the Studio automatically presents:

> This Spark can become a Family Story.
>
> Save a private Family Story copy when you publish.

The UI should set `familyStoryCandidate=true` and let the user confirm `preserveAsFamilyStory=true`.

Important current-repo boundary: `KeepForMyFamilyDialog` currently preserves **caption text only**. It explicitly does not preserve Moment photo/video/audio bytes. Therefore the media-preserving Family Story action requires a new certified backend contract using the existing Family Memory asset upload/storage path. Do not fake this by copying an expiring Moment URL into Family Vault.
