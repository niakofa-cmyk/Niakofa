# Remove the old source/steps page

The existing `SparkComposerChrome` contains a `source` step titled **Choose how to start** with:

- Take a photo or video
- Choose photos or videos
- Start with words

For the canonical Create a Spark pathway, remove that intermediate screen. The entry sequence becomes:

`Create a Spark → live camera → capture/record → edit → effects/tools → audience/publish`

Gallery and text remain available as secondary creation actions inside the Studio. The camera should acquire its stream immediately when the Studio opens.

If a draft is being recovered, recover it first. If a durable Exchange draft is present, resume that listing-owned draft instead of silently creating a second draft.
