# Direct Create a Spark — current repo already has the camera doorway

The current `CommunityStoryRail.tsx` already contains an `autoCameraOpenedRef` effect. Once the Spark composer is opened and its scoped draft recovery completes, a new composer with no recovered work automatically calls:

```ts
setCameraOpen(true);
```

Therefore **do not add a second auto-camera effect**.

The remaining work is to remove the visible `SparkComposerChrome` `source` page from the canonical path so users do not see:

> Create a Spark → Choose how to start

The desired path is:

```text
Create a Spark
    ↓
full-screen live camera
    ↓
capture / record
    ↓
edit
    ↓
effects / text / stickers / music / templates
    ↓
audience
    ↓
Share Spark
```

Keep the existing draft-recovery gate and Exchange-owned draft guard. Do not auto-open a fresh camera over a recoverable draft.
