/**
 * Niakofa's Moment retention and Family Story preservation are different
 * domains. This helper only decides when the UI should offer preservation.
 * It deliberately does not silently extend an expiring Moment.
 */
export type FamilyStoryCandidate = {
  eligible: boolean;
  durationSeconds: number;
  reason: "over-moment-limit" | "not-over-limit";
};

export function familyStoryCandidateForDuration(durationSeconds: number, momentLimitSeconds = 60): FamilyStoryCandidate {
  const safe = Number.isFinite(durationSeconds) && durationSeconds >= 0 ? durationSeconds : 0;
  return {
    eligible: safe > momentLimitSeconds,
    durationSeconds: safe,
    reason: safe > momentLimitSeconds ? "over-moment-limit" : "not-over-limit",
  };
}

/**
 * Contract for the eventual server-backed preservation action.
 * The current repository's KeepForMyFamilyDialog preserves caption text only;
 * this adapter keeps the new Studio UI honest until the media-preservation
 * endpoint is enabled and certified.
 */
export type PreserveSparkAsFamilyStoryInput = {
  familyId: number;
  sourceMomentId: number;
  title: string;
  durationSeconds: number;
};
