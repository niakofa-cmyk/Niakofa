import {
  Camera,
  ChevronLeft,
  Clock3,
  FlipHorizontal,
  GalleryHorizontal,
  Heart,
  ImagePlus,
  Lightbulb,
  Music2,
  Pause,
  Play,
  RotateCcw,
  Send,
  Settings2,
  Sparkles,
  Sticker,
  SwitchCamera,
  TextCursorInput,
  TimerReset,
  WandSparkles,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import "./niakofa-spark-studio.css";

export type SparkStudioEffect = "none" | "cyan" | "warm" | "mono" | "vivid" | "dream";
export type SparkStudioTool = "effects" | "text" | "stickers" | "music" | "templates" | "timer";

export type SparkStudioPublishMeta = {
  effect: SparkStudioEffect;
  textOverlay: string;
  sticker: string | null;
  musicFile: File | null;
  template: string | null;
  durationSeconds: number;
  clipCount: number;
  familyStoryCandidate: boolean;
  preserveAsFamilyStory: boolean;
};

export type NiakofaSparkStudioProps = {
  open: boolean;
  onClose: () => void;
  onGallery: () => void;
  onPublish: (files: File[], meta: SparkStudioPublishMeta) => void | Promise<void>;
  maxSeconds?: number;
  maxClips?: number;
};

const EFFECTS: Array<{ id: SparkStudioEffect; label: string; className: string }> = [
  { id: "none", label: "Original", className: "" },
  { id: "cyan", label: "Cyan", className: "nk-effect-cyan" },
  { id: "warm", label: "Warm", className: "nk-effect-warm" },
  { id: "mono", label: "Mono", className: "nk-effect-mono" },
  { id: "vivid", label: "Vivid", className: "nk-effect-vivid" },
  { id: "dream", label: "Dream", className: "nk-effect-dream" },
];

const STICKERS = ["✨", "❤️", "💙", "🌍", "🤎", "🙌🏾", "📍", "🎥", "🔥", "🪶"];
const TEMPLATES = ["Today", "Family Moment", "Neighborhood", "Gratitude", "Travel", "Celebration"];

function stopStream(stream: MediaStream | null) {
  stream?.getTracks().forEach((track) => track.stop());
}

function supportedMime() {
  if (typeof MediaRecorder === "undefined") return "";
  return [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
    "video/mp4",
  ].find((type) => MediaRecorder.isTypeSupported(type)) ?? "";
}

function formatTime(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds));
  return `${String(Math.floor(safe / 60)).padStart(2, "0")}:${String(safe % 60).padStart(2, "0")}`;
}

async function readVideoDuration(file: File): Promise<number> {
  if (!file.type.startsWith("video/")) return 0;
  const url = URL.createObjectURL(file);
  try {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.src = url;
    return await new Promise<number>((resolve) => {
      const done = () => resolve(Number.isFinite(video.duration) ? video.duration : 0);
      video.onloadedmetadata = done;
      video.onerror = () => resolve(0);
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function NiakofaSparkStudio({
  open,
  onClose,
  onGallery,
  onPublish,
  maxSeconds = 60,
  maxClips = 6,
}: NiakofaSparkStudioProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startedAtRef = useRef(0);
  const recordedSecondsRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [phase, setPhase] = useState<"camera" | "recording" | "paused" | "editor">("camera");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [torch, setTorch] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [countdownEnabled, setCountdownEnabled] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [clips, setClips] = useState<File[]>([]);
  const [selectedClip, setSelectedClip] = useState(0);
  const [tool, setTool] = useState<SparkStudioTool | null>(null);
  const [effect, setEffect] = useState<SparkStudioEffect>("none");
  const [textOverlay, setTextOverlay] = useState("");
  const [sticker, setSticker] = useState<string | null>(null);
  const [template, setTemplate] = useState<string | null>(null);
  const [musicFile, setMusicFile] = useState<File | null>(null);
  const [durations, setDurations] = useState<number[]>([]);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState("");

  const recordedSeconds = Math.min(maxSeconds, recordedSecondsRef.current + elapsed);
  const totalDuration = useMemo(() => durations.reduce((sum, value) => sum + value, 0), [durations]);
  const familyStoryCandidate = totalDuration > maxSeconds;
  const remaining = Math.max(0, maxSeconds - recordedSeconds);
  const activeEffect = EFFECTS.find((item) => item.id === effect)?.className ?? "";

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const start = async () => {
      setError("");
      if (!navigator.mediaDevices?.getUserMedia) {
        setError("Live camera recording is not available in this browser. Choose media from your device.");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: facing }, width: { ideal: 1080 }, height: { ideal: 1920 } },
          audio: true,
        });
        if (cancelled) {
          stopStream(stream);
          return;
        }
        streamRef.current = stream;
        const track = stream.getVideoTracks()[0];
        const caps = track?.getCapabilities?.() as MediaTrackCapabilities & { torch?: boolean } | undefined;
        setTorchSupported(Boolean(caps?.torch));
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setPhase("camera");
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : "Camera access was not available.");
      }
    };
    void start();
    return () => {
      cancelled = true;
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
      if (recorderRef.current?.state !== "inactive") recorderRef.current?.stop();
      recorderRef.current = null;
      stopStream(streamRef.current);
      streamRef.current = null;
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    if (!clips.length) return;
    void Promise.all(clips.map(readVideoDuration)).then((values) => {
      setDurations(values.map((value, index) => value || (clips[index].type.startsWith("video/") ? 0 : 0)));
    });
  }, [clips, open]);

  const stopClock = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  };

  const beginRecorder = async () => {
    const stream = streamRef.current;
    if (!stream || typeof MediaRecorder === "undefined") return setError("Video recording is not supported here.");
    if (clips.length >= maxClips) return setError(`A Spark can contain up to ${maxClips} clips.`);
    if (recordedSecondsRef.current >= maxSeconds) return setError(`The ${maxSeconds}-second camera limit has been reached.`);
    const mimeType = supportedMime();
    if (!mimeType) return setError("This browser cannot create a supported video recording.");
    chunksRef.current = [];
    const recorder = new MediaRecorder(stream, { mimeType });
    recorderRef.current = recorder;
    recorder.ondataavailable = (event) => event.data.size && chunksRef.current.push(event.data);
    recorder.onerror = () => {
      stopClock();
      setPhase("camera");
      setError("Recording stopped because the camera reported an error.");
    };
    recorder.onstop = () => {
      stopClock();
      const seconds = Math.min(maxSeconds - recordedSecondsRef.current, elapsed);
      const blob = new Blob(chunksRef.current, { type: mimeType });
      if (!blob.size) {
        setPhase("camera");
        return setError("No video was captured. Try again.");
      }
      const extension = mimeType.includes("mp4") ? "mp4" : "webm";
      const file = new File([blob], `niakofa-spark-${Date.now()}.${extension}`, { type: mimeType.split(";")[0], lastModified: Date.now() });
      recordedSecondsRef.current = Math.min(maxSeconds, recordedSecondsRef.current + Math.max(0, seconds));
      setElapsed(0);
      setClips((current) => [...current, file]);
      setSelectedClip(clips.length);
      setPhase("editor");
    };
    startedAtRef.current = Date.now();
    recorder.start(200);
    setPhase("recording");
    timerRef.current = setInterval(() => {
      const next = Math.min(maxSeconds - recordedSecondsRef.current, (Date.now() - startedAtRef.current) / 1000);
      setElapsed(next);
      if (next >= maxSeconds - recordedSecondsRef.current) recorder.stop();
    }, 100);
  };

  const startRecording = () => {
    setError("");
    if (!countdownEnabled) {
      void beginRecorder();
      return;
    }
    let count = 3;
    setCountdown(count);
    const id = window.setInterval(() => {
      count -= 1;
      setCountdown(count);
      if (count <= 0) {
        window.clearInterval(id);
        setCountdown(0);
        void beginRecorder();
      }
    }, 1000);
  };

  const togglePause = () => {
    const recorder = recorderRef.current;
    if (!recorder) return;
    if (recorder.state === "recording") {
      const next = Math.min(maxSeconds - recordedSecondsRef.current, (Date.now() - startedAtRef.current) / 1000);
      setElapsed(next);
      recorder.pause();
      stopClock();
      setPhase("paused");
    } else if (recorder.state === "paused") {
      startedAtRef.current = Date.now();
      recorder.resume();
      setPhase("recording");
      timerRef.current = setInterval(() => {
        const next = Math.min(maxSeconds - recordedSecondsRef.current, (Date.now() - startedAtRef.current) / 1000 + elapsed);
        setElapsed(next);
        if (next >= maxSeconds - recordedSecondsRef.current) recorder.stop();
      }, 100);
    }
  };

  const capturePhoto = () => {
    const video = videoRef.current;
    if (!video?.videoWidth || !video.videoHeight || clips.length >= maxClips) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const photo = new File([blob], `niakofa-spark-${Date.now()}.jpg`, { type: "image/jpeg", lastModified: Date.now() });
      setClips((current) => [...current, photo]);
      setDurations((current) => [...current, 0]);
      setSelectedClip(clips.length);
      setPhase("editor");
    }, "image/jpeg", 0.92);
  };

  const switchCamera = async () => {
    const next = facing === "user" ? "environment" : "user";
    try {
      stopStream(streamRef.current);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { exact: next } }, audio: true });
      streamRef.current = stream;
      setFacing(next);
      const track = stream.getVideoTracks()[0];
      const caps = track?.getCapabilities?.() as MediaTrackCapabilities & { torch?: boolean } | undefined;
      setTorchSupported(Boolean(caps?.torch));
      setTorch(false);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => undefined);
      }
    } catch {
      setError("That camera could not be opened. The current camera remains active.");
    }
  };

  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track || !torchSupported) return;
    const next = !torch;
    try {
      await track.applyConstraints({ advanced: [{ torch: next } as MediaTrackConstraintSet] });
      setTorch(next);
    } catch {
      setTorch(false);
      setError("The torch is not available on this camera.");
    }
  };

  const chooseMusic = (event: React.ChangeEvent<HTMLInputElement>) => {
    setMusicFile(event.target.files?.[0] ?? null);
    event.target.value = "";
  };

  const publish = async () => {
    if (!clips.length || publishing) return;
    setPublishing(true);
    try {
      await onPublish(clips, {
        effect,
        textOverlay,
        sticker,
        musicFile,
        template,
        durationSeconds: totalDuration || recordedSeconds,
        clipCount: clips.length,
        familyStoryCandidate,
        preserveAsFamilyStory: familyStoryCandidate,
      });
    } finally {
      setPublishing(false);
    }
  };

  if (!open) return null;

  const selected = clips[selectedClip];
  const selectedUrl = useMemo(() => selected ? URL.createObjectURL(selected) : "", [selected]);
  useEffect(() => () => { if (selectedUrl) URL.revokeObjectURL(selectedUrl); }, [selectedUrl]);

  return (
    <div className="nk-spark-studio" role="dialog" aria-modal="true" aria-label="Create a Spark">
      <div className="nk-spark-studio__stage">
        {phase !== "editor" ? (
          <>
            <video ref={videoRef} muted playsInline className={`nk-spark-studio__live ${activeEffect}`} aria-label="Live Spark camera" />
            <div className="nk-spark-studio__live-shade" />
            <div className="nk-spark-studio__top">
              <button className="nk-studio-icon" onClick={onClose} aria-label="Close Spark studio"><X /></button>
              <div className="nk-studio-live-badge"><span /> LIVE CREATION</div>
              <div className="nk-spark-studio__top-actions">
                <button className={`nk-studio-icon ${torch ? "is-active" : ""}`} onClick={() => void toggleTorch()} disabled={!torchSupported} aria-label="Toggle torch"><Lightbulb /></button>
                <button className="nk-studio-icon" onClick={() => void switchCamera()} aria-label="Switch camera"><SwitchCamera /></button>
              </div>
            </div>
            <div className="nk-spark-studio__live-copy">
              <span>NI A KOFA • CREATE A SPARK</span>
              <strong>Share what is happening now.</strong>
            </div>
            {countdown > 0 && <div className="nk-spark-countdown" aria-live="assertive">{countdown}</div>}
            <div className="nk-spark-studio__camera-tools">
              <button onClick={onGallery} aria-label="Open gallery"><GalleryHorizontal /><span>Gallery</span></button>
              <button onClick={() => setCountdownEnabled((value) => !value)} className={countdownEnabled ? "is-active" : ""} aria-label="Toggle three second timer"><TimerReset /><span>Timer</span></button>
              <button className="nk-spark-shutter" onClick={phase === "recording" || phase === "paused" ? togglePause : capturePhoto} aria-label={phase === "recording" ? "Pause recording" : phase === "paused" ? "Resume recording" : "Capture photo"}>
                <span className={phase === "recording" ? "recording" : ""}>{phase === "recording" ? <Pause /> : phase === "paused" ? <Play /> : <Camera />}</span>
              </button>
              <button onClick={startRecording} disabled={phase === "recording" || phase === "paused" || remaining <= 0} aria-label="Record video"><span className="nk-record-dot" /><span>Video</span></button>
              <button onClick={() => setPhase("editor")} disabled={!clips.length} aria-label="Open Spark editor"><WandSparkles /><span>Edit</span></button>
            </div>
          </>
        ) : (
          <>
            <div className="nk-spark-editor-head">
              <button className="nk-studio-icon" onClick={() => setPhase("camera")} aria-label="Back to camera"><ChevronLeft /></button>
              <div><strong>Create a Spark</strong><small>{formatTime(totalDuration || recordedSeconds)} • {clips.length} clip{clips.length === 1 ? "" : "s"}</small></div>
              <button className="nk-studio-icon" onClick={onClose} aria-label="Close Spark studio"><X /></button>
            </div>
            <div className="nk-spark-editor-preview">
              {selected?.type.startsWith("video/") ? <video src={selectedUrl} controls playsInline className={`nk-spark-editor-media ${activeEffect}`} /> : selected ? <img src={selectedUrl} className={`nk-spark-editor-media ${activeEffect}`} alt="Spark preview" /> : <div className="nk-spark-editor-empty">Capture something first.</div>}
              {textOverlay && <div className="nk-spark-overlay-text">{textOverlay}</div>}
              {sticker && <div className="nk-spark-overlay-sticker">{sticker}</div>}
              {template && <div className="nk-spark-template-badge">{template}</div>}
            </div>
            <div className="nk-spark-timeline" aria-label="Spark clip timeline">
              {clips.map((clip, index) => <SparkClipThumb key={`${clip.name}-${index}`} file={clip} selected={selectedClip === index} onClick={() => setSelectedClip(index)} index={index} />)}
              {clips.length < maxClips && <button className="nk-spark-add" onClick={() => setPhase("camera")} aria-label="Add another clip"><PlusIcon /></button>}
            </div>
            {familyStoryCandidate && <div className="nk-family-story-prompt"><div><Heart /><div><strong>This Spark can become a Family Story.</strong><span>{formatTime(totalDuration)} of media is longer than the {maxSeconds}-second Moment limit. Save a private Family Story copy when you publish.</span></div></div><span className="nk-family-story-check">✓</span></div>}
            {tool && <div className="nk-spark-tool-sheet">
              {tool === "effects" && <div className="nk-effect-grid">{EFFECTS.map((item) => <button key={item.id} className={effect === item.id ? "is-selected" : ""} onClick={() => setEffect(item.id)}><span className={`nk-effect-sample ${item.className}`} />{item.label}</button>)}</div>}
              {tool === "text" && <div className="nk-tool-row"><TextCursorInput /><input value={textOverlay} onChange={(event) => setTextOverlay(event.target.value)} placeholder="Add words to your Spark" maxLength={160} /></div>}
              {tool === "stickers" && <div className="nk-sticker-grid">{STICKERS.map((item) => <button key={item} onClick={() => setSticker(item)} className={sticker === item ? "is-selected" : ""}>{item}</button>)}</div>}
              {tool === "templates" && <div className="nk-template-grid">{TEMPLATES.map((item) => <button key={item} onClick={() => setTemplate(item)} className={template === item ? "is-selected" : ""}><span>{item.slice(0, 1)}</span>{item}</button>)}</div>}
              {tool === "music" && <div className="nk-tool-row"><Music2 /><label className="nk-music-picker">{musicFile ? musicFile.name : "Add original or licensed audio"}<input type="file" accept="audio/*" onChange={chooseMusic} /></label></div>}
              {tool === "timer" && <div className="nk-tool-row"><Clock3 /><strong>{countdownEnabled ? "3-second countdown enabled" : "Countdown off"}</strong><button onClick={() => setCountdownEnabled((value) => !value)}>{countdownEnabled ? "Turn off" : "Turn on"}</button></div>}
            </div>}
            <nav className="nk-spark-tool-dock" aria-label="Spark creation tools">
              <button onClick={() => setTool(tool === "effects" ? null : "effects")}><Sparkles /><span>Effects</span></button>
              <button onClick={() => setTool(tool === "text" ? null : "text")}><TextCursorInput /><span>Text</span></button>
              <button onClick={() => setTool(tool === "stickers" ? null : "stickers")}><Sticker /><span>Stickers</span></button>
              <button onClick={() => setTool(tool === "music" ? null : "music")}><Music2 /><span>Music</span></button>
              <button onClick={() => setTool(tool === "templates" ? null : "templates")}><Zap /><span>Templates</span></button>
              <button onClick={() => setTool(tool === "timer" ? null : "timer")}><TimerReset /><span>Timer</span></button>
            </nav>
            <footer className="nk-spark-editor-footer"><div><span>Make it yours</span><small>Original media stays yours.</small></div><button onClick={() => void publish()} disabled={!clips.length || publishing}>{publishing ? "Publishing…" : "Share Spark"}<Send /></button></footer>
          </>
        )}
      </div>
      {error && <div className="nk-spark-studio__error" role="alert">{error}</div>}
      {phase !== "editor" && <div className="nk-spark-meter"><div style={{ width: `${Math.min(100, (recordedSeconds / maxSeconds) * 100)}%` }} /><span>{formatTime(recordedSeconds)} / {formatTime(maxSeconds)}</span></div>}
    </div>
  );
}

function SparkClipThumb({ file, selected, onClick, index }: { file: File; selected: boolean; onClick: () => void; index: number }) {
  const url = useMemo(() => URL.createObjectURL(file), [file]);
  useEffect(() => () => URL.revokeObjectURL(url), [url]);
  return <button onClick={onClick} className={selected ? "is-selected" : ""}>{file.type.startsWith("video/") ? <video src={url} muted /> : <img src={url} alt="" />}<span>{index + 1}</span></button>;
}

function PlusIcon() {
  return <span aria-hidden="true" style={{ fontSize: 28, lineHeight: 1 }}>+</span>;
}
