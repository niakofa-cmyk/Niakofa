# Niakofa Media Studio Rebuild — 2026-10-01

This is a drop-in rebuild package for the Niakofa Community Media Studio and Moments presentation layer.

## Included

- `src/components/community/NiakofaSparkStudio.tsx`
- `src/components/community/niakofa-spark-studio.css`
- `src/lib/family-story-candidate.ts`
- direct Create-a-Spark patch
- legacy `/build` compatibility redirect patch
- global cyan-on-navy palette guidance
- Family Story media-preservation boundary
- donor feature map for the supplied Compose/Snapchat clone

## Important

This package intentionally does **not** replace Niakofa's existing authenticated media/storage backend. It is a frontend Studio rebuild plus integration patches. The existing production media certification gate remains authoritative.

The >60-second Family Story behavior is implemented as a preservation candidate in the Studio. Actual video-byte preservation must use the existing Family Vault media asset pipeline and requires a certified backend endpoint; the current caption-only `keepMoment` route is not sufficient for video archival.
