# Recommendations (priority order)

1. Do not start a large Globe/Research/DNA rewrite — Diaspora mutation acceptance is already green on 9ccff8d for Preserve+DNA.
2. Create one Research case under Davis Family if you want the third live test to pass.
3. Operator matrix: Tarrant vs second county GPS for pool/civic switch (POOL_GEO_MATRIX.md).
4. Ensure all user-facing pool UI reads /api/pool/my-stats only.
5. Payment: run Stripe test-mode webhook → financial_events → ledger → payout path once; keep integrity commits.
6. Rotate helper seed password after acceptance.
7. Provider-grade DNA = separate governed project.
