# County pool / civic geo verification matrix

Run while authenticated. Prefer two users or two GPS fixes (Tarrant vs Jackson/KC).

| Step | Action | Expect |
|------|--------|--------|
| 1 | GET /api/pool/my-stats at home GPS | community_id/name for that county; balance for THAT ledger only |
| 2 | Travel / mock GPS to another US county | PATCH location → community_id changes (or creates county community) |
| 3 | GET /api/pool/my-stats again | Different community_id; balance is that county's pool (not the previous county's dollars) |
| 4 | Helper payout/front | Debit only claimer's resolved community_id ledger |
| 5 | Sponsor contribution | Credit attributed to sponsor/request community — never silent global |
| 6 | Unresolved community | Payout/claim blocked (community_unresolved) |
| 7 | Civic needs / resources | Scoped to active community when those routes are used |

Live probe (helper@niakofa.app, 2026-09-05):
- my-stats → community_id=1, name=Tarrant County, balance=4.55
- pool/stats → global enabled, balance=4.55 (single active funded community)
