# Are implementations close to envisioned?

## Diaspora
Yes for the production boundary we set:
- Globe / Family / Vault / Tree / Research / Preserve / DNA consent-sketch / Timeline are wired in code
- Live E2E: Preserve + DNA mutation verified against production
- Provider-grade shared-cM/IBD remains future (correct)

## Community Pools (geo)
Architecture is county-scoped:
- /api/pool/my-stats returns community_id + community_name (live: Tarrant County id=1, balance $4.55)
- Ledger sums filter by community_id
- resolveCommunityFromFreshLocation / claim-scope fail-closed when unresolved
- GPS/county change is designed to re-resolve community and move pool/civic surfaces with the user

Remaining honesty note:
- /api/pool/stats still exposes a platform-level aggregate view (same $4.55 in this environment because only one funded community is active). UI that shows "My Community Pool" must use my-stats, not global stats.

## Payments
Recent main commits harden Stripe money movement, refund watermarks, restart-safe payouts, PIF repayments. Full Stripe→ledger E2E still needs operator runbooks against live/test Stripe — not inventable from GitHub alone.

## Railway
Set variables from .env.railway.example in the Railway dashboard (Grok cannot write them).
Include NIAKOFA_API_ORIGIN=https://niakofa.com (or the railway.app origin) for gate scripts.
