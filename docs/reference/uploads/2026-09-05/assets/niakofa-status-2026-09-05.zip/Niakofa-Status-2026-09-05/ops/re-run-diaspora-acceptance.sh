#!/usr/bin/env bash
set -euo pipefail
cd "${REPO_DIR:-$HOME/Niakofa-clean}"
export USER_A_STATE="${USER_A_STATE:-$HOME/niakofa-acceptance/playwright/.auth/user-a.json}"
export BASE_URL="${BASE_URL:-https://niakofa.com}"
export ALLOW_MUTATING_E2E=1
export CONFIRM_DISPOSABLE_ACCOUNT=1
test -f "$USER_A_STATE" || { echo "Missing USER_A_STATE file: $USER_A_STATE"; exit 1; }
npx playwright test e2e/diaspora-final-wiring-live.spec.ts --reporter=list
