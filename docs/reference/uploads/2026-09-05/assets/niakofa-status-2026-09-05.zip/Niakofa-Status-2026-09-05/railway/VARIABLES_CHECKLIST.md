# Railway Variables (set in dashboard — not via Grok)

Service serving niakofa.com / zesty-ambition-production-f6a1.up.railway.app

From repo .env.railway.example (required subset):

DATABASE_URL          (Postgres plugin)
REDIS_URL             (if workers enabled)
APP_URL               https://niakofa.com
ALLOWED_ORIGIN        https://niakofa.com
NIAKOFA_API_ORIGIN    https://niakofa.com
MAPBOX_TOKEN          (runtime geocode)
VITE_MAPBOX_TOKEN     (rebuild after change)
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
VITE_STRIPE_PUBLISHABLE_KEY  (rebuild after change)
SESSION_SECRET
ADMIN_SECRET
LIVEKIT_*             if Circles media enabled
DNA_MATCHING_ENABLED=false until ready

Do NOT store USER_A_STATE or user passwords in Railway Variables.
