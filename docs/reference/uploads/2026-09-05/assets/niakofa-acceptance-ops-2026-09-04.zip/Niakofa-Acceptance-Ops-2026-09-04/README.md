# Niakofa Acceptance Ops — 2026-09-04

## Verified live deployment
- Origin: `https://zesty-ambition-production-f6a1.up.railway.app`
- `/api/health` → ok, commit **`4fab669339cd74a4e9f2d7b2ca6af5a6fc3b5487`**
- `/api/status` → database ok, map ok
- `/api/diaspora/dashboard` without token → **401** (auth gate working)

## Blockers in this Grok environment
1. **Railway connector is not available** — cannot set Railway Variables from here (only GitHub is connected).
2. **No valid `USER_A_STATE` file** was uploaded to this session — cannot invent Playwright storage state.
3. Do **not** paste storage-state JSON or passwords into chat.

## What you must do (5 minutes)
1. Railway dashboard → project service for `zesty-ambition-production-f6a1` → Variables → apply checklist in `railway/RAILWAY_VARIABLES.md`
2. Locally generate disposable auth state: `ops/generate-user-a-state.mjs` (credentials via env, not chat)
3. Upload/store the JSON only on your machine / CI secrets — never commit it
4. Run `ops/run-deployed-acceptance.sh`

## Safety already on main
Commit `5a6ab5c` / `4fab669` closed production test-account seeding defaults and CSP IP geolocation — keep those; do not re-open default production passwords.
