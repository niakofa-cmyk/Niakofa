# Railway Variables — service behind zesty-ambition-production-f6a1.up.railway.app

Grok **cannot** write these (Railway not connected). Set in:
Railway → Project → **the web/API service** serving that domain → Variables

## Required for production app (typical monorepo single service)

| Variable | Suggested value | Why |
|----------|-----------------|-----|
| `DATABASE_URL` | (Railway Postgres plugin) | Persistence |
| `VITE_MAPBOX_TOKEN` | your Mapbox public token | Globe / maps (build-time for Vite) |
| `NODE_ENV` | `production` | |
| `PORT` | set by Railway | |

## CORS / public origin (if split web/API or strict CORS)

If the API validates origin, set **one** of the patterns your code expects:

| Variable | Suggested value |
|----------|-----------------|
| `CORS_ORIGIN` or `ALLOWED_ORIGINS` | `https://zesty-ambition-production-f6a1.up.railway.app` |
| `PUBLIC_APP_URL` / `APP_URL` | same HTTPS origin |

## Smoke / acceptance runners (CI or local — not always needed on Railway runtime)

| Variable | Value |
|----------|-------|
| `NIAKOFA_WEB_URL` | `https://zesty-ambition-production-f6a1.up.railway.app` |
| `NIAKOFA_API_URL` | `https://zesty-ambition-production-f6a1.up.railway.app` |
| `NIAKOFA_EXPECT_COMMIT` | `4fab669339cd74a4e9f2d7b2ca6af5a6fc3b5487` |

> Note: **`NIAKOFA_API_ORIGIN` is not a canonical name in the current release-smoke script.**  
> Use `NIAKOFA_API_URL` / `NIAKOFA_WEB_URL`. If some branch of your code reads `NIAKOFA_API_ORIGIN`, set it to the same HTTPS origin for compatibility:
> `NIAKOFA_API_ORIGIN=https://zesty-ambition-production-f6a1.up.railway.app`

## DNA (keep safe)

| Variable | Recommended production |
|----------|------------------------|
| `DNA_MATCHING_ENABLED` | `false` or `0` until operator-ready |
| `DNA_MATCHING_ENGINE` | `sketch` or `none` — never claim IBD without real engine |

## Do NOT put on Railway as plaintext defaults

- Playwright `USER_A_STATE` (local/CI secret only)
- Known shared seed passwords in production (blocked by seed script without explicit env + flag)

After changing **Vite** vars (`VITE_*`), trigger a **redeploy/rebuild** so the client bundle picks them up.
