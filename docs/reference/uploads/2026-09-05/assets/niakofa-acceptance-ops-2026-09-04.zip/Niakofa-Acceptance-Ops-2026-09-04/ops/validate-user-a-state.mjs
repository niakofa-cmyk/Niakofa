#!/usr/bin/env node
/** Validate a Playwright storageState file without printing secrets. */
import fs from "node:fs";

const file = process.argv[2] || process.env.USER_A_STATE;
if (!file) {
  console.error("Usage: node validate-user-a-state.mjs path/to/user-a.json");
  process.exit(1);
}
if (!fs.existsSync(file)) {
  console.error("FAIL: file does not exist:", file);
  process.exit(1);
}
let data;
try {
  data = JSON.parse(fs.readFileSync(file, "utf8"));
} catch {
  console.error("FAIL: not valid JSON");
  process.exit(1);
}
const ok =
  data &&
  typeof data === "object" &&
  (Array.isArray(data.cookies) || Array.isArray(data.origins));
if (!ok) {
  console.error("FAIL: not a Playwright storageState (need cookies[] and/or origins[])");
  process.exit(1);
}
const cookieCount = Array.isArray(data.cookies) ? data.cookies.length : 0;
const originCount = Array.isArray(data.origins) ? data.origins.length : 0;
console.log(`PASS: storageState shape ok (cookies=${cookieCount}, origins=${originCount})`);
console.log("Path only — contents not printed.");
