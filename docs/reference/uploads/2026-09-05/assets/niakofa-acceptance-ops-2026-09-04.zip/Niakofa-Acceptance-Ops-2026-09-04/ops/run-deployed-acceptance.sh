#!/usr/bin/env bash
# Run from Niakofa monorepo root after USER_A_STATE is a real storageState file.
set -euo pipefail

export BASE_URL="${BASE_URL:-https://zesty-ambition-production-f6a1.up.railway.app}"
export ALLOW_MUTATING_E2E=1
export EXPECTED_COMMIT="${EXPECTED_COMMIT:-4fab669339cd74a4e9f2d7b2ca6af5a6fc3b5487}"
: "${USER_A_STATE:?Set USER_A_STATE to a Playwright storageState JSON path}"

echo "== Validate storage state =="
node "$(dirname "$0")/validate-user-a-state.mjs" "$USER_A_STATE"

echo "== Health / commit probe =="
curl -sS "$BASE_URL/api/health" | tee /tmp/niakofa-health.json
echo
if command -v jq >/dev/null; then
  got=$(jq -r .commit /tmp/niakofa-health.json)
  echo "Deployed commit: $got"
  echo "Expected:        $EXPECTED_COMMIT"
fi

echo "== Gated live mutation suite =="
npx playwright test e2e/diaspora-final-wiring-live.spec.ts --reporter=list

echo "Acceptance suite finished. Attach playwright-report/ to release notes."
