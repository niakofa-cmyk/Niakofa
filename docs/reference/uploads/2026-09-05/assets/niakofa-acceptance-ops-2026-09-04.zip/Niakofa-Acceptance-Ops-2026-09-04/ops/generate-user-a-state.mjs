#!/usr/bin/env node
/**
 * Generate Playwright storageState for disposable User A.
 *
 * NEVER paste passwords or the output JSON into chat.
 *
 * Usage:
 *   DISPOSABLE_EMAIL='you@example.com' \
 *   DISPOSABLE_PASSWORD='…' \
 *   BASE_URL='https://zesty-ambition-production-f6a1.up.railway.app' \
 *   OUT='playwright/.auth/user-a.json' \
 *   node ops/generate-user-a-state.mjs
 *
 * Requires: playwright installed in the monorepo (`pnpm exec playwright`).
 */
import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";

const base = (process.env.BASE_URL || "https://zesty-ambition-production-f6a1.up.railway.app").replace(/\/+$/, "");
const email = process.env.DISPOSABLE_EMAIL?.trim();
const password = process.env.DISPOSABLE_PASSWORD ?? "";
const out = process.env.OUT || "playwright/.auth/user-a.json";

if (!email || !password) {
  console.error("Set DISPOSABLE_EMAIL and DISPOSABLE_PASSWORD (env only).");
  process.exit(1);
}

fs.mkdirSync(path.dirname(out), { recursive: true });

const browser = await chromium.launch({ headless: true });
const context = await browser.newContext();
const page = await context.newPage();

await page.goto(`${base}/login`, { waitUntil: "networkidle" });

// Best-effort selectors — adjust if login UI differs
const emailSel = 'input[type="email"], input[name="email"], input[autocomplete="email"]';
const passSel = 'input[type="password"], input[name="password"]';
await page.locator(emailSel).first().fill(email);
await page.locator(passSel).first().fill(password);
await page.locator('button[type="submit"], button:has-text("Sign in"), button:has-text("Log in")').first().click();
await page.waitForTimeout(2500);

// Prefer SPA token in localStorage if present
const token = await page.evaluate(() => localStorage.getItem("niakofa_token"));
if (!token) {
  console.warn("Warning: niakofa_token not found in localStorage — storage state may still hold cookies.");
}

await context.storageState({ path: out });
await browser.close();

// Validate shape
const raw = JSON.parse(fs.readFileSync(out, "utf8"));
if (!raw.cookies && !raw.origins) {
  console.error("Output is not a Playwright storageState object.");
  process.exit(1);
}
console.log(`Wrote storage state to ${out}`);
console.log("Set USER_A_STATE to that path. Do not commit this file.");
