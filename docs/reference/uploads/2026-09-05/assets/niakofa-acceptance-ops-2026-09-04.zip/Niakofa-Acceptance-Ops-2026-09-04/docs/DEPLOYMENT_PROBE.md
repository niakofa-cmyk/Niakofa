# Live probe (executed 2026-09-04)

| Endpoint | HTTP | Observation |
|----------|------|-------------|
| `/` | 200 | SPA HTML |
| `/api/health` | 200 | `commit: 4fab669…`, nia_service ok |
| `/api/status` | 200 | database ok, map ok, nia_ai disabled |
| `/api/diaspora/dashboard` | 401 | Bearer required |

**Deployed revision for acceptance:** `4fab669339cd74a4e9f2d7b2ca6af5a6fc3b5487`  
(Supersedes earlier `b8a2316` Heritage lock; include both in notes if needed.)
