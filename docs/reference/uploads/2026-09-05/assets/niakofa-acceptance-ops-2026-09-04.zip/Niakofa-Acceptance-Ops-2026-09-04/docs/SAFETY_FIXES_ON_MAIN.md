# Safety fixes already on public main (keep)

| Commit | Change |
|--------|--------|
| `5a6ab5c` | security: close production test-account seeding defaults |
| `4fab669` | fix: allow IP geolocation fallback through CSP |

Seed script requires explicit passwords + `--i-know-this-is-production` for non-local DBs. Do not reintroduce shared default production passwords.
