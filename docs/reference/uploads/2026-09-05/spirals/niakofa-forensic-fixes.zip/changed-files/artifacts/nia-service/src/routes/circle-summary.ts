import type { Request, Response } from "express";
import { Router } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { timingSafeEqual } from "node:crypto";
import { pino } from "pino";
import { isNiaEnabled } from "../lib/db.js";

/**
 * P0-02 fix — Circle AI summary bypassed the Nia kill-switch.
 *
 * Previously, api-server's audio-circles.ts called
 * https://api.anthropic.com/v1/messages directly with its own
 * ANTHROPIC_API_KEY, never touching nia-proxy.ts and never checking
 * isNiaEnabled(). That meant disabling Nia app-wide (the DB-backed,
 * fail-closed kill-switch used everywhere else — see chat.ts and
 * app-ai-boundary.test.ts) did nothing to stop Circle recordings from
 * calling out to Anthropic.
 *
 * Fix: the only Anthropic call for Circle summaries now lives here, in
 * nia-service, behind:
 *   1. The same requireInternalSecret guard chat.ts uses (fail-closed —
 *      rejects if INTERNAL_SECRET isn't configured, and uses a
 *      timing-safe comparison), so this can't be hit directly even if
 *      nia-service is publicly reachable.
 *   2. isNiaEnabled() — the same DB-backed, fail-closed switch that
 *      gates /chat. If Nia is disabled, this returns 503 and
 *      api-server's caller falls back to "ready, no summary" instead of
 *      calling Anthropic.
 *
 * api-server no longer needs its own ANTHROPIC_API_KEY for this path.
 */

const logger = pino({ name: "nia-service:circle-summary" });
const router = Router();

const anthropicApiKey = process.env["ANTHROPIC_API_KEY"];
if (!anthropicApiKey) {
  logger.error("ANTHROPIC_API_KEY is not set — circle-summary will not be able to respond");
}
const anthropic = new Anthropic({ apiKey: anthropicApiKey ?? "" });

// Same fail-closed internal-secret guard as chat.ts's requireInternalSecret.
// Duplicated rather than imported to keep this route independently reviewable
// and to avoid a cross-module coupling that could get out of sync silently.
function requireInternalSecret(req: Request, res: Response): boolean {
  const configuredSecret = process.env["INTERNAL_SECRET"] ?? "";
  if (!configuredSecret) {
    logger.error("INTERNAL_SECRET is not configured — rejecting circle-summary call to prevent unauthorized Anthropic access");
    res.status(503).json({ error: "Service not configured" });
    return false;
  }
  const callerSecret = req.headers["x-internal-secret"];
  const callerSecretStr = Array.isArray(callerSecret) ? callerSecret[0] : (callerSecret ?? "");
  const secretBuf = Buffer.from(configuredSecret, "utf8");
  const callerBuf = Buffer.from(callerSecretStr, "utf8");
  if (secretBuf.length !== callerBuf.length || !timingSafeEqual(secretBuf, callerBuf)) {
    res.status(403).json({ error: "Forbidden" });
    return false;
  }
  return true;
}

interface CircleSummaryRequestBody {
  title?: string;
  topic?: string | null;
  duration_minutes?: number | null;
}

interface CircleSummaryResult {
  summary: string | null;
  chapters: Array<{ start: number; title: string }> | null;
}

// POST /internal/circle-summary — called only by api-server's
// generateAiSummaryInBackground(), never by clients directly.
router.post("/internal/circle-summary", async (req: Request, res: Response) => {
  if (!requireInternalSecret(req, res)) return;

  // Fail closed on the same app-wide Nia toggle used for /chat. This is the
  // actual kill-switch: turning Nia off now stops Circle AI summaries too.
  if (!(await isNiaEnabled())) {
    return res.status(503).json({ error: "Nia is temporarily unavailable." });
  }

  if (!anthropicApiKey) {
    return res.status(503).json({ error: "Service not configured" });
  }

  const body = req.body as CircleSummaryRequestBody;
  const title = typeof body.title === "string" ? body.title.slice(0, 200) : "Untitled circle";
  const topic = typeof body.topic === "string" ? body.topic.slice(0, 200) : "General discussion";
  const durationMin = typeof body.duration_minutes === "number" && body.duration_minutes > 0
    ? Math.round(body.duration_minutes)
    : null;

  const prompt = `You are summarizing an audio recording of a community circle session.
Title: ${title}
Topic: ${topic}
Duration: ${durationMin ? `${durationMin} minutes` : "Unknown"}

Provide:
1. A concise 2-3 sentence summary of what was likely discussed.
2. 3-6 chapter markers as JSON: [{"start": <seconds>, "title": "<short label>"}]

Respond as valid JSON: {"summary": "...", "chapters": [...]}

Do not include any text outside the JSON block.`;

  try {
    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 1024,
      messages: [{ role: "user", content: prompt }],
    });

    const text = response.content[0]?.type === "text" ? response.content[0].text : "";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const result: CircleSummaryResult = { summary: null, chapters: null };
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[0]);
        result.summary = typeof parsed.summary === "string" ? parsed.summary : null;
        result.chapters = Array.isArray(parsed.chapters) ? parsed.chapters : null;
      } catch {
        // leave result as nulls — caller treats this as "no summary available"
      }
    }

    return res.json({ ok: true, ...result });
  } catch (err) {
    logger.error({ err }, "circle-summary: Anthropic call failed");
    return res.status(502).json({ error: "Summary generation failed" });
  }
});

export default router;
