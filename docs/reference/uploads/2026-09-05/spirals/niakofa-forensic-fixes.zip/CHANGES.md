# Niakofa Circles — forensic-report fixes

Verified against the live public repo `niakofa-cmyk/Niakofa`, HEAD
`a16842afabbb7d3cfd6f80011b75a9693996457a` (matches the forensic report's
stated baseline exactly). Every claim below was checked by reading the real
source, not assumed from the report.

## How to apply

Either:
- Copy the files under `changed-files/` over the same paths in your checkout, or
- `git apply forensic-fixes.patch` from the repo root.

Then:
```
cd artifacts/api-server && pnpm run typecheck && pnpm test
cd ../nia-service   && pnpm run typecheck && pnpm test
```
Both pass clean as of this patch (api-server: 40 suites / 354 tests / 0
failures / 5 pre-existing skips; nia-service: 4 suites / 37 tests).

## What was verified as accurate in the forensic report

- P1-01/P1-11 — `getActiveParticipants()` had no `.limit()`. Confirmed.
- P1-02/P2-01–05 — N+1 in `GET /audio-circles`: a `Promise.all()` per circle
  ran a live-session lookup, a follow lookup, a full participants read, and
  a separate host-name lookup. Confirmed.
- P1-03/P1-04 — `ensureCirclesForCity()` ran inline inside the `GET`
  handler, and its `catch` block only logged and swallowed failures.
  Confirmed.
- P1-05/P1-06/P1-13 — zero `db.transaction()` calls anywhere in the
  host-failover path (`expireIfHostGraceElapsed`). Confirmed; the race is
  real, not theoretical.
- P0-03 — a documented prior Nia kill-switch bypass exists in
  `.agents/memory/niakofa-nia-audit-fixes.md`. Confirmed.

## One correction to the report

- P2-10 states the speaker limits are `[4, 8, 12, 18, 24]`. The actual code
  (`VALID_SPEAKER_LIMITS` in `audio-circles.ts`) is
  `[4, 8, 12, 13, 18, 24]` — there's a `13` in there the report didn't
  mention. Not fixed here since it wasn't reported as a bug, just flagging
  the discrepancy.

## Fixes implemented in this patch

### P0-02 — Nia kill-switch bypass (most serious item)
**Before:** `generateAiSummaryInBackground()` in `audio-circles.ts` called
`https://api.anthropic.com/v1/messages` directly, with its own
`ANTHROPIC_API_KEY`, and never checked `isNiaEnabled()`. Disabling Nia
app-wide did nothing to stop Circle recordings from calling Anthropic.

**After:** the Anthropic call now lives only in a new nia-service route,
`POST /internal/circle-summary` (`artifacts/nia-service/src/routes/circle-summary.ts`),
gated by:
1. The same fail-closed `x-internal-secret` guard `/chat` uses
   (rejects if `INTERNAL_SECRET` isn't configured; timing-safe comparison).
2. `isNiaEnabled()` — the same DB-backed, fail-closed switch that gates
   `/chat`. Nia off → 503 → api-server degrades to "ready, no summary"
   instead of calling Anthropic.

`audio-circles.ts` now checks `isNiaEnabled()` itself (imported from
`nia-proxy.ts`) before even making the request, and calls the internal
route instead of Anthropic. `api-server` no longer needs its own
`ANTHROPIC_API_KEY` for this path.

### P1-01/P1-11 — unbounded participant reads
Added `MAX_PARTICIPANTS_PER_QUERY = 500` and applied it to
`getActiveParticipants()`. Added `getActiveParticipantCounts()`, a bulk
grouped-aggregate query for speaker/listener counts across many sessions at
once, instead of hydrating full rows just to show two numbers.

### P1-02/P2-01–05 — N+1 in `GET /audio-circles`
Replaced the per-circle `Promise.all()` with four fixed bulk queries
regardless of city size: all live sessions (`inArray` on circle ids), all
follow rows for the user, grouped participant counts per session, and one
`inArray` host-name lookup. Circle count no longer changes the number of
queries.

### P1-03/P1-04 — provisioning on the read path / swallowed errors
`ensureCirclesForCity()` no longer catches its own errors. `GET
/audio-circles` no longer awaits it — `scheduleCityProvisioning()` kicks it
off fire-and-forget, at most once per city per 60s cooldown. On failure the
cooldown entry is rolled back (so the next request retries) and the error
is logged at `error` severity, not silently absorbed.

### P1-05/P1-06/P1-13 — host-failover race
`expireIfHostGraceElapsed()` is now a single `db.transaction()`:
- `pg_advisory_xact_lock(key, session_id)` serializes concurrent callers for
  the same session (same pattern already used in `community-pool.ts` and
  `griot.ts` in this codebase).
- The row is re-read inside the transaction/lock.
- The session-update step (`WHERE host_disconnected_at = <value read>` with
  `.returning()`) is an optimistic-concurrency guard as defense in depth: if
  it doesn't match a row, this caller backs off and re-reads instead of
  double-promoting or double-ending.

### P1-08/P1-09 — dead mesh code
Not touched in this patch. Confirmed via grep that `AudioCircleMesh` has no
non-test call sites — only `getAudioCircleMediaCapabilities` is imported
from that file, and the live session manager wires exclusively to
`LiveKitCircleTransport`. This is real cleanup/regression-risk work
(remove or gate the mesh class), just not included here to keep this patch
focused on the P0/P1 items with the clearest fix shape.

## Test changes

`audio-circles.test.ts` mocks `@workspace/db` and `../lib/ws-hub` by hand
for native ESM. Three additions were needed purely because the mocks now
need to cover surface area the fixed code actually calls:
- `db.transaction` — mocked to just invoke its callback with the same mock
  db, matching how other suites in this repo already mock it.
- `systemSettingsTable` and `sendNiaEventToUser` exports — needed because
  `audio-circles.ts` now imports `isNiaEnabled` from `nia-proxy.ts`, which
  imports these.
- Several tests fed the `getActiveParticipants()` result through the mock's
  generic `.then()` resolution because the original function had no
  `.limit()` call. Since it now does, those tests were updated to supply
  that value as a third `.limit()` mock instead — no behavior assertions
  changed, only how the mock feeds the (now-bounded) query.

## Explicitly not done here

- P1-07 (in-memory WS state not multi-instance-safe), P1-10 (real-device
  LiveKit certification), P1-14 (block/report cross-check testing), and the
  Circles→Spirals migration itself are unchanged. They're either
  infrastructure/process items outside a code patch, or — per the
  migration plan in the uploaded zip — deliberately sequenced *after* this
  stabilization pass, not before it.
