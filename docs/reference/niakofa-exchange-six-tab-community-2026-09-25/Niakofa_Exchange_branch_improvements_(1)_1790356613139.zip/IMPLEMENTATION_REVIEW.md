# Niakofa Exchange branch review

Target: feature/niakofa-exchange-six-tab-community

## Required fixes
1. Remove Exchange/Profile duplicates from the secondary menu.
2. Update the V14 contract test to expect the six-tab Community architecture.
3. Assert Exchange is wired into the Community route and view.
4. Run CI on the branch before merge.

## Product hardening
The Exchange surface currently provides a marketplace doorway into existing Requests and Skills data. It does not yet implement a true goods-listing marketplace, seller onboarding, listing CRUD, search/filter backend, checkout, order state, or messaging tied to transactions. Those should be treated as the next Exchange product milestone rather than implied by the UI.
