# Implementation Specification

## 1. Navigation

Primary:

1. Home
2. Moments
3. Spirals
4. People
5. Notifications

Persistent header action:

- Messages → `/messages`

Secondary menu:

- Hubs
- Requests
- Services
- Spirals
- Media
- Diaspora
- Family
- Legacy
- Profile

## 2. Moments

Moments is not the database object. It is the user-facing destination and immersive viewing experience.

Recommended copy:

- Open Moments
- Explore Moments
- Your Moments
- Create a Spark
- Post a Spark
- Share a Spark
- Your Sparks
- Sparks from this Hub
- Sparks from your Spirals

## 3. Spark model

The existing `CommunityStory` record can temporarily represent a Spark. Do not duplicate media storage or create a second short-form media pipeline.

Recommended eventual frontend type:

```ts
export type CommunitySpark = CommunityStory;
```

Recommended eventual analytics:

```text
moment_opened
community_spark_created
community_spark_viewed
community_spark_reacted
community_spark_shared
moment_spark_advanced
moment_creator_changed
```

During migration, retain the existing `community_story_*` analytics as compatibility aliases.

## 4. Viewer behavior

The existing viewer should evolve toward:

- tap right → next Spark
- tap left → previous Spark
- last Spark → next creator
- first Spark → previous creator
- swipe left → next creator
- swipe right → previous creator
- swipe down → close
- press/hold → pause
- release → resume

The viewer should remain full-viewport rather than a constrained phone-shaped card on desktop.

## 5. Composer

The existing composer becomes a Spark Composer without changing the underlying API initially.

Copy changes:

- `Create Story` → `Create a Spark`
- `Add text to your Story` → `Add text to your Spark`
- `Share Story` → `Share Spark`
- `Reply to this Story` → `Reply to this Spark`
- `Story media` → `Spark media`

## 6. Story boundary

The word Story remains available for durable narrative content:

- Community Stories
- Family Stories
- Griot
- Legacy

A short-form Spark may be promoted into a durable Story later, but the two concepts should not be conflated.

## 7. Spirals

Spirals is now the official user-facing term. Do not expose Circles in navigation, headings, buttons, empty states, or descriptions.

Keep route/API aliases only where required for compatibility.

## 8. Nia separation

Nia may appear as optional creation assistance:

- Create with Nia
- Caption with Nia
- Translate with Nia
- Spark ideas with Nia

Nia should not become the Community navigation, primary identity, or Moments destination.
