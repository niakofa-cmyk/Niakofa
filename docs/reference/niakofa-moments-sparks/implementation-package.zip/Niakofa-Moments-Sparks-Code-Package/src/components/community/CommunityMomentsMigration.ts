/** Product-language constants. Keep API/database names unchanged during migration. */
export const COMMUNITY_CONTENT_LANGUAGE = {
  destination: "Moments",
  itemSingular: "Spark",
  itemPlural: "Sparks",
  community: "Spirals",
  durableNarrative: "Stories",
  preservedMemory: "Legacy",
} as const;

export const LEGACY_STORY_ROUTES = [
  "/community/stories",
  "/community/stories?storyId=",
] as const;

export const MOMENTS_ROUTE = "/community/moments" as const;
