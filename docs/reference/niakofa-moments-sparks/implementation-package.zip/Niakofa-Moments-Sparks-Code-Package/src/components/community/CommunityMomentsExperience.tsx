import { CommunityStoryRail } from "./CommunityStoryRail";

/**
 * Product-language boundary for Niakofa Moments.
 *
 * IMPORTANT: the existing Story API/data model remains the persistence layer.
 * "Moment" is the viewing experience; an individual short-form item is a
 * "Spark" in the product vocabulary.
 */
export function CommunityMomentsExperience({
  hubId,
  openComposerSignal,
  openStoryId,
  compact = false,
}: {
  hubId: number | null;
  openComposerSignal?: number;
  openStoryId?: number | null;
  compact?: boolean;
}) {
  return (
    <section
      className="nia-community-moments-experience"
      aria-label="Niakofa Community Moments experience"
    >
      <header className="mb-3 px-3 sm:px-0">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.18em] text-primary">
              Moments
            </p>
            <h1 className="text-2xl font-black tracking-tight">The Global Village in motion.</h1>
            <p className="mt-1 max-w-xl text-sm text-muted-foreground">
              Discover Sparks from people, places, Spirals, and Hubs across Niakofa.
            </p>
          </div>
          <span className="hidden shrink-0 rounded-full border border-border px-3 py-1 text-[11px] font-bold sm:inline-flex">
            Sparks
          </span>
        </div>
      </header>
      <CommunityStoryRail
        hubId={hubId}
        openComposerSignal={openComposerSignal}
        openStoryId={openStoryId}
        compact={compact}
      />
    </section>
  );
}
