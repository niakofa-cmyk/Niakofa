import { CommunityMomentsExperience } from "@/components/community/CommunityMomentsExperience";

export function CommunityMomentsView({
  hubId,
  openSparkId,
}: {
  hubId: number | null;
  openSparkId: number | null;
}) {
  return (
    <div className="space-y-3">
      <CommunityMomentsExperience hubId={hubId} openStoryId={openSparkId} />
    </div>
  );
}
