import { describe, test } from "node:test";
import * as assert from "node:assert";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, "../..");
const shell = fs.readFileSync(path.join(root, "components/community/CommunitySocialShell.tsx"), "utf8");
const moments = fs.readFileSync(path.join(root, "components/community/CommunityMomentsExperience.tsx"), "utf8");

describe("Niakofa Moments / Sparks / Spirals product vocabulary", () => {
  test("primary navigation uses Moments and Spirals", () => {
    assert.match(shell, /label: "Moments"/);
    assert.match(shell, /label: "Spirals"/);
    assert.doesNotMatch(shell, /label: "Stories"/);
    assert.doesNotMatch(shell, /label: "Circles"/);
  });

  test("Moments is the destination and Sparks are the content units", () => {
    assert.match(moments, /Moments/);
    assert.match(moments, /Sparks/);
    assert.match(moments, /Create|Discover/);
  });

  test("Messages remains outside the five-position primary navigation", () => {
    assert.doesNotMatch(shell, /key: "messages" as const, label: "Messages"/);
    assert.match(shell, /onRoute\("\/messages"\)/);
  });

  test("legacy Story persistence remains intentionally untouched", () => {
    assert.match(moments, /CommunityStoryRail/);
  });
});
