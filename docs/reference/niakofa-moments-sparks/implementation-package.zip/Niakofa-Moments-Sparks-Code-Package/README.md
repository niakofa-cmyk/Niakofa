# Niakofa Moments + Sparks + Spirals Implementation Package

## Final product vocabulary

- **Moments** = the short-form viewing destination / experience.
- **Spark** = one short-form post/video created by a person or community.
- **Spirals** = the community/group destination formerly represented as Circles.
- **Stories** = reserved for durable narrative storytelling.
- **Griot / Legacy** = preserved cultural, family, and historical memory.

Core model:

> A Moment is the experience. A Spark is the expression. A Story is the narrative. A Legacy is what the community chooses to preserve.

## Safe migration strategy

This package intentionally does **not** rename the existing database tables or `/api/community/stories` routes. The current Story subsystem is the persistence and media layer underneath the new product language.

Frontend terminology becomes:

`Moments → Sparks`

Existing deep links using `/community/stories?storyId=...` can remain supported during migration.

## Primary Community navigation

`Home | Moments | Spirals | People | Notifications`

Messages remains a persistent header action and routes to `/messages`.

## Files

- `src/components/community/CommunitySocialShell.tsx` — updated primary navigation and Spirals terminology.
- `src/components/community/CommunityMomentsExperience.tsx` — Moments destination wrapper around the existing Story rail.
- `src/components/community/CommunityMomentsView.tsx` — Moments page boundary.
- `src/lib/__tests__/community-moments-sparks.contract.test.ts` — migration contract tests.

## Integration

1. Copy the files into `artifacts/pay-it-forward/src/...`.
2. Update `community.tsx` to import `CommunityMomentsView` and map `/community/moments` to it.
3. Normalize legacy `/community/stories` to `/community/moments` while preserving `storyId` as the temporary deep-link parameter.
4. Keep `CommunityStoryRail`, `CommunityStoryVisual`, Story media APIs, and database schema intact initially.
5. Update user-facing Story composer copy to `Create a Spark`, `Post a Spark`, and `Share this Spark`.
6. Later, rename internal types/files from Story → Spark only after the compatibility period.

## Acceptance contract

- Moments is a primary Community destination.
- Users create Sparks, not Moments.
- Spirals is the only user-facing name for the former Circles concept.
- Messages remains `/messages`.
- Existing Story APIs remain functional.
- Existing Story deep links remain recoverable during migration.
- Family/Diaspora/Legacy storytelling remains separate from short-form Sparks.
- Nia remains optional creation assistance, not Community navigation.
