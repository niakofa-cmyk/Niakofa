# Niakofa Legacy — Original Demo Asset Pack

This pack is a **licensing-safe, fully original** replacement for the
placeholder RPG Maker MZ character-generator assets referenced in
`docs/legacy-character-engine.md`. Nothing here is traced, derived, or
extracted from the uploaded `generator.zip` / `img_2.zip` archives, RPG
Maker RTP, or any third-party pack (Styloo Village, Retro Tree Pack, etc).
Everything was generated procedurally in this session — you can use, ship,
and modify it freely.

**Why this exists:** your own repo's `catalog.json` and
`.agents/memory/legacy-character-engine-runtime.md` already flag the
generator-derived files under `public/legacy-character-assets/tv/` as
`"licenseStatus": "review-required"` — and I noticed the actual `.png`
files are currently sitting in your public folder and being served to the
browser, not just cataloged. That's worth resolving before this ships
publicly. This pack gives you a drop-in alternative that carries **no**
licensing risk while you sort that out (or permanently, if you like the
style).

## What's inside

```
niakofa-legacy-demo-pack/
├── characters/tv/          42 original 144×192 walking spritesheets
│                            (3 walk frames × 4 directions, 48×48 cells)
├── world/tiles/             13 original 32×32 village tiles
├── catalog-original.json    Asset registry matching your engine's schema
├── character_manifest.json  Flat list of every generated asset + assetId
├── preview/index.html       Playable preview: Living Baobab → village walk
└── README.md                This file
```

## Character system

Matches `LegacyLayer` / `LegacyAgeGroup` / `LegacyGender` exactly:

- **Groups:** `adult_male`, `adult_female`, `kid`
- **Layers:** `body` (1 base per group), `clothing` (3 color variants per
  group), `rearHair` + `frontHair` (5 paired styles per group)
- **Hairstyles (original, geometric, non-derivative):** `afro`, `coils`,
  `braids`, `bun`, `locs` — directly answering the "Black hairstyles with
  modern outfits" brief from your reference sheet, without touching that
  sheet's actual artwork.
- **Composite order:** `rearHair → body → clothing → frontHair` (same order
  your `resolveWalkingAppearance()` already assumes).

## Wiring it into `legacy-character-engine.ts`

1. Copy `characters/tv/*.png` into
   `artifacts/pay-it-forward/public/legacy-world-assets/tv/` (new folder,
   so it doesn't collide with the existing generator-derived files).
2. Add a second `libraryId` branch in the engine (or swap
   `APPROVED_LAYER_ASSETS` / `BODY_ASSETS` wholesale) pointing `file` at
   `/legacy-world-assets/tv/...` using the `assetId`s in
   `character_manifest.json`.
3. Extend `LegacyLayer`/appearance input with an optional `hairStyle` field
   (`afro | coils | braids | bun | locs`) so `deterministicVariant()` can
   pick a style instead of only a numeric variant — the hook is already
   there since each hair asset's `assetId` embeds its style name.
4. `deriveLifeStage()` and `resolveCharacterAppearance()` need no changes —
   this pack only replaces the *visual* layer, exactly the boundary your
   own runtime notes describe ("generator controls visual representation,
   Vault controls truth").

## World tiles

13 tiles at 32×32 covering the Chapter-1 "House of Mensah" locations from
your design doc: `grass_01/02`, `dirt_path`, `red_earth`, `water`, `sand`,
`compound_wall`, `thatch_roof`, `tree_canopy`, `baobab_trunk`,
`market_stall`, `fence`, `cocoa_row`. Same "reuse across eras" principle
your docs describe — swap `compound_wall`→weathered variants for the
Collapse chapter rather than building a new tileset per chapter.

## `preview/index.html`

A single self-contained HTML file (no build step) that demonstrates the
actual golden-path loop from your design notes:

1. **Living Baobab home screen** — animated SVG tree, tap a branch to open
   a family-member card (deterministic appearance per `characterId`, matching
   your engine's determinism requirement).
2. **Enter the world** — top-down village map built from the tile pack,
   walk the generated character around with arrow keys / WASD.
3. **Record a memory** — a button that simulates the Vault → AI extraction
   → World Regeneration event: a new branch grows on the Baobab and a new
   NPC (freshly composited from the same asset pack) appears on the map.

Open it directly in a browser — it's plain HTML/CSS/JS, nothing to install.

## What I did *not* do

I did not open, extract usable art from, or repackage any file from
`generator.zip` or `img_2.zip` into this pack — those remain exactly as you
uploaded them, untouched. If you do secure a commercial license for the
RPG Maker generator or the named third-party packs, your engine's existing
`APPROVED_LAYER_ASSETS` promotion pattern (catalog-only → approved) is the
right place to bring them in — this pack doesn't need to be replaced, it
can just sit alongside as the always-safe fallback.
