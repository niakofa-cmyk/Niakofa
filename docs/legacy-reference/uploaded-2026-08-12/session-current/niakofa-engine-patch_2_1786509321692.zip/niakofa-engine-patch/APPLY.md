# Applying this patch to Niakofa-main

Verified against your uploaded repo: `git apply --check` passes cleanly,
and the full existing test suite (15/15) plus 5 new tests (20/20 total)
pass against the patched engine — checked with `tsx --test`.

## 1. Apply the code change

From the repo root:

```bash
git apply legacy-engine-patch/legacy-character-engine.patch
```

This modifies exactly one file:
`artifacts/pay-it-forward/src/lib/legacy-character-engine.ts`

If you'd rather review it as a whole file instead of a diff, the full
post-patch file is also reproducible by applying the patch — I didn't
include a duplicate whole-file copy to avoid ambiguity about which one is
authoritative.

## 2. Copy the new test cases

```bash
cp legacy-engine-patch/artifacts/pay-it-forward/src/lib/__tests__/legacy-character-engine.test.ts \
   artifacts/pay-it-forward/src/lib/__tests__/legacy-character-engine.test.ts
```

This is the *whole* test file (existing 15 tests, unchanged, plus 5 new
ones for the original-art library) — it replaces the file wholesale rather
than patching it, since the addition is a clean append.

## 3. Copy the new asset files

```bash
mkdir -p artifacts/pay-it-forward/public/legacy-world-assets/tv
cp legacy-engine-patch/artifacts/pay-it-forward/public/legacy-world-assets/tv/*.png \
   artifacts/pay-it-forward/public/legacy-world-assets/tv/
cp legacy-engine-patch/artifacts/pay-it-forward/public/legacy-world-assets/catalog-original.json \
   artifacts/pay-it-forward/public/legacy-world-assets/catalog-original.json
```

## 4. Run the tests

```bash
cd artifacts/pay-it-forward
npm test
```

(Or just the one file: `npx tsx --test src/lib/__tests__/legacy-character-engine.test.ts`)

## What changed, functionally

- **Nothing changes for existing callers.** `DEFAULT_LIBRARY_ID` stays
  `"niakofa-rpg-generator-v1"`, so every current call to
  `resolveWalkingAppearance`, `resolveCharacterAppearance`,
  `resolveWalkingAsset`, `getApprovedAsset`, and `inferAppearance` behaves
  identically to before. All 15 original tests pass unmodified.
- **New opt-in library:** pass `libraryId: "niakofa-original-art-demo-v1"`
  to any of those functions to get the license-clean original art instead.
- **New `hairStyle` field** on the appearance input
  (`"afro" | "coils" | "braids" | "bun" | "locs"`) — only meaningful for
  the original-art library; ignored by the generator library. Leave it
  unset and the engine still picks a deterministic style per
  `characterId` + `lifeStage` + `era`, same determinism guarantee as
  everything else in the file.
- `LegacyWalkingAppearance` now always carries a `libraryId` field so
  downstream renderers/tests can tell which art a resolved appearance came
  from.
- `getApprovedAsset(assetId, libraryId?)` gained an optional second
  parameter for the same reason.

## What did *not* change

- `deriveLifeStage`, `inferAppearance`'s gender/age inference rules, the
  "never invent identity from a filename" boundary, and the
  deceased-uses-death-year rule are all untouched.
- The generator library's asset tables, file paths, and deterministic
  variant math (`p02`–`p04`) are byte-identical to before — I diffed and
  test-verified this rather than assuming it.

## Suggested follow-up (not included here)

Flip `DEFAULT_LIBRARY_ID` to `"niakofa-original-art-demo-v1"` once you've
decided how to handle the review-required generator files currently
sitting in `public/legacy-character-assets/tv/`. That's a one-line change
at that point, and every existing call site picks up the license-clean art
automatically without further edits.
