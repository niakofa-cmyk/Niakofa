# Griot A+B+C integration — drop-in files

These files implement the sketch: Griot Stories now cohesively serves
(A) heritage archive, (B) gratitude tied to completed help requests, and
(C) diaspora social hubs — plus a real transcription/translation pipeline.

## How to apply
Copy each file into your repo at the SAME relative path, overwriting the
existing ones (griot.ts, gratitude.ts, index.ts x2, griot-stories.ts,
schema/index.ts). The rest are brand new files.

```
lib/db/migrations/0053_griot_gratitude_diaspora.sql   NEW — run via `pnpm --filter @workspace/db run migrate`
lib/db/src/schema/griot-stories.ts                     MODIFIED — adds story_type, request_id, gratitude_post_id, community_id, hub_id
lib/db/src/schema/diaspora-hubs.ts                      NEW — replaces the hardcoded 10-city array in globe.tsx
lib/db/src/schema/griot-transcription-jobs.ts            NEW — makes the "transcribing" status real
lib/db/src/schema/index.ts                              MODIFIED — barrel exports for the two new schema files

artifacts/api-server/src/routes/griot.ts                MODIFIED — enqueues jobs on create; adds GET/POST /griot/hubs, PATCH /griot/hubs/:id/claim, POST /admin/griot/hubs/:id/review
artifacts/api-server/src/routes/gratitude.ts            MODIFIED — adds POST /gratitude/:id/promote-to-story
artifacts/api-server/src/workers/griot-transcription-worker.ts   NEW — polls the job queue, drives text→translation pipeline
artifacts/api-server/src/index.ts                       MODIFIED — registers + starts the new worker

artifacts/nia-service/src/routes/griot-translate.ts       NEW — POST /griot/translate (Claude drafts translations)
artifacts/nia-service/src/index.ts                       MODIFIED — mounts the new route

artifacts/pay-it-forward/src/pages/globe.tsx             MODIFIED — fetches GET /griot/hubs instead of a hardcoded 10-city array; shows live activity stats + story counts per hub; loading/error/empty states for the hub grid
```

## Before deploying
1. Run the migration against a non-prod DB first — it's idempotent
   (`IF NOT EXISTS` / `ON CONFLICT` throughout) but always worth a dry run.
2. `transcribeAudio()` in `griot-transcription-worker.ts` is an intentional
   stub — Claude's API doesn't accept raw audio. Audio-based stories will
   enqueue and fail loudly with a clear error until you wire in a real
   speech-to-text provider (Whisper / AssemblyAI / Deepgram). Text-typed
   stories and the gratitude-promotion path work end-to-end today.
3. `globe.tsx` now depends on `GET /griot/hubs` responding — if the
   api-server routes/migration aren't deployed yet, the hub grid will show
   its "couldn't load hubs, tap to retry" state (handled gracefully, not a
   crash) until they are.

## New endpoints
- `GET  /griot/hubs` — public, live activity data for claimed hubs
- `POST /griot/hubs` — propose a new hub (auth required, pending_review)
- `PATCH /griot/hubs/:id/claim` — admin: attach a community to a hub
- `POST /admin/griot/hubs/:id/review` — admin: approve/reject a proposed hub
- `POST /gratitude/:id/promote-to-story` — turn a thank-you into a Griot story

## globe.tsx changes, specifically
- `Hub` type now matches the API shape (numeric `id`, `region` mapped from
  `region_label`, plus `story_count`/`activity`/`community_id`); the old
  `color`/`bg` Tailwind-class fields are gone since the server can't sensibly
  emit Tailwind classes — tag→color is now a client-side hex lookup
  (`HUB_COLORS`) applied via inline `style`, same visual result.
- The old `hub.id === "ftw"` special-case (home hub gets a pulse ring +
  bigger marker) is now `hub.tag === "home"`, since ids are DB-generated
  numbers now, not fixed city-code strings.
- Arcs are computed with `useMemo(() => buildArcs(hubs), [hubs])` once hubs
  have loaded, anchored to whichever hub has `tag === "home"` (falls back to
  a fixed Fort Worth coordinate if that hasn't loaded yet, purely so arcs
  don't visually snap once it does).
- The hub picker grid has real loading (skeleton), error (retry button), and
  empty states — it's a network call now, not a static array.
- The hub detail panel shows live `active_helpers` / `requests_fulfilled` /
  `pool_balance` when a community has claimed the hub, or a story count
  otherwise — this is the piece that turns the globe from decoration into a
  map of where the help network is actually active.

