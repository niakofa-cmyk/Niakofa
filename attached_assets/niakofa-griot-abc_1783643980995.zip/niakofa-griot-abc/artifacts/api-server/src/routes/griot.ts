/**
 * Griot Stories — oral history / diaspora storytelling
 *
 * Endpoints:
 *  GET  /griot/stories             — published stories (public feed)
 *  GET  /griot/stories/mine        — caller's own stories (all statuses)
 *  POST /griot/stories             — create a new story (auth required)
 *  GET  /griot/stories/:id         — single story detail
 *  PATCH /griot/stories/:id        — update title/visibility/release_at (author only)
 *  POST /griot/stories/:id/publish — set status = published (author only)
 *
 *  GET  /griot/stories/:id/translations       — list translations for a story
 *  POST /griot/stories/:id/translations       — add/upsert a translation
 *  PATCH /griot/stories/:id/translations/:lang/approve — recorder approves translation
 */

import { Router } from "express";
import { db, griotStoriesTable, storyTranslationsTable, griotTranscriptionJobsTable, diasporaHubsTable, usersTable, requestsTable, communityPoolLedgerTable, reportsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import { requireAdmin } from "../middlewares/authz";
import { generalApiLimiter } from "../middlewares/rate-limit";
import { eq, and, desc, sql } from "drizzle-orm";
import { z } from "zod";
import { moderatePostText } from "../lib/post-moderation";
import { broadcast } from "../lib/ws-hub";
import { logger } from "../lib/logger";

const router = Router();

// ── Validation schemas ─────────────────────────────────────────────────────

const CreateStorySchema = z.object({
  title:             z.string().max(200).optional(),
  prompt:            z.string().max(500).optional(),
  text_content:      z.string().max(20000).optional(),
  audio_url:         z.string().url().optional(),
  original_language: z.string().max(10).default("en"),
  diaspora_tag:      z.string().max(100).optional(),
  hub_location:      z.string().max(200).optional(),
  lat:               z.number().min(-90).max(90).optional(),
  lng:               z.number().min(-180).max(180).optional(),
  visibility:        z.enum(["public", "diaspora_tag", "private"]).default("public"),
  release_at:        z.string().datetime().optional(),
  duration_seconds:  z.number().int().min(0).max(7200).optional(),
});

const UpdateStorySchema = z.object({
  title:       z.string().max(200).optional(),
  visibility:  z.enum(["public", "diaspora_tag", "private"]).optional(),
  release_at:  z.string().datetime().nullable().optional(),
  hub_location: z.string().max(200).optional(),
  diaspora_tag: z.string().max(100).optional(),
});

const UpsertTranslationSchema = z.object({
  language:       z.string().min(2).max(10),
  nia_draft_text: z.string().max(20000).optional(),
  edited_text:    z.string().max(20000).optional(),
});

// ── GET /griot/stories — public published feed ─────────────────────────────

router.get("/griot/stories", generalApiLimiter, async (req, res) => {
  const hubLocation = req.query.hub as string | undefined;
  const diasporaTag = req.query.tag as string | undefined;
  const limit = Math.min(Number(req.query.limit ?? 20), 50);
  const offset = Number(req.query.offset ?? 0);

  // Public feed: only published AND public-visibility stories
  const conditions = [
    eq(griotStoriesTable.status, "published"),
    eq(griotStoriesTable.visibility, "public"),
  ];
  if (hubLocation) conditions.push(eq(griotStoriesTable.hub_location, hubLocation));
  if (diasporaTag) conditions.push(eq(griotStoriesTable.diaspora_tag, diasporaTag));

  const stories = await db
    .select({
      id:                griotStoriesTable.id,
      author_id:         griotStoriesTable.author_id,
      title:             griotStoriesTable.title,
      text_content:      griotStoriesTable.text_content,
      audio_url:         griotStoriesTable.audio_url,
      original_language: griotStoriesTable.original_language,
      diaspora_tag:      griotStoriesTable.diaspora_tag,
      hub_location:      griotStoriesTable.hub_location,
      lat:               griotStoriesTable.lat,
      lng:               griotStoriesTable.lng,
      visibility:        griotStoriesTable.visibility,
      duration_seconds:  griotStoriesTable.duration_seconds,
      published_at:      griotStoriesTable.published_at,
    })
    .from(griotStoriesTable)
    .where(and(...conditions))
    .orderBy(desc(griotStoriesTable.published_at))
    .limit(limit)
    .offset(offset);

  res.json({ stories, limit, offset });
});

// ── GET /griot/stories/mine — caller's own stories ─────────────────────────

router.get("/griot/stories/mine", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const stories = await db
    .select()
    .from(griotStoriesTable)
    .where(eq(griotStoriesTable.author_id, userId))
    .orderBy(desc(griotStoriesTable.created_at));
  res.json({ stories });
});

// ── POST /griot/stories — create a story ──────────────────────────────────

router.post("/griot/stories", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const parsed = CreateStorySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid story data", issues: parsed.error.issues });
    return;
  }
  const data = parsed.data;

  if (data.text_content) {
    const moderation = moderatePostText(data.text_content);
    if (moderation.status === "pending") {
      logger.warn(
        { author_id: userId, reason: moderation.reason },
        "griot: story text flagged by moderation heuristic on creation (will be re-checked at publish time)"
      );
    }
  }

  const [story] = await db
    .insert(griotStoriesTable)
    .values({
      author_id:         userId,
      title:             data.title,
      prompt:            data.prompt,
      text_content:      data.text_content,
      audio_url:         data.audio_url,
      original_language: data.original_language,
      diaspora_tag:      data.diaspora_tag,
      hub_location:      data.hub_location,
      lat:               data.lat,
      lng:               data.lng,
      visibility:        data.visibility,
      release_at:        data.release_at ? new Date(data.release_at) : undefined,
      duration_seconds:  data.duration_seconds,
      status:            "recorded",
    })
    .returning();

  // Enqueue the transcription/translation pipeline whenever there's
  // something for griot-transcription-worker to do — audio needing a
  // transcript, or text already present that just needs translation drafts.
  // A pure metadata-only story (title only, no audio_url/text_content yet)
  // enqueues nothing; the author can trigger this later via a PATCH once
  // they add content.
  if (story.audio_url || story.text_content) {
    await db.insert(griotTranscriptionJobsTable).values({ story_id: story.id });
  }

  res.status(201).json({ story });
});

// ── GET /griot/stories/:id ─────────────────────────────────────────────────

router.get("/griot/stories/:id", generalApiLimiter, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Invalid story id" });
    return;
  }

  const [story] = await db
    .select()
    .from(griotStoriesTable)
    .where(eq(griotStoriesTable.id, id));

  if (!story) {
    res.status(404).json({ error: "Story not found" });
    return;
  }

  // Access control: non-published stories are author-only;
  // published but non-public stories are also author-only
  const callerId = (req as { authenticatedUserId?: number }).authenticatedUserId;
  const isAuthor = story.author_id === callerId;
  if (story.status !== "published" && !isAuthor) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  if (story.status === "published" && story.visibility !== "public" && !isAuthor) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const translations = await db
    .select()
    .from(storyTranslationsTable)
    .where(eq(storyTranslationsTable.story_id, id));

  res.json({ story, translations });
});

// ── PATCH /griot/stories/:id — update (author only) ───────────────────────

router.patch("/griot/stories/:id", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Invalid story id" });
    return;
  }

  const [existing] = await db
    .select({ author_id: griotStoriesTable.author_id })
    .from(griotStoriesTable)
    .where(eq(griotStoriesTable.id, id));

  if (!existing) {
    res.status(404).json({ error: "Story not found" });
    return;
  }
  if (existing.author_id !== userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const parsed = UpdateStorySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid update data", issues: parsed.error.issues });
    return;
  }

  const updates: Partial<typeof griotStoriesTable.$inferInsert> = {
    updated_at: new Date(),
  };
  if (parsed.data.title !== undefined)       updates.title       = parsed.data.title;
  if (parsed.data.visibility !== undefined)  updates.visibility  = parsed.data.visibility;
  if (parsed.data.hub_location !== undefined) updates.hub_location = parsed.data.hub_location;
  if (parsed.data.diaspora_tag !== undefined) updates.diaspora_tag = parsed.data.diaspora_tag;
  if ("release_at" in parsed.data) {
    updates.release_at = parsed.data.release_at ? new Date(parsed.data.release_at!) : null;
  }

  const [updated] = await db
    .update(griotStoriesTable)
    .set(updates)
    .where(eq(griotStoriesTable.id, id))
    .returning();

  res.json({ story: updated });
});

// ── POST /griot/stories/:id/publish — recorder releases story ─────────────

router.post("/griot/stories/:id/publish", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "Invalid story id" });
    return;
  }

  const [existing] = await db
    .select()
    .from(griotStoriesTable)
    .where(eq(griotStoriesTable.id, id));

  if (!existing) { res.status(404).json({ error: "Story not found" }); return; }
  if (existing.author_id !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  const allowedStatuses = ["ready", "pending_review", "recorded"];
  if (!allowedStatuses.includes(existing.status)) {
    res.status(409).json({ error: "Story cannot be published from its current status" });
    return;
  }

  // Re-screen text content at the moment of publish (not just creation) —
  // this is the actual gate against public UGC going live unmoderated.
  // A story with an open, unresolved report against it is also blocked.
  if (existing.text_content) {
    const moderation = moderatePostText(existing.text_content);
    if (moderation.status === "pending") {
      logger.warn(
        { story_id: id, author_id: userId, reason: moderation.reason },
        "griot: publish blocked by moderation heuristic"
      );
      res.status(409).json({
        error: "This story was flagged by our content screen and cannot be published yet. Contact support if you believe this is a mistake.",
      });
      return;
    }
  }

  const [openReport] = await db
    .select({ id: reportsTable.id })
    .from(reportsTable)
    .where(
      and(
        eq(reportsTable.reported_griot_story_id, id),
        sql`${reportsTable.status} IN ('pending', 'under_review')`
      )
    )
    .limit(1);
  if (openReport) {
    res.status(409).json({ error: "This story has an open report and cannot be published until it is resolved" });
    return;
  }

  const now = new Date();
  const releaseAt = existing.release_at;
  if (releaseAt && releaseAt > now) {
    // Scheduled for the future — mark ready but don't publish yet
    const [updated] = await db
      .update(griotStoriesTable)
      .set({ status: "ready", updated_at: now })
      .where(eq(griotStoriesTable.id, id))
      .returning();
    res.json({ story: updated, scheduled: true, release_at: releaseAt });
    return;
  }

  const [updated] = await db
    .update(griotStoriesTable)
    .set({ status: "published", published_at: now, updated_at: now })
    .where(eq(griotStoriesTable.id, id))
    .returning();

  res.json({ story: updated });
});

// ── GET /griot/stories/:id/translations ───────────────────────────────────

router.get("/griot/stories/:id/translations", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid story id" }); return; }

  const [story] = await db
    .select({ author_id: griotStoriesTable.author_id })
    .from(griotStoriesTable)
    .where(eq(griotStoriesTable.id, id));

  if (!story) { res.status(404).json({ error: "Story not found" }); return; }
  if (story.author_id !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  const translations = await db
    .select()
    .from(storyTranslationsTable)
    .where(eq(storyTranslationsTable.story_id, id));

  res.json({ translations });
});

// ── POST /griot/stories/:id/translations — upsert a translation ───────────

router.post("/griot/stories/:id/translations", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid story id" }); return; }

  const [story] = await db
    .select({ author_id: griotStoriesTable.author_id })
    .from(griotStoriesTable)
    .where(eq(griotStoriesTable.id, id));

  if (!story) { res.status(404).json({ error: "Story not found" }); return; }
  if (story.author_id !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  const parsed = UpsertTranslationSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid translation data", issues: parsed.error.issues });
    return;
  }

  const [translation] = await db
    .insert(storyTranslationsTable)
    .values({
      story_id:       id,
      language:       parsed.data.language,
      nia_draft_text: parsed.data.nia_draft_text,
      edited_text:    parsed.data.edited_text,
    })
    .onConflictDoUpdate({
      target: [storyTranslationsTable.story_id, storyTranslationsTable.language],
      set: {
        nia_draft_text: parsed.data.nia_draft_text ?? undefined,
        edited_text:    parsed.data.edited_text ?? undefined,
        was_edited:     parsed.data.edited_text !== undefined ? true : undefined,
        recorder_approved: false, // any new draft resets approval
        updated_at: new Date(),
      },
    })
    .returning();

  res.status(201).json({ translation });
});

// ── PATCH /griot/stories/:id/translations/:lang/approve ───────────────────

router.patch(
  "/griot/stories/:id/translations/:lang/approve",
  requireAuth,
  generalApiLimiter,
  async (req, res) => {
    const userId = req.authenticatedUserId!;
    const id = Number(req.params.id);
    const lang = String(req.params.lang);
    if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid story id" }); return; }

    const [story] = await db
      .select({ author_id: griotStoriesTable.author_id, status: griotStoriesTable.status })
      .from(griotStoriesTable)
      .where(eq(griotStoriesTable.id, id));

    if (!story) { res.status(404).json({ error: "Story not found" }); return; }
    if (story.author_id !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

    const editedText = req.body.edited_text as string | undefined;

    const now = new Date();
    const updateValues: Partial<typeof storyTranslationsTable.$inferInsert> = {
      recorder_approved: true,
      approved_at: now,
      updated_at: now,
    };
    if (editedText !== undefined) {
      updateValues.edited_text = editedText;
      updateValues.was_edited = true;
    }

    const [translation] = await db
      .update(storyTranslationsTable)
      .set(updateValues)
      .where(
        and(
          eq(storyTranslationsTable.story_id, id),
          eq(storyTranslationsTable.language, lang),
        )
      )
      .returning();

    if (!translation) { res.status(404).json({ error: "Translation not found" }); return; }

    // Advance story to pending_review → ready if all existing translations are approved
    if (story.status === "transcribing" || story.status === "pending_review") {
      const allTranslations = await db
        .select({ recorder_approved: storyTranslationsTable.recorder_approved })
        .from(storyTranslationsTable)
        .where(eq(storyTranslationsTable.story_id, id));

      const allApproved = allTranslations.every(t => t.recorder_approved);
      if (allApproved) {
        await db
          .update(griotStoriesTable)
          .set({ status: "ready", updated_at: now })
          .where(eq(griotStoriesTable.id, id));
      }
    }

    res.json({ translation });
  }
);

// ── Diaspora Hubs ────────────────────────────────────────────────────────────
// Replaces the hardcoded 10-city array that used to live in globe.tsx.
// Seed hubs (the original 10) ship via migration 0053 with is_seed=true.

const ProposeHubSchema = z.object({
  name:         z.string().min(2).max(120),
  region_label: z.string().min(2).max(200),
  lat:          z.number().min(-90).max(90),
  lng:          z.number().min(-180).max(180),
  tag:          z.string().max(20).default("us"),
  note:         z.string().max(500).optional(),
});

const ClaimHubSchema = z.object({
  community_id: z.number(),
});

const ReviewHubSchema = z.object({
  decision: z.enum(["approved", "rejected"]),
});

// GET /griot/hubs — public. Every approved hub, enriched with a published
// story count and, for hubs a community has claimed, the same live activity
// numbers /impact/:county shows (active helpers, requests fulfilled, pool
// balance) — this is what turns the globe from "10 static pins with lore"
// into a map of where the actual help network is active.
router.get("/griot/hubs", generalApiLimiter, async (_req, res) => {
  const hubs = await db
    .select()
    .from(diasporaHubsTable)
    .where(eq(diasporaHubsTable.status, "approved"))
    .orderBy(desc(diasporaHubsTable.is_seed));

  const enriched = await Promise.all(
    hubs.map(async (hub) => {
      const [storyCountRow] = await db
        .select({ count: sql<number>`COUNT(*)::int` })
        .from(griotStoriesTable)
        .where(and(eq(griotStoriesTable.hub_id, hub.id), eq(griotStoriesTable.status, "published")));

      let activity: { active_helpers: number; requests_fulfilled: number; pool_balance: number } | null = null;

      if (hub.community_id) {
        const [helperRow, requestRow, poolRow] = await Promise.all([
          db
            .select({ count: sql<number>`COUNT(*)::int` })
            .from(usersTable)
            .where(and(eq(usersTable.community_id, hub.community_id), eq(usersTable.helper_mode_active, true))),
          db
            .select({ count: sql<number>`COUNT(*)::int` })
            .from(requestsTable)
            .where(sql`${requestsTable.status} = 'completed'
              AND ${requestsTable.requester_id} IN (SELECT id FROM users WHERE community_id = ${hub.community_id})`),
          db
            .select({ balance: sql<number>`COALESCE(SUM(${communityPoolLedgerTable.amount}), 0)::float8` })
            .from(communityPoolLedgerTable)
            .where(eq(communityPoolLedgerTable.community_id, hub.community_id)),
        ]);

        activity = {
          active_helpers: helperRow[0]?.count ?? 0,
          requests_fulfilled: requestRow[0]?.count ?? 0,
          pool_balance: poolRow[0]?.balance ?? 0,
        };
      }

      return { ...hub, story_count: storyCountRow?.count ?? 0, activity };
    })
  );

  res.json({ hubs: enriched });
});

// POST /griot/hubs — propose a new hub (any authenticated user). Goes to
// pending_review, same governance pattern as story publish/gov-sponsor
// approval — an admin has to approve it before it shows on the public globe.
router.post("/griot/hubs", requireAuth, generalApiLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;
  const parsed = ProposeHubSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid hub data", issues: parsed.error.issues });
    return;
  }

  try {
    const [hub] = await db
      .insert(diasporaHubsTable)
      .values({ ...parsed.data, created_by: userId, status: "pending_review", is_seed: false })
      .returning();
    res.status(201).json({ hub });
  } catch (err: unknown) {
    // UNIQUE(name) — a duplicate proposal is a friendly 409, not a 500.
    if ((err as { code?: string })?.code === "23505") {
      res.status(409).json({ error: "A hub with this name already exists or is pending review" });
      return;
    }
    throw err;
  }
});

// PATCH /griot/hubs/:id/claim — attach a real Niakofa community to an
// existing hub (admin only for now — no community-scoped admin role exists
// yet, see requireOwnership/requireAdmin in middlewares/authz.ts). Claiming
// is what lights up the `activity` block in GET /griot/hubs for that hub.
router.patch("/griot/hubs/:id/claim", requireAuth, requireAdmin(), generalApiLimiter, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid hub id" }); return; }

  const parsed = ClaimHubSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid claim data", issues: parsed.error.issues });
    return;
  }

  const [hub] = await db
    .update(diasporaHubsTable)
    .set({ community_id: parsed.data.community_id, updated_at: new Date() })
    .where(eq(diasporaHubsTable.id, id))
    .returning();

  if (!hub) { res.status(404).json({ error: "Hub not found" }); return; }
  res.json({ hub });
});

// POST /admin/griot/hubs/:id/review — approve or reject a proposed hub.
router.post("/admin/griot/hubs/:id/review", requireAuth, requireAdmin(), generalApiLimiter, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid hub id" }); return; }

  const parsed = ReviewHubSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid review decision", issues: parsed.error.issues });
    return;
  }

  const [hub] = await db
    .update(diasporaHubsTable)
    .set({ status: parsed.data.decision, updated_at: new Date() })
    .where(eq(diasporaHubsTable.id, id))
    .returning();

  if (!hub) { res.status(404).json({ error: "Hub not found" }); return; }
  res.json({ hub });
});

export default router;
