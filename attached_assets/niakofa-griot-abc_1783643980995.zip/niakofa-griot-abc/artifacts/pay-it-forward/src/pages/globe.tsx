/**
 * Diaspora Globe — African diaspora connection map + Griot story layer
 *
 * Uses Mapbox GL JS globe projection (already available via react-map-gl/mapbox).
 * Hub cities are rendered as colored markers; great-circle arcs connect them
 * back to Fort Worth (the home base). Griot stories layer overlays story pins.
 */

import React, { useState, useRef, useCallback, useEffect, useMemo } from "react";
import Map, { Marker, Source, Layer, type MapRef } from "react-map-gl/mapbox";
import "mapbox-gl/dist/mapbox-gl.css";
import type mapboxgl from "mapbox-gl";
import { motion, AnimatePresence } from "framer-motion";
import {
  Globe2, Mic, MicOff, BookOpen, X, ChevronLeft, ChevronDown,
  ChevronUp, Check, Globe, MapPin, Clock, Languages, Play, Square,
  Send, ArrowLeft, Lock, Eye, Calendar, Flag,
} from "lucide-react";
import { useAppContext } from "@/lib/AppContext";
import { authHeaders } from "@/lib/auth";
import { toast } from "@/hooks/use-toast";
import { useTranslation } from "react-i18next";

// ── Diaspora hub definitions ───────────────────────────────────────────────
// Hubs used to be a hardcoded 10-city array. They now come from
// GET /griot/hubs (see fetchHubs below), which returns the original 10 as
// seed rows plus anything since proposed/approved, each enriched with a
// live story_count and — for hubs a community has claimed — real activity
// numbers (active helpers, requests fulfilled, pool balance).

type HubTag = "home" | "us" | "carib" | "latino" | "africa" | "europe" | string;

interface HubActivity {
  active_helpers: number;
  requests_fulfilled: number;
  pool_balance: number;
}

interface Hub {
  id: number;
  name: string;
  region: string; // mapped from the API's region_label
  lat: number;
  lng: number;
  tag: HubTag;
  note: string | null;
  community_id: number | null;
  story_count: number;
  activity: HubActivity | null;
}

const TAG_LABEL: Record<string, string> = {
  home: "Home base", us: "US hub", carib: "Caribbean", latino: "Afro-Latino", africa: "Continental Africa", europe: "Afro-European",
};

const HUB_COLORS: Record<string, string> = {
  home: "#f59e0b", us: "#f87171", carib: "#2dd4bf",
  latino: "#4ade80", africa: "#c084fc", europe: "#60a5fa",
};
const DEFAULT_HUB_COLOR = "#94a3b8"; // slate — for any tag proposed hubs introduce later

// Safety net only: used to anchor arcs if, for some reason, no hub tagged
// "home" has loaded yet (e.g. mid-request). Not shown as a marker itself.
const FALLBACK_HOME = { lat: 32.75, lng: -97.33 };

// ── Story types ────────────────────────────────────────────────────────────

interface GriotStory {
  id: number;
  author_id: number;
  title: string | null;
  text_content: string | null;
  audio_url: string | null;
  original_language: string;
  diaspora_tag: string | null;
  hub_location: string | null;
  lat: number | null;
  lng: number | null;
  visibility: string;
  duration_seconds: number | null;
  published_at: string | null;
}

interface StoryTranslation {
  id: number;
  story_id: number;
  language: string;
  nia_draft_text: string | null;
  edited_text: string | null;
  recorder_approved: boolean;
  approved_at: string | null;
}

// ── Globe layer config ─────────────────────────────────────────────────────

const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN as string;

// Great-circle arcs from the home hub (tag === "home") to every other hub.
// Falls back to FALLBACK_HOME if no hub is tagged "home" yet (e.g. still
// loading, or a fresh DB before the seed migration's home row exists).
function buildArcs(hubs: Hub[]) {
  const home = hubs.find(h => h.tag === "home") ?? { ...FALLBACK_HOME, id: -1 };
  const features = hubs
    .filter(h => h.tag !== "home")
    .map(h => ({
      type: "Feature" as const,
      geometry: {
        type: "LineString" as const,
        coordinates: [
          [home.lng, home.lat],
          [h.lng, h.lat],
        ],
      },
      properties: { hub: h.id },
    }));
  return { type: "FeatureCollection" as const, features };
}

// ── Translation review sub-panel ──────────────────────────────────────────

function TranslationReviewPanel({
  storyId,
  translations,
  onClose,
  onRefresh,
}: {
  storyId: number;
  translations: StoryTranslation[];
  onClose: () => void;
  onRefresh: () => void;
}) {
  const [selected, setSelected] = useState<StoryTranslation | null>(null);
  const [editedText, setEditedText] = useState("");
  const [saving, setSaving] = useState(false);

  const pendingCount = translations.filter(t => !t.recorder_approved).length;

  const approve = async (lang: string, edited?: string) => {
    setSaving(true);
    try {
      const body: Record<string, string> = {};
      if (edited) body.edited_text = edited;
      await fetch(`/api/griot/stories/${storyId}/translations/${lang}/approve`, {
        method: "PATCH",
        headers: { ...authHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      toast({ title: "Translation approved ✓" });
      onRefresh();
      setSelected(null);
    } catch {
      toast({ title: "Failed to approve", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const langLabel: Record<string, string> = {
    pt: "Português", es: "Español", fr: "Français", ht: "Kreyòl",
    sw: "Kiswahili", yo: "Yorùbá", ar: "العربية", de: "Deutsch",
    zh: "中文",
  };

  if (selected) {
    return (
      <div className="space-y-3">
        <button
          onClick={() => setSelected(null)}
          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-3 h-3" /> Back to inbox
        </button>

        <div>
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Your original · {selected.language.toUpperCase()}</p>
          <div className="bg-muted/40 rounded-xl p-3 text-[13px] leading-relaxed font-serif italic text-foreground/80">
            {/* Placeholder: real app would show the original text */}
            &ldquo;[Original story — language: {selected.language.toUpperCase()}]&rdquo;
          </div>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1 flex items-center gap-2">
            Nia&apos;s draft · {langLabel[selected.language] ?? selected.language}
            <span className="normal-case tracking-normal bg-muted rounded-full px-2 py-0.5 text-[10px]">
              Pending review
            </span>
          </p>
          <textarea
            value={editedText || selected.nia_draft_text || ""}
            onChange={e => setEditedText(e.target.value)}
            rows={5}
            className="w-full bg-muted/40 border border-border rounded-xl p-3 text-[13px] leading-relaxed resize-none focus:outline-none focus:ring-1 focus:ring-primary font-serif"
            placeholder="Nia's translation will appear here..."
            style={{ fontSize: "16px" }}
          />
          <p className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
            <Globe className="w-3 h-3" /> Publishes publicly once you approve
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => approve(selected.language, editedText || undefined)}
            disabled={saving}
            className="flex-1 flex items-center justify-center gap-1.5 bg-green-500/10 border border-green-500/30 text-green-400 rounded-xl py-2.5 text-[13px] font-bold hover:bg-green-500/20 transition-colors disabled:opacity-50"
          >
            <Check className="w-4 h-4" /> Looks right — approve
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        {pendingCount > 0 ? `${pendingCount} translation${pendingCount !== 1 ? "s" : ""} waiting for your review` : "All translations reviewed ✓"}
      </p>
      {translations.map(t => (
        <button
          key={t.id}
          onClick={() => { setSelected(t); setEditedText(""); }}
          className="w-full flex items-center justify-between p-3 bg-muted/40 border border-border rounded-xl text-left hover:bg-muted/60 transition-colors"
        >
          <div>
            <p className="text-[13px] font-medium">{t.recorder_approved ? "✓ " : ""}{langLabel[t.language] ?? t.language}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {t.recorder_approved ? "Approved" : "Pending review"}
            </p>
          </div>
          <span className={`text-[11px] px-2 py-0.5 rounded-full ${t.recorder_approved ? "bg-green-500/10 text-green-400" : "bg-amber-500/10 text-amber-400"}`}>
            {t.recorder_approved ? "Done" : "Review"}
          </span>
        </button>
      ))}
      <button
        onClick={onClose}
        className="w-full text-[12px] text-muted-foreground hover:text-foreground py-2 transition-colors"
      >
        Close
      </button>
    </div>
  );
}

// ── Griot story card ───────────────────────────────────────────────────────

function GriotStoryCard({ story }: { story: GriotStory }) {
  const { currentUser } = useAppContext();
  const [expanded, setExpanded] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [reporting, setReporting] = useState(false);
  const [reportSent, setReportSent] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const total = story.duration_seconds ?? 120;

  const submitReport = async () => {
    if (!currentUser || reportReason.trim().length < 10) {
      toast({ title: "Please describe the issue in at least 10 characters", variant: "destructive" });
      return;
    }
    try {
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { ...authHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify({
          reporter_id: currentUser.id,
          reported_griot_story_id: story.id,
          type: "other",
          description: reportReason.trim(),
        }),
      });
      if (!res.ok) throw new Error("failed");
      setReportSent(true);
      setReporting(false);
      toast({ title: "Report submitted — an admin will review this story" });
    } catch {
      toast({ title: "Couldn't submit report, try again", variant: "destructive" });
    }
  };

  const togglePlay = () => {
    if (playing) {
      clearInterval(timerRef.current!);
      setPlaying(false);
    } else {
      setPlaying(true);
      timerRef.current = setInterval(() => {
        setElapsed(e => {
          if (e >= total - 1) {
            clearInterval(timerRef.current!);
            setPlaying(false);
            return 0;
          }
          return e + 1;
        });
      }, 1000);
    }
  };

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const LANG_NAMES: Record<string, string> = {
    en: "English", es: "Español", fr: "Français", pt: "Português",
    ht: "Kreyòl", sw: "Kiswahili", yo: "Yorùbá", ar: "العربية",
  };

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      <button
        className="w-full text-left p-4 flex items-start gap-3"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
          <BookOpen className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-[14px] leading-snug line-clamp-2">
            {story.title ?? "Untitled story"}
          </p>
          <p className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1.5">
            <MapPin className="w-3 h-3" />
            {story.hub_location ?? "Diaspora community"}
            <span className="ml-1 px-1.5 py-0 bg-muted rounded-full">
              {LANG_NAMES[story.original_language] ?? story.original_language}
            </span>
          </p>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-3">
              {/* Audio player */}
              {story.audio_url && (
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlay}
                    className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0"
                    aria-label={playing ? "Pause" : "Play"}
                  >
                    {playing ? <Square className="w-4 h-4 text-primary-foreground fill-primary-foreground" /> : <Play className="w-4 h-4 text-primary-foreground fill-primary-foreground ml-0.5" />}
                  </button>
                  {/* Waveform bars */}
                  <div className="flex-1 flex items-center gap-[2px] h-8">
                    {Array.from({ length: 30 }, (_, i) => {
                      const h = [8,14,10,20,16,24,12,18,9,15,22,11,19,13,17,10,21,14,8,16,12,20,9,18,15,11,23,13,17,10][i];
                      const active = i < Math.floor((elapsed / total) * 30);
                      return (
                        <div
                          key={i}
                          className={`rounded-sm flex-shrink-0 transition-colors ${active ? "bg-primary" : "bg-border"}`}
                          style={{ width: 3, height: h }}
                        />
                      );
                    })}
                  </div>
                  <span className="text-[11px] text-muted-foreground font-mono min-w-[36px] text-right">
                    {playing ? fmt(elapsed) : fmt(total)}
                  </span>
                </div>
              )}

              {/* Text content */}
              {story.text_content && (
                <p className="text-[13px] leading-relaxed text-foreground/80 font-serif italic">
                  &ldquo;{story.text_content}&rdquo;
                </p>
              )}

              {story.diaspora_tag && (
                <p className="text-[11px] text-muted-foreground">
                  Tagged: <span className="text-primary">{story.diaspora_tag}</span>
                </p>
              )}

              <div className="pt-1 border-t border-border/60">
                {reportSent ? (
                  <p className="text-[11px] text-muted-foreground pt-2">Report submitted. Thank you for helping keep Niakofa safe.</p>
                ) : reporting ? (
                  <div className="pt-2 space-y-2">
                    <textarea
                      value={reportReason}
                      onChange={e => setReportReason(e.target.value)}
                      rows={2}
                      placeholder="What's wrong with this story? (min 10 characters)"
                      className="w-full bg-muted/40 border border-border rounded-lg p-2 text-[12px] resize-none focus:outline-none focus:ring-1 focus:ring-primary"
                      style={{ fontSize: "16px" }}
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={submitReport}
                        className="flex-1 bg-destructive/10 border border-destructive/30 text-destructive rounded-lg py-1.5 text-[12px] font-bold hover:bg-destructive/20 transition-colors"
                      >
                        Submit report
                      </button>
                      <button
                        onClick={() => { setReporting(false); setReportReason(""); }}
                        className="px-3 rounded-lg text-[12px] text-muted-foreground hover:text-foreground transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setReporting(true)}
                    className="flex items-center gap-1 text-[11px] text-muted-foreground hover:text-destructive transition-colors pt-2"
                  >
                    <Flag className="w-3 h-3" /> Report this story
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Record new story panel ─────────────────────────────────────────────────

type RecordMode = "voice" | "text";
type RecordStep = "compose" | "review" | "release";
const DAILY_PROMPTS = [
  "What's a name, place, or memory you want the next generation to know?",
  "Describe a tradition in your family that comes from your ancestors.",
  "Tell us about a food, song, or practice tied to your heritage.",
  "Who was an elder who shaped who you are?",
  "What language or words do you wish the next generation would keep?",
];

function RecordStoryPanel({
  selectedHub,
  onClose,
  onSaved,
}: {
  selectedHub: Hub | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [mode, setMode] = useState<RecordMode>("voice");
  const [step, setStep] = useState<RecordStep>("compose");
  const [recording, setRecording] = useState(false);
  const [recSeconds, setRecSeconds] = useState(0);
  const [textContent, setTextContent] = useState("");
  const [title, setTitle] = useState("");
  const [visibility, setVisibility] = useState<"public" | "diaspora_tag" | "private">("public");
  const [saving, setSaving] = useState(false);
  const recTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const prompt = DAILY_PROMPTS[new Date().getDate() % DAILY_PROMPTS.length];
  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  const toggleRecording = () => {
    if (recording) {
      clearInterval(recTimerRef.current!);
      setRecording(false);
    } else {
      setRecording(true);
      recTimerRef.current = setInterval(() => setRecSeconds(s => s + 1), 1000);
    }
  };

  const saveStory = async () => {
    if (!textContent.trim() && recSeconds === 0) {
      toast({ title: "Add a story first", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        title: title || prompt.slice(0, 80),
        text_content: textContent || undefined,
        visibility,
        hub_location: selectedHub?.name,
        lat: selectedHub?.lat,
        lng: selectedHub?.lng,
        diaspora_tag: selectedHub?.tag,
        duration_seconds: recSeconds > 0 ? recSeconds : undefined,
        original_language: "en",
      };

      const res = await fetch("/api/griot/stories", {
        method: "POST",
        headers: { ...authHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error(await res.text());
      toast({ title: "Story saved! Nia will transcribe and translate it shortly." });
      onSaved();
    } catch {
      toast({ title: "Failed to save story", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (step === "release") {
    return (
      <div className="space-y-4">
        <p className="text-[13px] text-muted-foreground leading-relaxed">
          Your story is saved. Nia will transcribe and translate it automatically. 
          You&apos;ll review the translations before it goes public.
        </p>

        <div className="space-y-2">
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Visibility</p>
          {(["public", "diaspora_tag", "private"] as const).map(v => (
            <button
              key={v}
              onClick={() => setVisibility(v)}
              className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-colors ${
                visibility === v ? "border-primary bg-primary/10" : "border-border bg-muted/30 hover:bg-muted/50"
              }`}
            >
              <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${visibility === v ? "border-primary" : "border-muted-foreground"}`}>
                {visibility === v && <div className="w-2 h-2 rounded-full bg-primary" />}
              </div>
              <div>
                <p className="text-[13px] font-medium">
                  {v === "public" ? "🌍 Public to globe" : v === "diaspora_tag" ? "🏷️ Diaspora tag only" : "🔒 Private (just me)"}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {v === "public" ? "Anyone on the Diaspora Globe can find it" :
                   v === "diaspora_tag" ? "Only people with your heritage tag" :
                   "Only you can see this story"}
                </p>
              </div>
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setStep("compose")}
            className="flex-1 py-2.5 rounded-xl border border-border text-[13px] font-bold text-muted-foreground hover:text-foreground transition-colors"
          >
            Back
          </button>
          <button
            onClick={saveStory}
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-[13px] font-bold hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {saving ? "Saving…" : "Save story ↗"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Daily prompt */}
      <div>
        <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-1">Today&apos;s prompt</p>
        <p className="text-[14px] font-bold leading-snug font-serif">{prompt}</p>
      </div>

      {/* Optional title */}
      <input
        type="text"
        placeholder="Give your story a title (optional)"
        value={title}
        onChange={e => setTitle(e.target.value)}
        className="w-full bg-muted/40 border border-border rounded-xl px-3 py-2 text-[14px] focus:outline-none focus:ring-1 focus:ring-primary"
        style={{ fontSize: "16px" }}
      />

      {/* Mode toggle */}
      <div className="flex gap-2">
        {(["voice", "text"] as const).map(m => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-[13px] font-bold transition-all ${
              mode === m ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {m === "voice" ? <Mic className="w-4 h-4" /> : <BookOpen className="w-4 h-4" />}
            {m === "voice" ? "Voice" : "Text"}
          </button>
        ))}
      </div>

      {/* Voice recording */}
      {mode === "voice" && (
        <div className="flex flex-col items-center py-4 gap-3">
          <button
            onClick={toggleRecording}
            aria-label={recording ? "Stop recording" : "Start recording"}
            className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
              recording
                ? "bg-red-500/20 border-2 border-red-500 animate-pulse"
                : "bg-muted/40 border-2 border-border hover:border-primary"
            }`}
          >
            {recording
              ? <MicOff className="w-7 h-7 text-red-400" />
              : <Mic className="w-7 h-7 text-primary" />}
          </button>
          <p className="text-[12px] text-muted-foreground">
            {recording ? "Recording…" : "Tap to start"}
          </p>
          {(recording || recSeconds > 0) && (
            <p className="text-xl font-mono text-primary">{fmt(recSeconds)}</p>
          )}
        </div>
      )}

      {/* Text input */}
      {mode === "text" && (
        <textarea
          value={textContent}
          onChange={e => setTextContent(e.target.value)}
          rows={5}
          placeholder="Write the story here, in whatever language feels most natural…"
          className="w-full bg-muted/40 border border-border rounded-xl p-3 text-[14px] leading-relaxed resize-none focus:outline-none focus:ring-1 focus:ring-primary font-serif"
          style={{ fontSize: "16px" }}
        />
      )}

      {/* Privacy note + next */}
      <div className="flex items-center justify-between">
        <p className="text-[11px] text-muted-foreground flex items-center gap-1">
          <Lock className="w-3 h-3" /> Public by default, opt-out available
        </p>
        <button
          onClick={() => setStep("release")}
          disabled={(mode === "text" && !textContent.trim()) || (mode === "voice" && recSeconds === 0)}
          className="flex items-center gap-1 bg-primary text-primary-foreground rounded-xl px-4 py-2 text-[13px] font-bold hover:opacity-90 transition-opacity disabled:opacity-40"
        >
          Next <Send className="w-3 h-3" />
        </button>
      </div>

      <p className="text-[11px] text-muted-foreground text-center leading-relaxed">
        Nia will automatically transcribe and translate your story.
        You&apos;ll review translations before they go live.
      </p>
    </div>
  );
}

// ── Main globe view ────────────────────────────────────────────────────────

type GlobeLayer = "hubs" | "stories" | "arcs";
type GlobePanel = "hub" | "stories_feed" | "record" | "translations" | null;

export default function GlobePage() {
  const { currentUser } = useAppContext();
  const [activeHub, setActiveHub] = useState<Hub | null>(null);
  const [panel, setPanel] = useState<GlobePanel>(null);
  const [enabledLayers, setEnabledLayers] = useState<Set<GlobeLayer>>(
    new Set(["hubs", "arcs"])
  );
  const [stories, setStories] = useState<GriotStory[]>([]);
  const [myStories, setMyStories] = useState<GriotStory[]>([]);
  const [myTranslations, setMyTranslations] = useState<StoryTranslation[]>([]);
  const [reviewingStoryId, setReviewingStoryId] = useState<number | null>(null);
  const [storiesLoading, setStoriesLoading] = useState(false);
  const [hubs, setHubs] = useState<Hub[]>([]);
  const [hubsLoading, setHubsLoading] = useState(true);
  const [hubsError, setHubsError] = useState(false);
  const mapRef = useRef<MapRef | null>(null);

  // Map initial view — centered on Atlantic (to show both Americas and Africa)
  const [viewState, setViewState] = useState({
    longitude: -30,
    latitude: 20,
    zoom: 1.5,
    pitch: 15,
    bearing: 0,
  });

  const toggleLayer = (layer: GlobeLayer) => {
    setEnabledLayers(prev => {
      const next = new Set(prev);
      next.has(layer) ? next.delete(layer) : next.add(layer);
      return next;
    });
  };

  const fetchHubs = useCallback(async () => {
    setHubsLoading(true);
    setHubsError(false);
    try {
      const res = await fetch("/api/griot/hubs");
      if (!res.ok) throw new Error(`${res.status}`);
      const data = await res.json() as {
        hubs: Array<{
          id: number; name: string; region_label: string; lat: number; lng: number;
          tag: string; note: string | null; community_id: number | null;
          story_count: number; activity: HubActivity | null;
        }>;
      };
      setHubs(data.hubs.map(h => ({
        id: h.id,
        name: h.name,
        region: h.region_label,
        lat: h.lat,
        lng: h.lng,
        tag: h.tag,
        note: h.note,
        community_id: h.community_id,
        story_count: h.story_count,
        activity: h.activity,
      })));
    } catch {
      setHubsError(true);
    } finally {
      setHubsLoading(false);
    }
  }, []);

  const fetchStories = useCallback(async (hubLocation?: string) => {
    setStoriesLoading(true);
    try {
      const params = new URLSearchParams({ limit: "20" });
      if (hubLocation) params.set("hub", hubLocation);
      const res = await fetch(`/api/griot/stories?${params}`);
      if (res.ok) {
        const data = await res.json() as { stories: GriotStory[] };
        setStories(data.stories);
      }
    } finally {
      setStoriesLoading(false);
    }
  }, []);

  const fetchMyTranslations = useCallback(async (storyId?: number) => {
    if (!currentUser) return;
    try {
      // Fetch the caller's own stories first
      const storiesRes = await fetch("/api/griot/stories/mine", {
        headers: authHeaders(),
      });
      if (!storiesRes.ok) return;
      const storiesData = await storiesRes.json() as { stories: GriotStory[] };
      setMyStories(storiesData.stories);

      // If a specific story was requested, fetch its translations
      const targetId = storyId ?? storiesData.stories[0]?.id;
      if (targetId) {
        const transRes = await fetch(`/api/griot/stories/${targetId}/translations`, {
          headers: authHeaders(),
        });
        if (transRes.ok) {
          const transData = await transRes.json() as { translations: StoryTranslation[] };
          setMyTranslations(transData.translations);
          setReviewingStoryId(targetId);
        }
      }
    } catch {
      // silent
    }
  }, [currentUser]);

  useEffect(() => {
    fetchStories();
    fetchHubs();
  }, [fetchStories, fetchHubs]);

  const arcGeojson = useMemo(() => buildArcs(hubs), [hubs]);

  const handleHubClick = (hub: Hub) => {
    setActiveHub(hub);
    setPanel("hub");
    // Fly to the hub
    if (mapRef.current) {
      mapRef.current.flyTo({
        center: [hub.lng, hub.lat],
        zoom: 4,
        duration: 1500,
        essential: true,
      });
    }
  };

  const openStoriesFeed = (hub?: Hub) => {
    const h = hub ?? activeHub;
    setPanel("stories_feed");
    fetchStories(h?.name);
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-card/95 backdrop-blur-xl border-b border-border p-4 pt-safe">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-black uppercase tracking-widest flex items-center gap-2 flex-1">
            <Globe2 className="w-5 h-5 text-primary" /> Diaspora Globe
          </h1>
          {currentUser && (
            <button
              onClick={() => { setPanel("record"); setActiveHub(null); }}
              className="flex items-center gap-1.5 bg-primary/10 border border-primary/30 text-primary rounded-xl px-3 py-1.5 text-[12px] font-bold hover:bg-primary/20 transition-colors"
            >
              <Mic className="w-3.5 h-3.5" /> Record story
            </button>
          )}
        </div>

        {/* Layer toggles */}
        <div className="flex gap-2 mt-3 overflow-x-auto pb-1 -mx-4 px-4 scrollbar-none">
          {(["hubs", "stories", "arcs"] as const).map(layer => (
            <button
              key={layer}
              onClick={() => toggleLayer(layer)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-[11px] font-bold uppercase tracking-wider border transition-all ${
                enabledLayers.has(layer)
                  ? "bg-primary/10 border-primary/40 text-primary"
                  : "bg-muted/50 border-border text-muted-foreground"
              }`}
            >
              {layer === "hubs" ? "🌍 Hubs" : layer === "stories" ? "📖 Stories" : "〰️ Arcs"}
            </button>
          ))}
          <div className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-muted/30 rounded-full text-[11px] text-muted-foreground">
            <Languages className="w-3 h-3" />
            <span>7 languages</span>
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="relative" style={{ height: "55vw", minHeight: 220, maxHeight: 380 }}>
        <Map
          ref={mapRef}
          mapboxAccessToken={MAPBOX_TOKEN}
          {...viewState}
          onMove={e => setViewState(e.viewState)}
          projection={{ name: "globe" }}
          mapStyle="mapbox://styles/mapbox/dark-v11"
          style={{ width: "100%", height: "100%" }}
          fog={{
            color: "rgb(10, 12, 20)",
            "high-color": "rgb(30, 35, 60)",
            "horizon-blend": 0.02,
            "star-intensity": 0.4,
          }}
          scrollZoom={false}
          doubleClickZoom={false}
        >
          {/* Great-circle arcs layer */}
          {enabledLayers.has("arcs") && (
            <Source id="arcs" type="geojson" data={arcGeojson}>
              <Layer
                id="arcs-line"
                type="line"
                paint={{
                  "line-color": "#f59e0b",
                  "line-width": 1,
                  "line-opacity": 0.35,
                  "line-dasharray": [2, 3],
                }}
              />
            </Source>
          )}

          {/* Hub markers */}
          {enabledLayers.has("hubs") && hubs.map(hub => (
            <Marker
              key={hub.id}
              longitude={hub.lng}
              latitude={hub.lat}
              anchor="center"
              onClick={() => handleHubClick(hub)}
            >
              <button
                aria-label={`${hub.name} — ${hub.region}`}
                style={{ touchAction: "manipulation" }}
                className="relative group"
              >
                {/* Pulse ring for home */}
                {hub.tag === "home" && (
                  <span
                    className="absolute inset-0 rounded-full animate-ping"
                    style={{ background: HUB_COLORS[hub.tag] ?? DEFAULT_HUB_COLOR, opacity: 0.3 }}
                  />
                )}
                <span
                  className="relative flex items-center justify-center rounded-full border-2 border-background shadow-lg transition-transform group-active:scale-90"
                  style={{
                    width: hub.tag === "home" ? 18 : 13,
                    height: hub.tag === "home" ? 18 : 13,
                    background: HUB_COLORS[hub.tag] ?? DEFAULT_HUB_COLOR,
                  }}
                />
                {/* Story dot overlay */}
                {enabledLayers.has("stories") && hub.story_count > 0 && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-rose-400 rounded-full border border-background" />
                )}
              </button>
            </Marker>
          ))}
        </Map>

        {/* Zoom controls */}
        <div className="absolute right-3 bottom-3 flex flex-col gap-1.5">
          <button
            onClick={() => setViewState(v => ({ ...v, zoom: Math.min(v.zoom + 0.8, 10) }))}
            className="w-9 h-9 bg-card/90 border border-border rounded-xl flex items-center justify-center text-foreground hover:bg-card transition-colors shadow-lg"
            aria-label="Zoom in"
          >
            <span className="text-lg font-bold leading-none">+</span>
          </button>
          <button
            onClick={() => setViewState(v => ({ ...v, zoom: Math.max(v.zoom - 0.8, 1) }))}
            className="w-9 h-9 bg-card/90 border border-border rounded-xl flex items-center justify-center text-foreground hover:bg-card transition-colors shadow-lg"
            aria-label="Zoom out"
          >
            <span className="text-lg font-bold leading-none">−</span>
          </button>
          <button
            onClick={() => setViewState({ longitude: -30, latitude: 20, zoom: 1.5, pitch: 15, bearing: 0 })}
            className="w-9 h-9 bg-card/90 border border-border rounded-xl flex items-center justify-center text-foreground hover:bg-card transition-colors shadow-lg"
            aria-label="Reset view"
          >
            <Globe2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-3 px-4 py-2 overflow-x-auto scrollbar-none text-[10px] text-muted-foreground">
        {Object.entries(HUB_COLORS).map(([tag, color]) => (
          <div key={tag} className="flex items-center gap-1 shrink-0">
            <span className="w-2 h-2 rounded-full" style={{ background: color }} />
            <span>{TAG_LABEL[tag as HubTag]}</span>
          </div>
        ))}
      </div>

      {/* Panel area */}
      <div className="flex-1 px-4 pb-28 space-y-3 max-w-lg mx-auto w-full">

        {/* Hub detail card */}
        <AnimatePresence mode="wait">
          {panel === "hub" && activeHub && (
            <motion.div
              key="hub-detail"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              className="bg-card border border-border rounded-2xl p-4"
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ background: HUB_COLORS[activeHub.tag] ?? DEFAULT_HUB_COLOR }}
                    />
                    <h2 className="font-black text-[16px]">{activeHub.name}</h2>
                  </div>
                  <p className="text-[12px] text-muted-foreground mt-0.5">{activeHub.region}</p>
                </div>
                <span
                  className="text-[11px] px-2 py-0.5 rounded-full font-bold"
                  style={{
                    color: HUB_COLORS[activeHub.tag] ?? DEFAULT_HUB_COLOR,
                    background: `${HUB_COLORS[activeHub.tag] ?? DEFAULT_HUB_COLOR}20`,
                  }}
                >
                  {TAG_LABEL[activeHub.tag] ?? activeHub.tag}
                </span>
              </div>
              {activeHub.note && (
                <p className="text-[13px] text-foreground/80 leading-relaxed mb-3">{activeHub.note}</p>
              )}

              {/* Live activity — only present once a community has claimed this hub */}
              {activeHub.activity ? (
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <div className="bg-muted/40 rounded-xl p-2 text-center">
                    <p className="text-[15px] font-black">{activeHub.activity.active_helpers}</p>
                    <p className="text-[9px] text-muted-foreground uppercase tracking-wide">Helpers</p>
                  </div>
                  <div className="bg-muted/40 rounded-xl p-2 text-center">
                    <p className="text-[15px] font-black">{activeHub.activity.requests_fulfilled}</p>
                    <p className="text-[9px] text-muted-foreground uppercase tracking-wide">Fulfilled</p>
                  </div>
                  <div className="bg-muted/40 rounded-xl p-2 text-center">
                    <p className="text-[15px] font-black">${activeHub.activity.pool_balance.toFixed(0)}</p>
                    <p className="text-[9px] text-muted-foreground uppercase tracking-wide">Pool</p>
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-muted-foreground mb-3">
                  {activeHub.story_count} {activeHub.story_count === 1 ? "story" : "stories"} shared here
                </p>
              )}

              <div className="flex gap-2">
                <button
                  onClick={() => openStoriesFeed(activeHub)}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-muted/50 border border-border rounded-xl text-[13px] font-bold hover:bg-muted transition-colors"
                >
                  <BookOpen className="w-4 h-4" /> Stories ↗
                </button>
                <button
                  onClick={() => setPanel("record")}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-primary/10 border border-primary/30 text-primary rounded-xl text-[13px] font-bold hover:bg-primary/20 transition-colors"
                >
                  <Mic className="w-4 h-4" /> Record here
                </button>
              </div>
            </motion.div>
          )}

          {/* Stories feed */}
          {panel === "stories_feed" && (
            <motion.div
              key="stories-feed"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              className="space-y-3"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-black text-[15px] flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-primary" />
                  Griot Stories
                  {activeHub && <span className="text-muted-foreground font-normal text-[12px]">· {activeHub.name}</span>}
                </h2>
                <button
                  onClick={() => setPanel(activeHub ? "hub" : null)}
                  className="text-[12px] text-muted-foreground hover:text-foreground flex items-center gap-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" /> Back
                </button>
              </div>

              {storiesLoading ? (
                <div className="text-center py-8 text-muted-foreground text-[13px]">Loading stories…</div>
              ) : stories.length === 0 ? (
                <div className="text-center py-8 space-y-2">
                  <p className="text-muted-foreground text-[13px]">No stories yet for this hub.</p>
                  <button
                    onClick={() => setPanel("record")}
                    className="text-primary text-[13px] font-bold hover:underline"
                  >
                    Be the first to share one ↗
                  </button>
                </div>
              ) : (
                stories.map(s => <GriotStoryCard key={s.id} story={s} />)
              )}
            </motion.div>
          )}

          {/* Record story */}
          {panel === "record" && (
            <motion.div
              key="record-panel"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              className="bg-card border border-border rounded-2xl p-4"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-black text-[15px] flex items-center gap-2">
                  <Mic className="w-4 h-4 text-primary" /> Record a story
                </h2>
                <button onClick={() => setPanel(activeHub ? "hub" : null)} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
              {currentUser ? (
                <RecordStoryPanel
                  selectedHub={activeHub}
                  onClose={() => setPanel(activeHub ? "hub" : null)}
                  onSaved={() => { fetchStories(); setPanel(activeHub ? "hub" : null); }}
                />
              ) : (
                <p className="text-[13px] text-muted-foreground text-center py-4">
                  Sign in to record and share a griot story.
                </p>
              )}
            </motion.div>
          )}

          {/* Translation review */}
          {panel === "translations" && reviewingStoryId && (
            <motion.div
              key="translations-panel"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              className="bg-card border border-border rounded-2xl p-4"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-black text-[15px] flex items-center gap-2">
                  <Languages className="w-4 h-4 text-primary" /> Review Translations
                </h2>
                <button onClick={() => setPanel(null)} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
              <TranslationReviewPanel
                storyId={reviewingStoryId}
                translations={myTranslations}
                onClose={() => setPanel(null)}
                onRefresh={() => fetchMyTranslations()}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Default: hub picker grid when no panel open */}
        {panel === null && (
          <div className="space-y-3">
            <p className="text-[12px] text-muted-foreground uppercase tracking-widest font-bold">Diaspora Hubs</p>

            {hubsLoading && hubs.length === 0 && (
              <div className="grid grid-cols-2 gap-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-16 bg-muted/30 rounded-2xl animate-pulse" />
                ))}
              </div>
            )}

            {!hubsLoading && hubsError && (
              <button
                onClick={fetchHubs}
                className="w-full flex items-center justify-center gap-2 p-3 bg-muted/40 border border-border rounded-2xl text-[12px] text-muted-foreground hover:bg-muted/60 transition-colors"
              >
                Couldn't load hubs — tap to retry
              </button>
            )}

            {!hubsLoading && !hubsError && hubs.length === 0 && (
              <p className="text-[12px] text-muted-foreground py-4 text-center">No hubs yet.</p>
            )}

            {hubs.length > 0 && (
              <div className="grid grid-cols-2 gap-2">
                {hubs.map(hub => (
                  <button
                    key={hub.id}
                    onClick={() => handleHubClick(hub)}
                    className="flex flex-col items-start gap-0.5 p-3 bg-card border border-border rounded-2xl hover:border-primary/40 transition-all text-left active:scale-95"
                    style={{ touchAction: "manipulation" }}
                  >
                    <div className="flex items-center gap-2 w-full">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: HUB_COLORS[hub.tag] ?? DEFAULT_HUB_COLOR }} />
                      <span className="text-[12px] font-black leading-snug truncate">{hub.name}</span>
                    </div>
                    <span className="text-[10px] text-muted-foreground pl-4">{hub.region}</span>
                  </button>
                ))}
              </div>
            )}

            {currentUser && (
              <button
                onClick={() => { fetchMyTranslations(); setPanel("translations"); }}
                className="w-full flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-2xl text-[13px] font-bold hover:bg-amber-500/20 transition-colors"
              >
                <BookOpen className="w-4 h-4" />
                My stories &amp; translations
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
