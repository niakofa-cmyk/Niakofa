import { pgTable, serial, integer, text, boolean, timestamp, doublePrecision, uniqueIndex } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { communitiesTable } from "./communities";

// Diaspora Globe hub cities. The original 10 curated cities ship as
// `is_seed = true` rows (see migration 0053); anything added after that is
// either an admin/community-proposed hub (status="pending_review" until
// approved) or a community claiming one of the seed pins as their own via
// `community_id`.
export const diasporaHubsTable = pgTable("diaspora_hubs", {
  id:           serial("id").primaryKey(),
  name:         text("name").notNull(),
  region_label: text("region_label").notNull(),
  lat:          doublePrecision("lat").notNull(),
  lng:          doublePrecision("lng").notNull(),
  tag:          text("tag").notNull().default("us"), // home|us|carib|latino|africa|europe (loose — UI-driven, not DB-enforced)
  note:         text("note"),
  community_id: integer("community_id").references(() => communitiesTable.id, { onDelete: "set null" }),
  is_seed:      boolean("is_seed").notNull().default(false),
  status:       text("status").notNull().default("approved"), // pending_review | approved | rejected
  created_by:   integer("created_by").references(() => usersTable.id, { onDelete: "set null" }),
  created_at:   timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updated_at:   timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("diaspora_hubs_name_unique").on(t.name),
]);

export type DiasporaHub = typeof diasporaHubsTable.$inferSelect;
export type InsertDiasporaHub = typeof diasporaHubsTable.$inferInsert;
