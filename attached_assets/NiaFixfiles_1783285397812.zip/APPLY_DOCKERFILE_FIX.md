# Fix for recurring nia-service build failure

## What was wrong
Every build of the nia-service Railway service was failing at:
```
[ 7/10] COPY artifacts/nia-service/ ./artifacts/nia-service/
Build Failed: ... failed to calculate checksum of ref ...: "/artifacts/nia-service": not found
```
We ruled out the two most likely causes before landing on this fix:
- **Stale build cache** — ruled out. Bumping the Dockerfile's `CACHE_BUST`
  arg produced a genuinely new cache key (confirmed via the changed ref
  hash in the build log) and it failed identically anyway.
- **Misconfigured Railway "Root Directory"** — ruled out. Confirmed empty
  in Settings → Source.

That leaves a real bug in how Railway's builder resolves a scoped,
per-subdirectory `COPY artifacts/nia-service/ ...` layer inside this
monorepo. The fix is to stop using that pattern.

## What changed
`artifacts/nia-service/Dockerfile` no longer copies just its own
subdirectory. It now copies the entire repo root in one `COPY . .`, which
avoids the buggy code path entirely. A pnpm store cache mount
(`--mount=type=cache`) keeps repeat installs fast despite losing the old
two-stage layer-caching trick.

A root-level `.dockerignore` was added (there wasn't one before) so the
full-repo copy doesn't drag in `node_modules`, `.git`, or the large
`attached_assets` folder.

## How to apply

1. Place the attached `.dockerignore` at your **repo root** (same level as
   `package.json`), if you don't already have one there.
2. Replace `artifacts/nia-service/Dockerfile` with the attached `Dockerfile`.
3. Commit and push both:
```bash
git add .dockerignore artifacts/nia-service/Dockerfile
git commit -m "fix: nia-service Dockerfile COPY was hitting a recurring Railway checksum bug"
git push
```
4. Railway will redeploy nia-service automatically. This build will likely
   be a bit slower the first time (no warm pnpm-store cache yet), but
   should succeed rather than failing at the COPY step.

## If it still fails
If this exact error somehow recurs even after this change, that would
point to something more fundamental in Railway's builder for this project
specifically — at that point I'd suggest trying Railway's "Redeploy without
cache" option (if available on your plan) once against this new Dockerfile,
and if it still fails, contacting Railway support with this build log,
since we'd have ruled out every likely cause on the repo side.
