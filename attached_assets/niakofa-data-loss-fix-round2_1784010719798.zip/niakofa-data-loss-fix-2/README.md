# Data-loss audit — round 2 (INNER JOIN sweep)

Your last build already had the round-1 fix applied correctly (the three
`ON DELETE CASCADE` → `SET NULL`/`RESTRICT` schema changes, plus the
migration, plus two downstream call sites that were already updated to
handle the new nullable columns). Good sign — nothing regressed there.

This round is a different bug **class**, not new schema damage: an
`INNER JOIN` against `users` silently drops the *entire row* from a query's
results if the user it's joined to no longer exists — even though the row
itself is still sitting untouched in the database. To the user it looks
exactly like "data disappeared," but nothing was ever deleted; it's just
excluded from that one query's output.

## What I checked
Every `.innerJoin(usersTable, ...)` in the API routes (7 total), cross-
referenced against every user-referencing column that's actually nullable
(`SET NULL` on delete). Only a nullable column can end up pointing at a
non-existent user, so only those joins are load-bearing bugs — the rest are
inner-joining against columns that still cascade-delete alongside the user,
so no orphan is possible there and no fix is needed.

## Two real hits, both fixed here as patches:

**`audio-circles.ts.patch`** — `audio_circle_sessions.host_id` is now
`SET NULL` (from round 1). The recordings-archive query still used
`INNER JOIN`, so a completed session whose host later deleted their account
would silently vanish from the archive — a direct regression from round 1's
own fix, now closed with `LEFT JOIN`.

**`requests.ts.patch`** — `requests.requester_id` has *no* foreign-key
constraint at all (confirmed — `requests.ts`'s schema defines no
`.references()` on it). Nothing stops it from going stale if a requester's
account is deleted after their request reaches a non-active status (the
account-deletion route only blocks on `ACTIVE_REQUEST_STATUSES`). The admin
hardship/pledge-forgiveness queue used `INNER JOIN` here, so an orphaned
request would silently disappear from that queue. Fixed the same way.

## Apply
From the repo root:
```
patch -p1 < audio-circles.ts.patch
patch -p1 < requests.ts.patch
```
or `git apply audio-circles.ts.patch requests.ts.patch`.

## Not touched, and why that's fine
`audio-circles.ts:56` (participants), `businesses.ts:214` (members),
`griot.ts:732`/`1134` (hub leaders), and `requests.ts:2383` (helper-chain
roster) all also use `INNER JOIN` against `users`, but every column they
join on still cascade-deletes with the user — so the row itself is removed
too, and there's no orphan for the join to silently hide. Leaving those as
`INNER JOIN` is correct as-is.

## The remaining gap worth knowing about
`requests.requester_id` and `requests.helper_id` still have zero FK
enforcement at the database level. Round 1 + this round stop the two
concrete symptoms found so far, but the underlying gap — nothing in the
schema guarantees those columns point at a real user — remains. Adding a
real (nullable, `SET NULL`) FK constraint there is the structural fix; it's
a larger migration since `requests` is a heavily-referenced table, so I
scoped it out of this pass rather than rush it. Flagging it now so it
doesn't get lost.
