# Niakofa Backend Audit Fixes — July 5, 2026

This package contains the fixed versions of 4 files, plus unified diffs, from the P0/P2 findings
in the backend audit. Drop the files into your repo at the matching paths (they mirror the
monorepo structure exactly), or apply the `.diff` files with `git apply`.

## What changed and why

### 1. `artifacts/api-server/src/routes/requests.ts` — 🔴 P0 security fix
Added `requireApproved` (imported alongside the existing `requireAuth`) to four route
handlers that were missing it despite a code comment in `auth.ts` claiming it had already
been added:

- `POST /requests/:id/claim`
- `POST /requests/:id/en-route`
- `POST /requests/:id/arrived`
- `POST /requests/:id/complete`

**Before:** a suspended, banned, or not-yet-approved user could still claim a help request,
mark themselves en route, mark arrival, and complete the task — including sensitive
categories like childcare and senior care.
**After:** all four actions now correctly 403 for suspended/banned accounts and 403 for
accounts still pending approval, matching the same pattern already used correctly in
`stripe.ts`'s Connect onboarding and payout routes.

No other logic in these handlers changed. `requireApproved` was already implemented and
proven correct elsewhere in the codebase — this just wires it into the four routes that were
missing it.

### 2. `artifacts/api-server/src/app.ts` — 🟡 P2 hardening fix
The global Express error handler used to forward `err.message` straight to the client for
every unhandled exception, including raw 500s (e.g. a Postgres constraint-violation message).
Now:
- **5xx (server errors):** client always gets a generic `"An unexpected error occurred"`.
  The real error is still fully logged server-side via `logger.error` — nothing is lost for
  debugging, it's just no longer shown to whoever triggered the request.
- **4xx errors a route deliberately threw with a message** (e.g. the CORS origin-rejection
  error a few lines up in the same file) still show that intentional message, since those are
  written to be client-facing.

### 3. `artifacts/api-server/src/routes/stripe.ts` — cosmetic/log-clarity fix
The Stripe webhook handler's log message said "webhook signature verification skipped" when
`STRIPE_WEBHOOK_SECRET` isn't set — but the code on the very next line actually rejects the
request with `400` and never processes the event. The behavior was always fail-closed and
correct; only the log wording was misleading (it reads like a fail-open path on a quick scan).
Reworded so a future reviewer doesn't have to re-derive that it's safe.

### 4. `artifacts/api-server/src/workers/pledge-worker.ts` — stale comment fix
A comment said pledges auto-default after "90 days outstanding." The actual, currently-running
constant (`PLEDGE_DEFAULT_DAYS` in `scheduler.ts`) is `730` (2 years) — the real behavior
already matches the "even 2 years later" pay-it-forward vision; the comment was just stale
from an earlier version and had drifted out of sync with the code it was describing.

## How to apply

**Option A — copy files directly** (simplest): copy the 4 files in `artifacts/` here over the
matching paths in your repo, then `git add` + commit.

**Option B — apply as patches:** from your repo root:
```bash
git apply patches/requests.ts.diff
git apply patches/app.ts.diff
git apply patches/stripe.ts.diff
git apply patches/pledge-worker.ts.diff
```
(Patches were generated with `diff -u`, standard unified format — `git apply` or plain `patch -p0`
both work.)

## Before you push

- Run your existing test suite (`__tests__/lifecycle.test.ts` and
  `__tests__/integration-lifecycle.test.ts` both exercise the claim/complete flow and are the
  most relevant regression check for the `requests.ts` change).
- No schema/migration changes are needed — these are logic-only fixes to existing, already-
  deployed routes and middleware.
- No new environment variables or dependencies are introduced.
