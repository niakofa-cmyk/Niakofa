# Changed files — drop-in replacements

Paths below are relative to your repo root (`Niakofa-main/`).

## 1. artifacts/pay-it-forward/src/pages/map.tsx
Real bug: the civic-needs and civic-resources queries (community-mode map
data) key on `lat`/`lng`, which changes every time someone pans the map or
uses "search this area." React Query v5 resets a query's `data` to
`undefined` the instant its key changes, unless told to keep the previous
data around — these two queries weren't, so every pan/search flashed the
entire helpers/needs/resources list to empty for a moment before the new
area's data loaded back in. That's real, visible "disappearing data,"
even though nothing was ever actually lost server-side.

Fixed by adding `placeholderData: keepPreviousData` to both queries — the
list now stays showing the previous area's results until the new ones
arrive, instead of blanking in between.

(The helpers/open-requests data on the same screen was already protected
against this, via a local-state buffer that only updates on a genuine
success and holds its last value otherwise — these two civic queries were
consumed directly from React Query's `data` with no equivalent buffer,
which is why they were the one place this could happen.)

## 2. artifacts/pay-it-forward/src/pages/civic-needs.tsx
Smaller version of the same bug class: opening the invoice list for a
civic need wiped the list to empty on any failed fetch, instead of leaving
whatever was already loaded. Fixed to only replace the list on success —
and to correctly clear it when switching to a *different* need (so a
failure there can't leave one need's invoices showing under another need's
modal, which would be worse than an empty list).

## On the database itself
Both of these were frontend caching/display bugs — nothing was ever
actually deleted or lost in the database. I did not find evidence of real
data loss at the DB layer in this pass. If you're seeing something that
looks like true data loss (a record that's gone even after a hard refresh
and re-login, not just a momentary flash), that's a different and more
serious class of bug — tell me exactly what disappeared and I'll trace it
at the database/API level specifically, since this fix addresses the
"flickers empty then comes back" symptom, not "gone for good."

## Verified before packaging
Full monorepo typecheck, full build, and the frontend test suite (19
tests) all pass with these two files in place.
