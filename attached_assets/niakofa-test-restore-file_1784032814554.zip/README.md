# Changed file — drop-in replacement

Path relative to your repo root (`Niakofa-main/`):
`artifacts/api-server/src/__tests__/audio-circles.test.ts`

## What happened
This round's rewrite of this test file (adding coverage for the new
auto-provisioning fix, see below) dropped the 2 regression tests for the
host-refresh grace-period fix from the round before. The actual production
fix in `routes/audio-circles.ts` was untouched and still correct — only
its test coverage disappeared. Restored both tests; all 29 tests in this
file pass against the current implementation.

## Everything else this round needed no changes from me
This was a strong round — found and fixed the more fundamental cause of
"Circles disappear": migration 0064 seeded Audio Circles for Fort Worth
only, as a one-time insert, and nothing else ever created a circle for any
other city. Anyone whose city wasn't literally "Fort Worth" saw "no circles
yet" forever — which reads exactly like "they disappeared" once a user's
real location replaced a fallback. Fixed by making circle creation
self-provisioning on first read (same pattern already used for
neighborhoods), with race-safe `ON CONFLICT DO NOTHING` inserts backed by
two new partial unique indexes. Once a circle is created this way it's a
permanent row, unaffected by refresh, navigation, or logout.

## Verified before packaging
Full monorepo typecheck, full build, and all three test suites — 194 tests
(141 backend + 34 nia-service + 19 frontend) — pass with this file in place.
