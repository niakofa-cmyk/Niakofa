# Changed files — drop-in replacements

Paths below are relative to your repo root (`Niakofa-main/`). Replace each
file at the matching path with the version in this zip.

## 1. artifacts/pay-it-forward/src/components/MapControlsPanel.tsx
Removed the explicit zoom in/out buttons from the right-edge control stack
(now just orientation + recenter — 2 icons instead of 4). Pinch-to-zoom and
double-tap-zoom are already enabled by default on the Map component, so the
buttons were a redundant, always-visible affordance for something already
reachable directly on the map — matches the Uber reference image's leaner
control cluster, and is now the reference design for Helper Mode Map.

## 2. artifacts/pay-it-forward/src/pages/map.tsx
Companion change to #1: removed the now-unused `zoomIn`/`zoomOut`
`useCallback`s and the `onZoomIn`/`onZoomOut` props passed into
`MapControlsPanel` (their only callers were the removed buttons).

## 3. artifacts/nia-service/package.json
Fixed the `test` script's path to the jest binary. It pointed to
`../../node_modules/jest/bin/jest.js` (assuming a hoisted root install that
doesn't exist in this pnpm workspace); jest is actually installed in this
package's own `node_modules`. Without this fix, `pnpm run test` in
nia-service fails with MODULE_NOT_FOUND before running a single test — this
has reverted repeatedly across multiple exports, so it's worth checking
whether whatever's producing these exports is branching from a point before
this line was last fixed.

## 4. artifacts/nia-service/src/__tests__/auth.test.ts
Fixed a genuinely flaky test: "returns valid:false for a tampered
signature" simulated tampering by flipping the *last* character of the
base64url-encoded HMAC-SHA256 signature. That trailing character only
carries 4 real bits (the rest is base64 encoding padding), so roughly 1 in
8–16 runs it would land on a different-looking character that decodes to
the exact same real bits — meaning the "tampered" token wasn't actually
tampered, and correctly verified as valid, which then looked like a test
failure. Fixed by flipping the *first* character instead (always a full,
unambiguous 6 bits). Verified with 30+ consecutive passing runs. This was
never a real security issue — `verifyToken` itself was correct the whole
time; only the test simulating tampering had the flaw.

## Verified before packaging
Full monorepo typecheck, full build, and all three test suites (192 tests:
139 backend + 34 nia-service + 19 frontend) pass with these files in place.
