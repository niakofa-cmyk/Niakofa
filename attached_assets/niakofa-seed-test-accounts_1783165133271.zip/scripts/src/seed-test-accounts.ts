/**
 * Niakofa — Seed Test Accounts
 *
 * Creates (or repairs) the three standing test accounts against whichever
 * database DATABASE_URL points to. Upserts by email, so it's safe to run
 * more than once — existing rows get their password/role flags corrected
 * rather than erroring on a duplicate.
 *
 * This is intentionally a manual, standalone script — it is NOT wired into
 * railpack.json's automatic deploy startCommand. Seeding known admin
 * credentials on every production boot would be a standing security hole;
 * run this once, by hand, against the target database instead:
 *
 *   DATABASE_URL="<railway-postgres-url>" pnpm --filter @workspace/scripts run seed-test-accounts
 *
 * Get the Railway Postgres connection string from Railway → Postgres →
 * Variables → DATABASE_URL (or DATABASE_PUBLIC_URL if running this from
 * outside Railway's private network).
 */
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import bcrypt from "bcryptjs";
import { usersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("ERROR: DATABASE_URL environment variable is not set.");
  console.error('Set it to the target database, e.g.:');
  console.error('  DATABASE_URL="postgres://..." pnpm --filter @workspace/scripts run seed-test-accounts');
  process.exit(1);
}

const pool = new pg.Pool({ connectionString: DATABASE_URL });
const db = drizzle(pool);

const ACCOUNTS = [
  {
    role: "admin",
    name: "Admin Test Account",
    email: "admin@niakofa.app",
    password: "NiakofaAdmin2026!",
    overrides: { is_admin: true, approval_status: "approved" as const },
  },
  {
    role: "helper",
    name: "Helper Test Account",
    email: "helper@niakofa.app",
    password: "NiakofaHelper2026!",
    overrides: {
      is_helper: true,
      helper_status: "approved" as const,
      approval_status: "approved" as const,
    },
  },
  {
    role: "user",
    name: "User Test Account",
    email: "user@niakofa.app",
    password: "NiakofaUser2026!",
    overrides: { approval_status: "approved" as const },
  },
];

async function main() {
  for (const acct of ACCOUNTS) {
    // Match the exact hashing used by the real register/login routes so
    // these accounts authenticate through the normal login flow.
    const password_hash = await bcrypt.hash(acct.password, 12);
    const normalizedEmail = acct.email.trim().toLowerCase();

    const [existing] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(sql`lower(${usersTable.email}) = ${normalizedEmail}`)
      .limit(1);

    if (existing) {
      await db
        .update(usersTable)
        .set({
          password_hash,
          account_type: "individual",
          ...acct.overrides,
        } as Record<string, unknown>)
        .where(eq(usersTable.id, existing.id));
      console.log(`seed-test-accounts: updated ${acct.role} (${acct.email}) — id ${existing.id}`);
    } else {
      const [created] = await db
        .insert(usersTable)
        .values({
          name: acct.name,
          email: normalizedEmail,
          password_hash,
          account_type: "individual",
          ...acct.overrides,
        } as typeof usersTable.$inferInsert)
        .returning({ id: usersTable.id });
      console.log(`seed-test-accounts: created ${acct.role} (${acct.email}) — id ${created.id}`);
    }
  }

  console.log("seed-test-accounts: done. All three accounts are ready to log in on this database.");
  await pool.end();
}

main().catch(async (err) => {
  console.error("seed-test-accounts: failed", err);
  await pool.end().catch(() => {});
  process.exit(1);
});
