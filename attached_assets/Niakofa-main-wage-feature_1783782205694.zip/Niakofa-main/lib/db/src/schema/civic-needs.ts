import { pgTable, serial, text, integer, numeric, date, timestamp, index } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { usersTable } from "./users";
import { governmentSponsorsTable } from "./government-sponsors";

/**
 * civic_needs — county/gov-sponsor posts a community need (FIX 2, migration 0057).
 *
 * Two-way civic portal: previously sponsors could only fund the pool; now they
 * can also post specific needs that helpers/businesses claim and fulfil.
 *
 * Status lifecycle: open → claimed → completed | cancelled
 */
export const civicNeedsTable = pgTable("civic_needs", {
  id:                    serial("id").primaryKey(),
  posted_by_user_id:     integer("posted_by_user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  government_sponsor_id: integer("government_sponsor_id").notNull().references(() => governmentSponsorsTable.id, { onDelete: "cascade" }),
  title:                 text("title").notNull(),
  description:           text("description"),
  category:              text("category").notNull().default("other"),
  estimated_cost:        numeric("estimated_cost", { precision: 12, scale: 2 }),
  due_date:              date("due_date"),
  // status: open | claimed | completed | cancelled
  status:                text("status").notNull().default("open"),
  claimed_by_user_id:    integer("claimed_by_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  claimed_at:            timestamp("claimed_at", { withTimezone: true }),
  completed_at:          timestamp("completed_at", { withTimezone: true }),
  cancelled_at:          timestamp("cancelled_at", { withTimezone: true }),
  created_at:            timestamp("created_at", { withTimezone: true }).notNull().default(sql`NOW()`),
  updated_at:            timestamp("updated_at", { withTimezone: true }).notNull().default(sql`NOW()`),
}, (t) => [
  index("idx_civic_needs_status").on(t.status, t.created_at),
  index("idx_civic_needs_sponsor").on(t.government_sponsor_id),
]);

export type CivicNeed = typeof civicNeedsTable.$inferSelect;
export type InsertCivicNeed = typeof civicNeedsTable.$inferInsert;
