import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import {
  Shield, AlertCircle, CheckCircle2, Clock, X, ChevronLeft,
  Eye, Flag, User as UserIcon, RefreshCw, ExternalLink,
  Users, Search, Ban, AlertTriangle, Star, Bot, Power, Timer,
  BarChart2, TrendingUp, Activity, Zap, MessageSquare, Package,
  ChevronDown, ChevronUp, CheckSquare, Square, HandHeart, DollarSign,
  LineChart, FileText, Gavel, Sparkles, RotateCcw, Landmark, Building2,
  SlidersHorizontal, Save, Loader2, Server, LifeBuoy, Cpu, CheckCircle, WifiOff,
  Siren, MapPin, Globe, Fingerprint, Banknote, BadgeCheck, Inbox,
  ShieldAlert, ThumbsUp, ThumbsDown, Megaphone, Map, Link, Navigation2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { getToken } from "@/lib/auth";
import { useAppContext } from "@/lib/AppContext";
import { BackgroundCheckAdmin } from "@/components/BackgroundCheckAdmin";
import { detectUnits } from "@/lib/locale-utils";
import { AdminLiveBanner } from "@/components/AdminLiveBanner";
import { wsSubscribe, type WsEventType } from "@/lib/wsClient";

const BASE = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

// ── Helpers ───────────────────────────────────────────────────────────────────
interface Report {
  id: number;
  reporter_id: number;
  reported_user_id: number | null;
  reported_request_id: number | null;
  type: string;
  description: string;
  status: string;
  admin_notes: string | null;
  reviewed_by: number | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
  reporter_name?: string | null;
  reporter_email?: string | null;
  reported_user_name?: string | null;
}

interface AdminUser {
  id: number;
  name: string;
  email: string;
  is_helper: boolean;
  trust_score: number | null;
  help_count: number;
  created_at: string;
  is_suspended?: boolean;
}

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  pending:              { label: "Pending",       color: "bg-yellow-500/15 text-yellow-500 border-yellow-500/30" },
  under_review:         { label: "Reviewing",     color: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  resolved_dismissed:   { label: "Dismissed",     color: "bg-muted text-muted-foreground border-border" },
  resolved_warned:      { label: "Warned",        color: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  resolved_banned:      { label: "Banned",        color: "bg-destructive/15 text-destructive border-destructive/30" },
};

const TYPE_LABELS: Record<string, string> = {
  suspicious_request: "Suspicious Request",
  suspicious_helper:  "Suspicious Helper",
  fraud:              "Fraud",
  harassment:         "Harassment",
  fake_profile:       "Fake Profile",
  dangerous_behavior: "Dangerous Behavior",
  spam:               "Spam",
  other:              "Other",
};

const STATUS_FILTERS = ["all", "pending", "under_review", "resolved_dismissed", "resolved_warned", "resolved_banned"];
const SESSION_DURATION_MS  = 15 * 60 * 1000;
const BUMP_OFFER_BEFORE_MS =  5 * 60 * 1000;

function fmtDate(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

// ── New interfaces for admin enhancements ─────────────────────────────────────

interface FlaggedRequest {
  id: number;
  title: string;
  description: string | null;
  category: string | null;
  urgency: string | null;
  status: string;
  moderation_status: string;
  moderation_reason: string | null;
  requester_id: number;
  requester_name: string | null;
  requester_email: string | null;
  created_at: string;
}

interface GratitudePost {
  id: number;
  request_id: number | null;
  author_id: number;
  author_name: string;
  content: string;
  moderation_status: string;
  moderation_reason: string | null;
  created_at: string;
}

interface CivicSuggestion {
  id: number;
  name: string;
  category: string | null;
  description: string | null;
  phone: string | null;
  website: string | null;
  status: string;
  admin_notes: string | null;
  created_at: string;
}

interface Neighborhood {
  id: number;
  city_key: string;
  neighborhood_id: string;
  name: string;
  emoji: string | null;
  description: string | null;
  verified: boolean;
  created_at: string;
}

interface RegionCrisisResource {
  id: number;
  region_display: string;
  state_code: string | null;
  resources: { label: string; phone?: string; url?: string }[];
  verified: boolean;
  notes: string | null;
  created_at: string;
}

interface AdminCashout {
  id: number;
  user_id: number;
  user_name: string | null;
  user_email: string | null;
  amount: number;
  state: string;
  stripe_transfer_id: string | null;
  notes: string | null;
  created_at: string;
}

interface AuditLogEntry {
  id: number;
  user_id: number;
  action: string;
  target_user_id?: number;
  details: string;
  created_at: string;
  admin_name?: string;
}

interface PledgePoolData {
  total_pledged: number;
  total_paid: number;
  pending: number;
  completion_rate: number;
  daily_volume: Array<{ day: string; count: number }>;
}

interface NiaCostDailyEntry {
  date: string;
  totalCalls: number;
  totalInputTokens: number;
  totalOutputTokens: number;
  estimatedCostUsd: number;
  failedCalls: number;
}

interface NiaCostData {
  daily: NiaCostDailyEntry[];
  summary: {
    totalCalls: number;
    totalInputTokens: number;
    totalOutputTokens: number;
    totalCostUsd: number;
    totalFailed: number;
    averageCostPerCall: number;
  };
  period: { days: number; startDate: string | null; endDate: string | null };
}

// ── KPI tile ──────────────────────────────────────────────────────────────────
function KpiTile({ label, value, sub, color = "text-foreground", icon: Icon }: {
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="bg-card border border-border rounded-2xl p-4 flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">{label}</span>
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
      </div>
      <div className={`text-2xl font-black tabular-nums ${color}`}>{value}</div>
      {sub && <span className="text-[10px] text-muted-foreground">{sub}</span>}
    </div>
  );
}

// ── Analytics Tab ─────────────────────────────────────────────────────────────
function AnalyticsTab() {
  const [stats, setStats] = useState<{
    total_requests: number;
    completed_requests: number;
    total_users: number;
    active_helpers: number;
    total_reports: number;
    pending_reports: number;
    nia_conversations: number;
    avg_trust_score: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch(`${BASE}/api/admin/stats`, { headers: (() => { const t = getToken(); const h: Record<string, string> = t ? { Authorization: `Bearer ${t}` } : {}; return h; })() }).then(r => r.ok ? r.json() : null).catch(() => null),
    ]).then(([statsData]) => {
      if (statsData) setStats(statsData);
      setLoading(false);
    });
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center py-16 gap-2 text-muted-foreground">
      <RefreshCw className="w-5 h-5 animate-spin" /><span className="text-sm">Loading analytics…</span>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Platform Overview */}
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 mb-2">Platform Overview</div>
      <div className="grid grid-cols-2 gap-3">
        <KpiTile label="Total Requests" value={stats?.total_requests ?? "—"} sub="all time" icon={Package} />
        <KpiTile label="Completed" value={stats?.completed_requests ?? "—"} sub="fulfilled" icon={CheckCircle2} color="text-green-500" />
        <KpiTile label="Users" value={stats?.total_users ?? "—"} sub="registered" icon={Users} />
        <KpiTile label="Active Helpers" value={stats?.active_helpers ?? "—"} sub="on platform" icon={Star} color="text-primary" />
      </div>

      {/* Safety */}
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 mt-2 mb-2">Safety & Moderation</div>
      <div className="grid grid-cols-2 gap-3">
        <KpiTile label="Total Reports" value={stats?.total_reports ?? "—"} icon={Flag} />
        <KpiTile label="Pending" value={stats?.pending_reports ?? "—"} sub="need review" icon={AlertCircle}
          color={(stats?.pending_reports ?? 0) > 0 ? "text-yellow-500" : "text-green-500"} />
      </div>

      {/* Nia */}
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 mt-2 mb-2">Nia AI</div>
      <div className="grid grid-cols-2 gap-3">
        <KpiTile label="Conversations" value={stats?.nia_conversations ?? "—"} icon={MessageSquare} color="text-primary" />
        <KpiTile label="Avg Trust Score" value={stats?.avg_trust_score ? `${Math.round(stats.avg_trust_score)}%` : "—"} icon={TrendingUp} />
      </div>

      {/* No stats fallback */}
      {!stats && !loading && (
        <div className="bg-muted/40 border border-border rounded-2xl p-6 text-center">
          <Activity className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <div className="text-sm font-bold text-muted-foreground">Analytics unavailable</div>
          <div className="text-xs text-muted-foreground/60 mt-1">/api/admin/stats endpoint not responding</div>
        </div>
      )}

      {/* Leaderboard recalculate */}
      <LeaderboardRecalculateCard />
    </div>
  );
}

// ── Leaderboard Recalculate Control ──────────────────────────────────────────
function LeaderboardRecalculateCard() {
  const [running, setRunning] = useState(false);
  const [lastRun, setLastRun] = useState<string | null>(null);

  const recalculate = async () => {
    setRunning(true);
    try {
      const res = await fetch(`${BASE}/api/leaderboard/recalculate`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        setLastRun(new Date().toLocaleTimeString());
        toast({ title: "Leaderboard recalculated ✓" });
      } else {
        const b = await res.json().catch(() => ({})) as { error?: string };
        toast({ title: b.error ?? "Recalculation failed", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setRunning(false); }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <RotateCcw className="w-4 h-4 text-primary" />
        <span className="text-xs font-black uppercase tracking-wider">Leaderboard</span>
        {lastRun && <span className="text-[10px] text-green-400 ml-auto">Last run: {lastRun}</span>}
      </div>
      <p className="text-xs text-muted-foreground">Manually trigger a full trust-score and leaderboard recomputation. Runs automatically on a schedule but can be forced here after bulk moderation actions.</p>
      <button
        onClick={recalculate}
        disabled={running}
        style={{ touchAction: "manipulation" }}
        className="w-full h-10 rounded-xl border border-primary/40 bg-primary/10 text-primary text-sm font-black disabled:opacity-50 active:scale-95 transition-all flex items-center justify-center gap-2"
      >
        {running ? <><RefreshCw className="w-4 h-4 animate-spin" /> Recalculating…</> : <><RotateCcw className="w-4 h-4" /> Recalculate Now</>}
      </button>
    </div>
  );
}

// ── 7-Day Sparkline Component ─────────────────────────────────────────────────
function Sparkline({ data, color = "#3b82f6", height = 40 }: { data: number[]; color?: string; height?: number }) {
  if (!data || data.length === 0) return null;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1 || 1)) * 100;
    const y = 100 - ((v - min) / range) * 100;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full" style={{ height }}>
      <polyline fill="none" stroke={color} strokeWidth="3" points={points} />
    </svg>
  );
}

// ── Pledge Pool Dashboard ───────────────────────────────────────────────────
// ── Pool Balance Banner ───────────────────────────────────────────────────────
// Real-time community pool stats shown at the top of the Pledges tab so admins
// don't have to switch to Analytics to see balance and runway.
// Fetches /api/pool/stats (public endpoint) and auto-refreshes every 60s.
interface PoolStats {
  enabled: boolean;
  balance: number;
  runway_days: number | null;
  inflow_30d: number;
  outflow_30d: number;
  guaranteed_minimum: number;
  minimum_hourly_rate: number;
  pending_minimums_count: number;
  pending_minimums_total: number;
}

function PoolBalanceBanner() {
  const [stats, setStats] = useState<PoolStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/pool/stats");
      if (res.ok) {
        const d = await res.json() as PoolStats;
        setStats(d);
        setLastRefresh(new Date());
      }
    } catch {
      // non-fatal — shows stale data or skeleton
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const id = setInterval(() => { void load(); }, 60_000);
    return () => clearInterval(id);
  }, [load]);

  const runwayLabel = stats?.runway_days == null
    ? "∞"
    : stats.runway_days > 999
    ? "999+ days"
    : `${stats.runway_days} day${stats.runway_days !== 1 ? "s" : ""}`;

  const runwayColor = stats == null ? ""
    : stats.runway_days == null ? "text-green-400"
    : stats.runway_days < 14 ? "text-destructive"
    : stats.runway_days < 60 ? "text-yellow-400"
    : "text-green-400";

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Header row */}
      <div className="flex items-center justify-between px-4 pt-3 pb-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-black uppercase tracking-wider text-muted-foreground">Community Pool</span>
          {stats && (
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
              stats.enabled
                ? "bg-green-500/10 text-green-400 border-green-500/30"
                : "bg-destructive/10 text-destructive border-destructive/30"
            }`}>
              {stats.enabled ? "ACTIVE" : "PAUSED"}
            </span>
          )}
        </div>
        <button
          onClick={() => { void load(); }}
          disabled={loading}
          className="text-muted-foreground active:text-foreground"
          style={{ touchAction: "manipulation" }}
          title="Refresh pool stats"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Main stat grid */}
      <div className="grid grid-cols-3 divide-x divide-border border-t border-border mt-2">
        <div className="px-4 py-3 text-center">
          <div className={`text-xl font-black tabular-nums ${loading ? "animate-pulse text-muted-foreground" : "text-primary"}`}>
            {stats ? `$${stats.balance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}` : "—"}
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">Balance</div>
        </div>
        <div className="px-4 py-3 text-center">
          <div className={`text-xl font-black tabular-nums ${loading ? "animate-pulse text-muted-foreground" : runwayColor}`}>
            {stats ? runwayLabel : "—"}
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">Runway</div>
        </div>
        <div className="px-4 py-3 text-center">
          <div className={`text-xl font-black tabular-nums ${loading ? "animate-pulse text-muted-foreground" : stats?.pending_minimums_count ? "text-yellow-400" : "text-muted-foreground"}`}>
            {stats ? stats.pending_minimums_count : "—"}
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">Queued payouts</div>
        </div>
      </div>

      {/* Secondary row */}
      {stats && (
        <div className="flex divide-x divide-border border-t border-border">
          <div className="flex-1 px-4 py-2 flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">30d inflow</span>
            <span className="text-[11px] font-bold text-green-400">+${stats.inflow_30d.toFixed(0)}</span>
          </div>
          <div className="flex-1 px-4 py-2 flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">30d outflow</span>
            <span className="text-[11px] font-bold text-destructive">-${stats.outflow_30d.toFixed(0)}</span>
          </div>
          <div className="flex-1 px-4 py-2 flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">Min rate</span>
            <span className="text-[11px] font-bold">${stats.minimum_hourly_rate}/hr</span>
          </div>
        </div>
      )}

      {lastRefresh && (
        <div className="px-4 pb-2 text-[9px] text-muted-foreground/50 text-right">
          Updated {lastRefresh.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · auto-refreshes every 60s
        </div>
      )}
    </div>
  );
}

function PledgePoolDashboard() {
  const [data, setData] = useState<PledgePoolData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const tok = getToken();
    fetch(`${BASE}/api/admin/analytics`, { headers: tok ? { Authorization: `Bearer ${tok}` } : {} })
      .then(r => r.ok ? r.json() : null)
      .then((d: any) => {
        if (d?.pledge_pool) {
          setData({
            total_pledged: d.pledge_pool.total_pledged,
            total_paid: d.pledge_pool.total_paid,
            pending: d.pledge_pool.pending,
            completion_rate: d.pledge_pool.total_pledged > 0
              ? Math.round((d.pledge_pool.total_paid / d.pledge_pool.total_pledged) * 100)
              : 0,
            daily_volume: d.daily_request_volume || [],
          });
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
      <RefreshCw className="w-4 h-4 animate-spin" /><span className="text-xs">Loading pledge data…</span>
    </div>
  );

  if (!data) return (
    <div className="text-center py-8 text-muted-foreground text-xs">Pledge pool data unavailable</div>
  );

  const dailyCounts = data.daily_volume.map((d: any) => d.count || 0);

  return (
    <div className="space-y-4">
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 mb-2">Pledge Pool Health</div>
      <div className="grid grid-cols-2 gap-3">
        <KpiTile label="Total Pledged" value={`$${data.total_pledged.toLocaleString()}`} sub="community commitments" icon={HandHeart} color="text-primary" />
        <KpiTile label="Total Paid" value={`$${data.total_paid.toLocaleString()}`} sub="honored contributions" icon={DollarSign} color="text-green-500" />
        <KpiTile label="Pending" value={`$${data.pending.toLocaleString()}`} sub="outstanding balance" icon={Clock} color="text-yellow-500" />
        <KpiTile label="Completion Rate" value={`${data.completion_rate}%`} sub="pay-it-forward ratio" icon={TrendingUp} color={data.completion_rate >= 80 ? "text-green-500" : "text-yellow-500"} />
      </div>

      {/* 7-day sparkline */}
      {dailyCounts.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">7-Day Request Volume</span>
            <LineChart className="w-3.5 h-3.5 text-muted-foreground" />
          </div>
          <Sparkline data={dailyCounts} color="#3b82f6" height={60} />
          <div className="flex justify-between mt-1 text-[10px] text-muted-foreground">
            {data.daily_volume.map((d: any, i: number) => (
              <span key={i} className="text-center flex-1">{d.day?.slice(0, 3) ?? ""}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Pledge Write-Off Card ─────────────────────────────────────────────────────
// Lets admins resolve stale unpaid pledges (forgive or write off) so they
// stop dragging down the pool runway number. Endpoint: PATCH /admin/requests/:id/pledge-status
interface PledgeRequest {
  id: number;
  title: string;
  pledge_amount: number | null;
  pledge_status: string;
  status: string;
  created_at: string;
  requester_name?: string;
}

function PledgeWriteOffCard() {
  const [pledges, setPledges] = useState<PledgeRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<number | null>(null);
  const [showAll, setShowAll] = useState(false);

  const load = useCallback(() => {
    const tok = getToken();
    fetch(`${BASE}/api/requests?payment_type=pay_it_forward&limit=100`, {
      headers: tok ? { Authorization: `Bearer ${tok}` } : {},
    })
      .then(r => r.ok ? r.json() : [])
      .then((data: PledgeRequest[]) => {
        if (Array.isArray(data)) {
          setPledges(data.filter(r =>
            (r.pledge_amount ?? 0) > 0 &&
            (!r.pledge_status || r.pledge_status === "active") &&
            (r.status === "pay_it_forward_pending" || r.status === "completed")
          ));
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const markStatus = async (requestId: number, pledge_status: "forgiven" | "written_off") => {
    setProcessing(requestId);
    try {
      const tok = getToken();
      const res = await fetch(`${BASE}/api/admin/requests/${requestId}/pledge-status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ pledge_status }),
      });
      if (!res.ok) throw new Error("Failed");
      setPledges(prev => prev.filter(p => p.id !== requestId));
      toast({ title: pledge_status === "forgiven" ? "Pledge forgiven 🤝" : "Pledge written off 📝" });
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  if (loading) return (
    <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground text-sm">
      <RefreshCw className="w-4 h-4 animate-spin" /> Loading pledges…
    </div>
  );

  if (pledges.length === 0) return (
    <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-4 text-center">
      <CheckCircle2 className="w-6 h-6 text-green-500 mx-auto mb-1" />
      <div className="text-xs font-bold text-green-600">No outstanding pledges need attention</div>
    </div>
  );

  const visible = showAll ? pledges : pledges.slice(0, 5);

  return (
    <div className="space-y-3">
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground flex items-center justify-between">
        <span className="flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> Outstanding Pledges ({pledges.length})</span>
        <button onClick={load} className="text-primary text-[10px] flex items-center gap-1"><RefreshCw className="w-3 h-3" /> Refresh</button>
      </div>
      <div className="space-y-2">
        {visible.map(p => (
          <div key={p.id} className="bg-card border border-border rounded-xl p-3 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-xs font-bold truncate">{p.title}</div>
                {p.requester_name && <div className="text-[10px] text-muted-foreground">{p.requester_name}</div>}
                <div className="text-[10px] text-yellow-500 font-bold mt-0.5">
                  Pledge: ${(p.pledge_amount ?? 0).toFixed(2)} · {p.status}
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => markStatus(p.id, "forgiven")}
                disabled={processing === p.id}
                className="flex-1 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-600 text-[11px] font-black disabled:opacity-50"
              >🤝 Forgive</button>
              <button
                onClick={() => markStatus(p.id, "written_off")}
                disabled={processing === p.id}
                className="flex-1 h-8 rounded-lg bg-muted border border-border text-muted-foreground text-[11px] font-black disabled:opacity-50"
              >📝 Write Off</button>
            </div>
          </div>
        ))}
      </div>
      {pledges.length > 5 && (
        <button
          onClick={() => setShowAll(v => !v)}
          className="w-full text-xs text-primary underline py-1"
        >{showAll ? "Show less" : `Show all ${pledges.length}`}</button>
      )}
    </div>
  );
}

// ── Audit Log Table ───────────────────────────────────────────────────────────
// Synthesises a unified audit timeline from multiple admin-accessible endpoints:
//   • Resolved user reports   → shows who was warned/banned and by whom
//   • Moderated requests      → flagged request approvals/rejections
// This is the best available audit trail given there is no dedicated audit_log
// table. If a future migration adds one, replace the fetches below with a single
// GET /api/admin/audit-log call.
function AuditLogTable() {
  const [entries, setEntries] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    const tok = getToken();
    const headers: Record<string, string> = tok ? { Authorization: `Bearer ${tok}` } : {};
    Promise.all([
      fetch(`${BASE}/api/reports`, { headers }).then(r => r.ok ? r.json() : []),
      fetch(`${BASE}/api/admin/accounts?limit=100`, { headers }).then(r => r.ok ? r.json() : []),
    ])
      .then(([reports, users]: [any[], any[]]) => {
        const reportEntries: AuditLogEntry[] = (reports as any[])
          .filter((r: any) => r.status !== "pending" && r.reviewed_at)
          .map((r: any) => ({
            id: r.id,
            user_id: r.reviewed_by ?? 0,
            action: r.status === "resolved_banned" ? "BANNED" :
                    r.status === "resolved_warned" ? "WARNED" :
                    r.status === "resolved_dismissed" ? "DISMISSED" :
                    r.status === "under_review" ? "REVIEWING" : r.status.toUpperCase(),
            target_user_id: r.reported_user_id,
            details: r.admin_notes || `Report type: ${TYPE_LABELS[r.type] ?? r.type}`,
            created_at: r.reviewed_at ?? r.created_at,
            admin_name: "Admin",
          }));

        const userEntries: AuditLogEntry[] = (users as any[])
          .filter((u: any) => u.is_suspended || (u.trust_score !== null && u.trust_score <= -1))
          .map((u: any, i: number) => ({
            id: 10000 + i,
            user_id: 0,
            action: u.trust_score !== null && u.trust_score <= -1 ? "BANNED" : "SUSPENDED",
            target_user_id: u.id,
            details: u.suspended_reason || `Account moderation — ${u.name}`,
            created_at: u.suspended_at ?? u.created_at,
            admin_name: "System",
          }));

        // Merge, deduplicate by id, sort newest first
        const seen = new Set<number>();
        const merged = [...reportEntries, ...userEntries]
          .filter(e => { if (seen.has(e.id)) return false; seen.add(e.id); return true; })
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

        setEntries(merged);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filtered = entries.filter(e =>
    !filter ||
    e.action.toLowerCase().includes(filter.toLowerCase()) ||
    e.details.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-3">
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 mb-2">Audit Log</div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="search"
          placeholder="Filter audit entries…"
          value={filter}
          onChange={e => setFilter(e.target.value)}
          className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-3 text-sm outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      {loading && (
        <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
          <RefreshCw className="w-4 h-4 animate-spin" /><span className="text-xs">Loading audit log…</span>
        </div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="text-center py-8 text-muted-foreground text-xs">No audit entries found</div>
      )}

      <div className="space-y-2">
        {filtered.map(entry => (
          <div key={entry.id} className="bg-card border border-border rounded-xl p-3 flex items-center gap-3">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
              entry.action === "BANNED" ? "bg-destructive/10 text-destructive" : "bg-yellow-500/10 text-yellow-500"
            }`}>
              {entry.action === "BANNED" ? <Ban className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold">{entry.action}</span>
                <span className="text-[10px] text-muted-foreground">User #{entry.target_user_id}</span>
              </div>
              <div className="text-xs text-muted-foreground truncate">{entry.details}</div>
            </div>
            <div className="text-[10px] text-muted-foreground shrink-0">{fmtDate(entry.created_at)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Bulk Helper Approvals ─────────────────────────────────────────────────────
function BulkHelperApprovals() {
  const [pending, setPending] = useState<PendingHelper[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    const tok = getToken();
    fetch(`${BASE}/api/admin/helper-applications?status=pending`, { headers: tok ? { Authorization: `Bearer ${tok}` } : {} })
      .then(r => r.ok ? r.json() : [])
      .then((data: PendingHelper[]) => {
        if (Array.isArray(data)) setPending(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const toggleSelect = (id: number) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAll = () => {
    if (selected.size === pending.length) setSelected(new Set());
    else setSelected(new Set(pending.map(p => p.id)));
  };

  const bulkApprove = async () => {
    if (selected.size === 0) return;
    setProcessing(true);
    const tok = getToken();
    const promises = Array.from(selected).map(id =>
      fetch(`${BASE}/api/users/${id}/helper-application`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ status: "approved" }),
      })
    );
    await Promise.all(promises);
    setPending(prev => prev.filter(p => !selected.has(p.id)));
    setSelected(new Set());
    setProcessing(false);
    toast({ title: `Approved ${selected.size} helper${selected.size > 1 ? "s" : ""} ✅` });
  };

  const bulkReject = async () => {
    if (selected.size === 0) return;
    setProcessing(true);
    const tok = getToken();
    const promises = Array.from(selected).map(id =>
      fetch(`${BASE}/api/users/${id}/helper-application`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ status: "rejected" }),
      })
    );
    await Promise.all(promises);
    setPending(prev => prev.filter(p => !selected.has(p.id)));
    setSelected(new Set());
    setProcessing(false);
    toast({ title: `Rejected ${selected.size} helper${selected.size > 1 ? "s" : ""}` });
  };

  if (loading) return (
    <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
      <RefreshCw className="w-4 h-4 animate-spin" /><span className="text-xs">Loading applications…</span>
    </div>
  );

  if (pending.length === 0) return (
    <div className="text-center py-8">
      <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-green-400/40" />
      <div className="text-xs text-muted-foreground">No pending helper applications</div>
    </div>
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">Bulk Helper Approvals ({pending.length})</div>
        <button
          onClick={selectAll}
          className="text-[10px] font-black px-2.5 py-1.5 rounded-full border border-border bg-card active:bg-muted"
        >
          {selected.size === pending.length ? "Deselect All" : "Select All"}
        </button>
      </div>

      <div className="space-y-2">
        {pending.map(u => (
          <div key={u.id} className="bg-card border border-border rounded-xl p-3 flex items-center gap-3"
          onClick={() => toggleSelect(u.id)}
          >
            <div className="shrink-0">
              {selected.has(u.id) ? <CheckSquare className="w-5 h-5 text-primary" /> : <Square className="w-5 h-5 text-muted-foreground" />}
            </div>
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-black text-xs text-primary shrink-0">
              {u.name[0]?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold truncate">{u.name}</div>
              <div className="text-[10px] text-muted-foreground truncate">{u.email}</div>
              {u.helper_skills && u.helper_skills.length > 0 && (
                <div className="flex gap-1 mt-1 flex-wrap">
                  {u.helper_skills.slice(0, 2).map(s => (
                    <span key={s} className="text-[9px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">{s}</span>
                  ))}
                  {u.helper_skills.length > 2 && <span className="text-[9px] text-muted-foreground">+{u.helper_skills.length - 2}</span>}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {selected.size > 0 && (
        <div className="flex gap-2 pt-2">
          <button
            onClick={bulkReject}
            disabled={processing}
            className="flex-1 h-10 rounded-xl border border-destructive/40 bg-destructive/10 text-destructive text-xs font-black disabled:opacity-50"
          >
            {processing ? <RefreshCw className="w-4 h-4 animate-spin mx-auto" /> : `Reject ${selected.size}`}
          </button>
          <button
            onClick={bulkApprove}
            disabled={processing}
            className="flex-1 h-10 rounded-xl bg-green-500 text-white text-xs font-black disabled:opacity-50"
          >
            {processing ? <RefreshCw className="w-4 h-4 animate-spin mx-auto" /> : `Approve ${selected.size}`}
          </button>
        </div>
      )}
    </div>
  );
}

// ── Report Detail Sheet ───────────────────────────────────────────────────────
function ReportDetailSheet({ report, onClose, onReviewed }: {
  report: Report; onClose: () => void; onReviewed: (updated: Report) => void;
}) {
  const [status, setStatus] = useState<string>(report.status === "pending" ? "under_review" : report.status);
  const [notes, setNotes] = useState(report.admin_notes ?? "");
  const [saving, setSaving] = useState(false);

  const handleReview = async () => {
    const valid = ["under_review", "resolved_dismissed", "resolved_warned", "resolved_banned"];
    if (!valid.includes(status)) return;
    setSaving(true);
    try {
      const token = getToken();
      const res = await fetch(`${BASE}/api/reports/${report.id}/review`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ status, admin_notes: notes || null }),
      });
      if (!res.ok) throw new Error("Failed");
      const updated = await res.json() as Report;
      onReviewed(updated);
      toast({ title: "Report updated", description: `→ ${STATUS_LABELS[status]?.label ?? status}` });
      onClose();
    } catch {
      toast({ title: "Failed to update report", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 26, stiffness: 220 }}
        className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border rounded-t-3xl max-h-[92dvh] overflow-y-auto"
        style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-9 h-1 bg-border rounded-full" />
        </div>

        <div className="flex items-center justify-between px-5 pb-3 border-b border-border">
          <div className="flex items-center gap-2">
            <Flag className="w-5 h-5 text-destructive" />
            <h3 className="font-black text-lg">Report #{report.id}</h3>
          </div>
          <button onClick={onClose} style={{ touchAction: "manipulation" }}
            className="w-9 h-9 rounded-full border border-border flex items-center justify-center active:bg-muted">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-background rounded-xl p-3 border border-border">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Type</div>
              <div className="text-sm font-bold">{TYPE_LABELS[report.type] ?? report.type}</div>
            </div>
            <div className="bg-background rounded-xl p-3 border border-border">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Filed</div>
              <div className="text-sm font-bold">{fmtDate(report.created_at)}</div>
            </div>
            {report.reporter_name && (
              <div className="bg-background rounded-xl p-3 border border-border">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Reporter</div>
                <div className="text-sm font-bold">{report.reporter_name}</div>
                {report.reporter_email && <div className="text-[10px] text-muted-foreground truncate">{report.reporter_email}</div>}
              </div>
            )}
            {report.reported_user_name && (
              <div className="bg-background rounded-xl p-3 border border-border">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Reported</div>
                <div className="text-sm font-bold">{report.reported_user_name}</div>
              </div>
            )}
          </div>

          <div className="bg-background rounded-xl p-4 border border-border">
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Description</div>
            <p className="text-sm leading-relaxed">{report.description}</p>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">Admin Action</div>
            <div className="grid grid-cols-2 gap-2">
              {(["under_review", "resolved_dismissed", "resolved_warned", "resolved_banned"] as const).map(s => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  style={{ touchAction: "manipulation" }}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                    status === s
                      ? STATUS_LABELS[s].color + " ring-2 ring-offset-1 ring-offset-card ring-current"
                      : "bg-background border-border text-muted-foreground"
                  }`}
                >
                  {STATUS_LABELS[s].label}
                </button>
              ))}
            </div>

            <textarea
              placeholder="Admin notes (optional)…"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
              className="w-full text-sm bg-background border border-border rounded-xl p-3 resize-none focus:outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
            />

            <Button className="w-full h-12 font-black text-base" onClick={handleReview} disabled={saving}
              style={{ touchAction: "manipulation" }}>
              {saving ? <span className="flex items-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" />Saving…</span> : "Submit Review"}
            </Button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

// ── Hard-Delete User Button ───────────────────────────────────────────────────
// Calls DELETE /users/:id — permanent. Requires typing the user's name in full.
function HardDeleteUserButton({ userId, userName, onDeleted }: {
  userId: number; userName: string; onDeleted: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [confirm, setConfirm] = useState("");
  const [deleting, setDeleting] = useState(false);

  const doDelete = async () => {
    if (confirm.trim().toLowerCase() !== userName.toLowerCase()) return;
    setDeleting(true);
    try {
      const res = await fetch(`${BASE}/api/users/${userId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        toast({ title: `${userName} permanently deleted` });
        onDeleted();
      } else {
        const b = await res.json().catch(() => ({})) as { error?: string };
        toast({ title: b.error ?? "Delete failed", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setDeleting(false); }
  };

  if (!expanded) {
    return (
      <button onClick={() => setExpanded(true)} style={{ touchAction: "manipulation" }}
        className="w-full flex items-center gap-3 p-4 bg-muted/40 border border-border rounded-2xl active:scale-[0.98] transition-all">
        <X className="w-5 h-5 text-muted-foreground" />
        <div className="text-left">
          <div className="font-black text-sm text-muted-foreground">Hard Delete Account</div>
          <div className="text-xs text-muted-foreground/60">Permanent — all data removed</div>
        </div>
      </button>
    );
  }

  return (
    <div className="border border-destructive/40 rounded-2xl p-4 space-y-3 bg-destructive/5">
      <div className="text-xs text-destructive font-bold leading-relaxed">
        ⚠️ Permanently deletes all data for <strong>{userName}</strong> — requests, wallet, transactions, history. Cannot be undone.
      </div>
      <div className="text-xs text-muted-foreground">Type the user's name to confirm:</div>
      <input type="text" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder={userName}
        className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-destructive"
        style={{ fontSize: "16px" }} autoFocus />
      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => { setExpanded(false); setConfirm(""); }}
          className="h-10 rounded-xl border border-border text-sm text-muted-foreground font-bold">Cancel</button>
        <button onClick={doDelete}
          disabled={confirm.trim().toLowerCase() !== userName.toLowerCase() || deleting}
          className="h-10 rounded-xl bg-destructive text-white text-sm font-black disabled:opacity-40 active:scale-95 transition-all">
          {deleting ? <RefreshCw className="w-4 h-4 animate-spin mx-auto" /> : "Delete Forever"}
        </button>
      </div>
    </div>
  );
}

// ── Users Tab ─────────────────────────────────────────────────────────────────
// ── Pending Account Approvals ─────────────────────────────────────────────────
// BUG-CRIT-01: individual accounts now auto-approve at registration (see
// CLAUDE.md Incident #19), but organization accounts still require real
// admin review. This is the UI for that — previously GET /admin/accounts
// could list pending accounts but no UI surfaced them and no endpoint could
// act on them at all.
function PendingAccountsCard() {
  const [pending, setPending] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(() => {
    const tok = getToken();
    fetch(`${BASE}/api/admin/accounts?approval_status=pending`, { headers: tok ? { Authorization: `Bearer ${tok}` } : {} })
      .then(r => r.ok ? r.json() : [])
      .then((data: AdminUser[]) => { if (Array.isArray(data)) setPending(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (userId: number, status: "approved" | "denied") => {
    setProcessing(userId);
    try {
      const tok = getToken();
      const res = await fetch(`${BASE}/api/admin/accounts/${userId}/approval`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed");
      setPending(prev => prev.filter(u => u.id !== userId));
      toast({ title: status === "approved" ? "Account approved ✅" : "Account denied" });
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  if (loading || pending.length === 0) return null;

  return (
    <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-2xl p-4 space-y-3">
      <div className="text-xs font-black uppercase tracking-wider text-yellow-600 flex items-center gap-1.5">
        <Clock className="w-3.5 h-3.5" /> Pending Account Approvals ({pending.length})
      </div>
      {pending.map(u => (
        <div key={u.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm font-bold truncate">{u.name}</div>
            <div className="text-xs text-muted-foreground truncate">{u.email}</div>
            {(u as AdminUser & { organization_name?: string }).organization_name && (
              <div className="text-[10px] text-primary mt-0.5">{(u as AdminUser & { organization_name?: string }).organization_name}</div>
            )}
          </div>
          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => decide(u.id, "denied")}
              disabled={processing === u.id}
              className="h-9 px-3 rounded-lg border border-destructive/40 bg-destructive/10 text-destructive text-xs font-black disabled:opacity-50"
            >Deny</button>
            <button
              onClick={() => decide(u.id, "approved")}
              disabled={processing === u.id}
              className="h-9 px-3 rounded-lg bg-green-500 text-white text-xs font-black disabled:opacity-50"
            >Approve</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Pending Business Approvals ────────────────────────────────────────────────
interface PendingBusiness {
  id: number;
  legal_name: string;
  display_name: string;
  address: string | null;
  phone: string | null;
  approval_status: string;
  created_by_user_id: number;
  created_at: string;
  owner_name?: string;
  owner_email?: string;
}

function PendingBusinessesCard() {
  const [pending, setPending] = useState<PendingBusiness[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(() => {
    const tok = getToken();
    fetch(`${BASE}/api/admin/businesses`, { headers: tok ? { Authorization: `Bearer ${tok}` } : {} })
      .then(r => r.ok ? r.json() : [])
      .then((data: PendingBusiness[]) => {
        if (Array.isArray(data)) setPending(data.filter(b => b.approval_status === "pending"));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (businessId: number, status: "approved" | "rejected") => {
    setProcessing(businessId);
    try {
      const tok = getToken();
      const res = await fetch(`${BASE}/api/admin/businesses/${businessId}/approve`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ approval_status: status }),
      });
      if (!res.ok) throw new Error("Failed");
      setPending(prev => prev.filter(b => b.id !== businessId));
      toast({ title: status === "approved" ? "Business approved ✅" : "Business rejected" });
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  if (loading || pending.length === 0) return null;

  return (
    <div className="bg-blue-500/10 border border-blue-500/30 rounded-2xl p-4 space-y-3">
      <div className="text-xs font-black uppercase tracking-wider text-blue-600 flex items-center gap-1.5">
        <Package className="w-3.5 h-3.5" /> Pending Business Applications ({pending.length})
      </div>
      {pending.map(b => (
        <div key={b.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm font-bold truncate">{b.display_name}</div>
            <div className="text-xs text-muted-foreground truncate">{b.legal_name}</div>
            {b.address && <div className="text-[10px] text-muted-foreground mt-0.5 truncate">{b.address}</div>}
            {b.owner_name && <div className="text-[10px] text-primary mt-0.5">Owner: {b.owner_name}</div>}
          </div>
          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => decide(b.id, "rejected")}
              disabled={processing === b.id}
              className="h-9 px-3 rounded-lg border border-destructive/40 bg-destructive/10 text-destructive text-xs font-black disabled:opacity-50"
            >Reject</button>
            <button
              onClick={() => decide(b.id, "approved")}
              disabled={processing === b.id}
              className="h-9 px-3 rounded-lg bg-green-500 text-white text-xs font-black disabled:opacity-50"
            >Approve</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [actionUser, setActionUser] = useState<AdminUser | null>(null);
  const [showHelperOnly, setShowHelperOnly] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<Set<number>>(new Set());
  const [bulkMode, setBulkMode] = useState(false);

  // Debounced, server-side search — searching client-side over only the first
  // 200 fetched rows meant an admin could never find a user past that cutoff.
  // The server now searches the full table by name/email and returns the true
  // total, so "Showing X of Y" is always accurate no matter how many users exist.
  useEffect(() => {
    const tok = getToken();
    setLoading(true);
    const handle = setTimeout(() => {
      const qParam = search.trim() ? `&q=${encodeURIComponent(search.trim())}` : "";
      fetch(`${BASE}/api/users?limit=200${qParam}`, { headers: tok ? { Authorization: `Bearer ${tok}` } : {} })
        .then(r => r.json())
        .then((data: { users?: AdminUser[]; total?: number }) => {
          setUsers(Array.isArray(data.users) ? data.users : []);
          setTotal(typeof data.total === "number" ? data.total : null);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }, search.trim() ? 300 : 0);
    return () => clearTimeout(handle);
  }, [search]);

  const filtered = users.filter(u => !showHelperOnly || u.is_helper);

  const handleAction = async (userId: number, action: "warn" | "ban") => {
    try {
      const tok = getToken();
      await fetch(`${BASE}/api/users/${userId}/moderation`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ action }),
      });
      toast({ title: action === "ban" ? "User banned" : "Warning issued" });
      setActionUser(null);
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-3">
      <PendingAccountsCard />
      <PendingBusinessesCard />
      {/* Search + filter row */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search users…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-3 text-sm outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <button
          onClick={() => setShowHelperOnly(!showHelperOnly)}
          style={{ touchAction: "manipulation" }}
          className={`px-4 py-3 rounded-xl border text-xs font-black transition-all ${
            showHelperOnly ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground"
          }`}
        >
          Helpers
        </button>
      </div>

      <div className="flex items-center justify-between px-1">
        <div className="text-xs text-muted-foreground">
          {search.trim()
            ? `${filtered.length} match${filtered.length !== 1 ? "es" : ""}${typeof total === "number" ? ` of ${total} total` : ""}`
            : typeof total === "number"
              ? `Showing ${filtered.length} of ${total} user${total !== 1 ? "s" : ""}`
              : `${filtered.length} user${filtered.length !== 1 ? "s" : ""}`}
        </div>
        <button
          onClick={() => { setBulkMode(!bulkMode); setSelectedUsers(new Set()); }}
          className={`text-[10px] font-black px-2.5 py-1.5 rounded-full border transition-all ${
            bulkMode ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground"
          }`}
        >
          {bulkMode ? "Done" : "Bulk Select"}
        </button>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-12 gap-2 text-muted-foreground">
          <RefreshCw className="w-5 h-5 animate-spin" /><span className="text-sm">Loading…</span>
        </div>
      )}

      {filtered.map(user => (
        <motion.div
          key={user.id}
          layout
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-2xl p-4"
        >
          <div className="flex items-center gap-3">
            {bulkMode && (
              <button
                onClick={() => {
                  setSelectedUsers(prev => {
                    const next = new Set(prev);
                    if (next.has(user.id)) next.delete(user.id);
                    else next.add(user.id);
                    return next;
                  });
                }}
                className="shrink-0"
              >
                {selectedUsers.has(user.id) ? <CheckSquare className="w-5 h-5 text-primary" /> : <Square className="w-5 h-5 text-muted-foreground" />}
              </button>
            )}
            <div className="w-11 h-11 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 font-black text-primary text-base">
              {user.name[0]?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-sm truncate">{user.name}</div>
              <div className="text-[11px] text-muted-foreground truncate">{user.email}</div>
              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                {user.is_helper && (
                  <span className="text-[10px] bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-full font-bold">Helper</span>
                )}
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Star className="w-3 h-3" />{(user.trust_score ?? 0).toFixed(0)}%
                </span>
                <span className="text-[10px] text-muted-foreground">{user.help_count} helps</span>
                {user.is_suspended && (
                  <span className="text-[10px] bg-destructive/10 text-destructive border border-destructive/20 px-2 py-0.5 rounded-full font-bold">Suspended</span>
                )}
              </div>
            </div>
            <button
              onClick={() => setActionUser(user)}
              style={{ touchAction: "manipulation" }}
              className="w-10 h-10 rounded-xl border border-border flex items-center justify-center active:bg-muted transition-colors"
            >
              <AlertTriangle className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </motion.div>
      ))}

      {/* Action sheet */}
      <AnimatePresence>
        {actionUser && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
              onClick={() => setActionUser(null)}
            />
            <motion.div
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border rounded-t-3xl p-5"
              style={{ paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" }}
              onClick={e => e.stopPropagation()}
            >
              {/* Drag handle */}
              <div className="flex justify-center mb-4">
                <div className="w-9 h-1 bg-border rounded-full" />
              </div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center font-black text-lg">
                  {actionUser.name[0]?.toUpperCase()}
                </div>
                <div>
                  <div className="font-black">{actionUser.name}</div>
                  <div className="text-xs text-muted-foreground">{actionUser.email}</div>
                </div>
              </div>
              <div className="space-y-2">
                <button
                  onClick={() => handleAction(actionUser.id, "warn")}
                  style={{ touchAction: "manipulation" }}
                  className="w-full flex items-center gap-3 p-4 bg-orange-500/10 border border-orange-500/30 rounded-2xl active:scale-[0.98] transition-all"
                >
                  <AlertTriangle className="w-5 h-5 text-orange-400" />
                  <div className="text-left">
                    <div className="font-black text-sm text-orange-400">Issue Warning</div>
                    <div className="text-xs text-muted-foreground">User gets a community guidelines warning</div>
                  </div>
                </button>
                <button
                  onClick={() => handleAction(actionUser.id, "ban")}
                  style={{ touchAction: "manipulation" }}
                  className="w-full flex items-center gap-3 p-4 bg-destructive/10 border border-destructive/30 rounded-2xl active:scale-[0.98] transition-all"
                >
                  <Ban className="w-5 h-5 text-destructive" />
                  <div className="text-left">
                    <div className="font-black text-sm text-destructive">Ban User</div>
                    <div className="text-xs text-muted-foreground">Remove from platform permanently</div>
                  </div>
                </button>
                <HardDeleteUserButton userId={actionUser.id} userName={actionUser.name} onDeleted={() => {
                  setActionUser(null);
                  setUsers(prev => prev.filter(u => u.id !== actionUser.id));
                }} />
                <button
                  onClick={() => setActionUser(null)}
                  style={{ touchAction: "manipulation" }}
                  className="w-full p-4 text-sm text-muted-foreground active:text-foreground rounded-2xl border border-border"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Bulk action bar */}
      {bulkMode && selectedUsers.size > 0 && (
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="fixed bottom-20 left-4 right-4 z-40 bg-card border border-border rounded-2xl p-4 shadow-lg"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-bold">{selectedUsers.size} selected</span>
            <button onClick={() => setSelectedUsers(new Set())} className="text-xs text-muted-foreground">Clear</button>
          </div>
          <div className="flex gap-2">
            <button
              onClick={async () => {
                const tok = getToken();
                await Promise.all(Array.from(selectedUsers).map(id =>
                  fetch(`${BASE}/api/users/${id}/moderation`, {
                    method: "PATCH",
                    headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
                    body: JSON.stringify({ action: "suspend" }),
                  })
                ));
                toast({ title: `Suspended ${selectedUsers.size} users` });
                setSelectedUsers(new Set());
                setBulkMode(false);
              }}
              className="flex-1 h-10 rounded-xl border border-yellow-500/40 bg-yellow-500/10 text-yellow-600 text-xs font-black"
            >
              Suspend
            </button>
            <button
              onClick={async () => {
                const tok = getToken();
                await Promise.all(Array.from(selectedUsers).map(id =>
                  fetch(`${BASE}/api/users/${id}/moderation`, {
                    method: "PATCH",
                    headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
                    body: JSON.stringify({ action: "ban" }),
                  })
                ));
                toast({ title: `Banned ${selectedUsers.size} users` });
                setSelectedUsers(new Set());
                setBulkMode(false);
              }}
              className="flex-1 h-10 rounded-xl bg-destructive text-white text-xs font-black"
            >
              Ban
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ── Nia Tab ───────────────────────────────────────────────────────────────────
function NiaTab() {
  const [niaEnabled, setNiaEnabled] = useState<boolean | null>(null);
  const [lastToggledAt, setLastToggledAt] = useState<string | null>(null);
  const [toggling, setToggling] = useState(false);
  const [confirmPending, setConfirmPending] = useState<boolean | null>(null);
  const [broadcastConfirm, setBroadcastConfirm] = useState<string | null>(null);
  const [memoryStats, setMemoryStats] = useState<{ users: number; entries: number } | null>(null);
  const [costData, setCostData] = useState<NiaCostData | null>(null);
  const [costLoading, setCostLoading] = useState(false);
  const [costAlert, setCostAlert] = useState<{ alert: boolean; threshold: number; todayCost: number; message: string } | null>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [wsReceived, setWsReceived] = useState<{ enabled: boolean; at: string } | null>(null);

  const hdrs = useCallback(() => {
    const t = getToken();
    return t ? { Authorization: `Bearer ${t}` } : {} as Record<string, string>;
  }, []);

  const loadStatus = useCallback(async (quiet = false) => {
    try {
      const r = await fetch(`${BASE}/api/admin/nia-status`, { headers: hdrs() });
      if (r.ok) {
        const d = await r.json() as { enabled: boolean; last_toggled_at: string | null };
        setNiaEnabled(d.enabled);
        if (d.last_toggled_at) setLastToggledAt(d.last_toggled_at);
      } else if (!quiet) toast({ title: `Nia status unavailable (${r.status})`, variant: "destructive" });
    } catch { if (!quiet) toast({ title: "Could not reach server", variant: "destructive" }); }
  }, [hdrs]);

  // ── Initial load: status + memory + cost alert + cost data ───────────────
  useEffect(() => {
    loadStatus();
    fetch(`${BASE}/api/admin/nia-memory-stats`, { headers: hdrs() })
      .then(r => r.ok ? r.json() : null).then(d => { if (d) setMemoryStats(d); }).catch(() => null);
    fetch(`${BASE}/api/admin/nia-cost-alert`, { headers: hdrs() })
      .then(r => r.ok ? r.json() : null).then(d => { if (d) setCostAlert(d); }).catch(() => null);
    setCostLoading(true);
    fetch(`${BASE}/api/admin/nia-costs?days=7`, { headers: hdrs() })
      .then(r => r.ok ? r.json() : null)
      .then((d: NiaCostData | null) => { if (d) setCostData(d); setCostLoading(false); })
      .catch(() => setCostLoading(false));
  }, [loadStatus, hdrs]);

  // ── 30-second status auto-refresh ────────────────────────────────────────
  useEffect(() => {
    const id = setInterval(() => loadStatus(true), 30_000);
    return () => clearInterval(id);
  }, [loadStatus]);

  // ── WS instant kill-switch — admin tab sees its own broadcast immediately ─
  useEffect(() => {
    const unsub = wsSubscribe((event) => {
      if (
        event.type === ("nia_status" as WsEventType) &&
        typeof (event.payload as Record<string, unknown>)?.enabled === "boolean"
      ) {
        const p = event.payload as { enabled: boolean; toggled_at?: string; source?: string };
        setNiaEnabled(p.enabled);
        if (p.toggled_at) setLastToggledAt(p.toggled_at);
        if (p.source === "admin_toggle") {
          setWsReceived({ enabled: p.enabled, at: new Date().toLocaleTimeString() });
          setTimeout(() => setWsReceived(null), 8_000);
        }
      }
    });
    return unsub;
  }, []);

  const submitToggle = async (enabled: boolean) => {
    setConfirmPending(null);
    setToggling(true);
    setBroadcastConfirm(null);
    try {
      const res = await fetch(`${BASE}/api/admin/nia-toggle`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...hdrs() },
        body: JSON.stringify({ enabled }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? "Toggle failed");
      }
      const data = await res.json() as { enabled: boolean; toggled_at: string };
      setNiaEnabled(data.enabled);
      if (data.toggled_at) setLastToggledAt(data.toggled_at);
      setBroadcastConfirm(
        data.enabled
          ? "✅ Nia enabled — WS broadcast sent to all users instantly"
          : "🔴 Nia disabled — WS broadcast sent to all users instantly"
      );
      setTimeout(() => setBroadcastConfirm(null), 7_000);
      toast({ title: data.enabled ? "✅ Nia enabled" : "🔴 Nia disabled" });
    } catch (err) {
      toast({ title: (err as Error).message ?? "Toggle failed", variant: "destructive" });
    } finally {
      setToggling(false);
    }
  };

  const runNiaTest = async () => {
    setTestLoading(true);
    setTestResult(null);
    try {
      const r = await fetch(`${BASE}/api/nia/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...hdrs() },
        body: JSON.stringify({
          message: "ping — admin test",
          sessionId: `admin-test-${Date.now()}`,
        }),
      });
      if (r.status === 503) {
        setTestResult({ ok: false, message: "503 — Nia is disabled (kill-switch is working ✅)" });
      } else if (r.ok) {
        // SSE stream — just check first byte
        const text = await r.text();
        const hasContent = text.trim().length > 0;
        setTestResult({ ok: true, message: hasContent ? "✅ Nia responded — chat is live" : "⚠️ Response was empty" });
      } else {
        const body = await r.json().catch(() => ({})) as { error?: string };
        setTestResult({ ok: false, message: `Error ${r.status}: ${body.error ?? "unknown"}` });
      }
    } catch {
      setTestResult({ ok: false, message: "Network error reaching /api/nia/chat" });
    } finally {
      setTestLoading(false);
    }
  };

  // Format "last toggled" timestamp for display
  const fmtToggled = (iso: string | null): string => {
    if (!iso) return "Never";
    try {
      const d = new Date(iso);
      const diffMs = Date.now() - d.getTime();
      const diffMins = Math.floor(diffMs / 60_000);
      if (diffMins < 1) return "just now";
      if (diffMins < 60) return `${diffMins}m ago`;
      const diffHrs = Math.floor(diffMins / 60);
      if (diffHrs < 24) return `${diffHrs}h ago`;
      return d.toLocaleDateString();
    } catch { return iso; }
  };

  return (
    <div className="space-y-4">

      {/* ── WS instant broadcast confirmation ── */}
      <AnimatePresence>
        {broadcastConfirm && (
          <motion.div
            key="broadcast-confirm"
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className={`flex items-center gap-2.5 rounded-2xl px-4 py-3 text-sm font-bold ${
              niaEnabled
                ? "bg-green-500/10 border border-green-500/30 text-green-600 dark:text-green-400"
                : "bg-destructive/10 border border-destructive/30 text-destructive"
            }`}
          >
            <Zap className="w-4 h-4 shrink-0" />
            <span className="flex-1">{broadcastConfirm}</span>
          </motion.div>
        )}
        {wsReceived && (
          <motion.div
            key="ws-received"
            initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
            className="flex items-center gap-2 rounded-xl px-3 py-2 bg-primary/10 border border-primary/20 text-[11px] text-primary font-bold"
          >
            <Activity className="w-3.5 h-3.5 shrink-0" />
            WS confirmed {wsReceived.enabled ? "ENABLED" : "DISABLED"} at {wsReceived.at}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Daily cost alert banner ── */}
      {costAlert?.alert && (
        <motion.div
          initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          className="flex items-start gap-3 bg-destructive/10 border border-destructive/30 rounded-2xl px-4 py-3"
        >
          <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-black text-destructive">AI Cost Alert</div>
            <div className="text-xs text-muted-foreground mt-0.5">{costAlert.message}</div>
          </div>
        </motion.div>
      )}
      {costAlert && !costAlert.alert && (
        <div className="flex items-center gap-2 text-[11px] text-green-500 bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2">
          <CheckCircle className="w-3.5 h-3.5 shrink-0" />
          <span>Today's AI cost <strong>${costAlert.todayCost.toFixed(3)}</strong> within <strong>${costAlert.threshold.toFixed(2)}</strong>/day threshold</span>
        </div>
      )}

      {/* ── Main status card ── */}
      <motion.div
        layout
        className={`rounded-2xl border p-5 transition-colors ${
          niaEnabled === false ? "bg-destructive/5 border-destructive/30" : "bg-card border-border"
        }`}
      >
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${
              niaEnabled === false ? "bg-destructive/10" : "bg-primary/10"
            }`}>
              <Bot className={`w-5 h-5 ${niaEnabled === false ? "text-destructive" : "text-primary"}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-sm">Nia AI Status</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                {niaEnabled === null ? (
                  <span className="text-xs text-muted-foreground">Checking…</span>
                ) : (
                  <>
                    <span className={`w-2 h-2 rounded-full inline-block shrink-0 ${
                      niaEnabled ? "bg-green-500 animate-pulse" : "bg-muted-foreground"
                    }`} />
                    <span className={`text-xs font-bold ${
                      niaEnabled ? "text-green-600 dark:text-green-400" : "text-muted-foreground"
                    }`}>
                      {niaEnabled ? "Active — all users" : "Disabled — 503"}
                    </span>
                  </>
                )}
              </div>
              {lastToggledAt && (
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  Last changed: {fmtToggled(lastToggledAt)}
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {/* Manual refresh button */}
            <button
              onClick={() => loadStatus()}
              disabled={toggling}
              style={{ touchAction: "manipulation" }}
              className="w-8 h-8 rounded-xl border border-border flex items-center justify-center active:bg-muted disabled:opacity-40"
              title="Refresh status"
            >
              <RefreshCw className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
            {/* Toggle switch */}
            <button
              role="switch"
              aria-checked={niaEnabled ?? false}
              disabled={niaEnabled === null || toggling}
              onClick={() => setConfirmPending(!niaEnabled)}
              style={{ touchAction: "manipulation" }}
              className={`relative w-14 h-7 rounded-full transition-colors disabled:opacity-40 ${
                niaEnabled ? "bg-green-500" : "bg-muted"
              }`}
            >
              {toggling ? (
                <span className="absolute inset-0 flex items-center justify-center">
                  <RefreshCw className="w-3.5 h-3.5 text-white animate-spin" />
                </span>
              ) : (
                <span className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full shadow transition-transform duration-200 ${
                  niaEnabled ? "translate-x-7" : "translate-x-0"
                }`} />
              )}
            </button>
          </div>
        </div>
      </motion.div>

      {/* ── What this toggle controls ── */}
      <div className="bg-card border border-border rounded-2xl p-4 space-y-2">
        <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-2">Toggle affects</div>
        {[
          { icon: MessageSquare, label: "Chat", desc: "POST /api/nia/chat → 503 when off", affected: true },
          { icon: Activity, label: "Voice TTS", desc: "POST /api/nia/voice/speak → 503 when off", affected: true },
          { icon: Sparkles, label: "Context injection", desc: "GET /api/nia/context still available", affected: false },
          { icon: Zap, label: "Crisis suggestions", desc: "Crisis resources still served", affected: false },
          { icon: LifeBuoy, label: "24h check-in AI", desc: "Check-in worker uses direct API", affected: false },
        ].map(({ icon: Icon, label, desc, affected }) => (
          <div key={label} className="flex items-center gap-3">
            <Icon className={`w-3.5 h-3.5 shrink-0 ${affected ? "text-foreground" : "text-muted-foreground"}`} />
            <div className="flex-1 min-w-0">
              <span className={`text-[11px] font-bold ${affected ? "text-foreground" : "text-muted-foreground"}`}>{label}</span>
              <span className="text-[10px] text-muted-foreground ml-2">{desc}</span>
            </div>
            <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${
              affected
                ? (niaEnabled === false ? "bg-destructive/10 text-destructive" : "bg-green-500/10 text-green-600 dark:text-green-400")
                : "bg-muted text-muted-foreground"
            }`}>
              {affected ? (niaEnabled === false ? "OFF" : "ON") : "unaffected"}
            </span>
          </div>
        ))}
      </div>

      {/* ── Test Nia button ── */}
      <div className="bg-card border border-border rounded-2xl p-4 space-y-2">
        <div className="flex items-center justify-between">
          <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">Live Test</div>
          <button
            onClick={runNiaTest}
            disabled={testLoading}
            style={{ touchAction: "manipulation" }}
            className="flex items-center gap-1.5 text-[11px] font-black px-3 py-1.5 rounded-xl bg-primary/10 text-primary border border-primary/20 active:bg-primary/20 disabled:opacity-50"
          >
            {testLoading ? <><RefreshCw className="w-3 h-3 animate-spin" /> Testing…</> : <><Zap className="w-3 h-3" /> Send Test Ping</>}
          </button>
        </div>
        <div className="text-[10px] text-muted-foreground">Sends "ping — admin test" to /api/nia/chat to verify kill-switch is working as expected.</div>
        <AnimatePresence>
          {testResult && (
            <motion.div
              initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
              className={`overflow-hidden rounded-xl px-3 py-2 text-[11px] font-bold ${
                testResult.ok
                  ? "bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-400"
                  : "bg-muted border border-border text-foreground"
              }`}
            >
              {testResult.message}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── System info grid ── */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Persistence</div>
          <div className="text-sm font-bold text-green-500">DB-backed</div>
          <div className="text-[10px] text-muted-foreground">Survives redeploys</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Kill-switch</div>
          <div className="text-sm font-bold">3 layers</div>
          <div className="text-[10px] text-muted-foreground">Proxy + Voice + WS push</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Memory Users</div>
          <div className="text-sm font-bold">{memoryStats?.users ?? "—"}</div>
          <div className="text-[10px] text-muted-foreground">cross-session</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Memory Entries</div>
          <div className="text-sm font-bold">{memoryStats?.entries ?? "—"}</div>
          <div className="text-[10px] text-muted-foreground">total facts</div>
        </div>
      </div>

      {/* Nia AI Cost Dashboard */}
      <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="w-3.5 h-3.5 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">AI Cost Dashboard (7d)</span>
          </div>
          {costLoading && <RefreshCw className="w-3 h-3 text-muted-foreground animate-spin" />}
        </div>

        {costData ? (
          <>
            {/* Summary row */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-background rounded-xl p-2.5 text-center">
                <div className="text-base font-black text-foreground">${costData.summary.totalCostUsd.toFixed(3)}</div>
                <div className="text-[9px] text-muted-foreground mt-0.5">Total Cost</div>
              </div>
              <div className="bg-background rounded-xl p-2.5 text-center">
                <div className="text-base font-black text-primary">{costData.summary.totalCalls.toLocaleString()}</div>
                <div className="text-[9px] text-muted-foreground mt-0.5">API Calls</div>
              </div>
              <div className="bg-background rounded-xl p-2.5 text-center">
                <div className={`text-base font-black ${costData.summary.totalFailed > 0 ? "text-destructive" : "text-green-400"}`}>
                  {costData.summary.totalFailed}
                </div>
                <div className="text-[9px] text-muted-foreground mt-0.5">Failed</div>
              </div>
            </div>
            {/* Avg cost per call */}
            <div className="text-[10px] text-muted-foreground px-0.5">
              Avg <span className="font-bold text-foreground">${costData.summary.averageCostPerCall.toFixed(5)}</span> / call ·{" "}
              <span className="font-bold text-foreground">{(costData.summary.totalInputTokens + costData.summary.totalOutputTokens).toLocaleString()}</span> total tokens
            </div>
            {/* Daily breakdown */}
            {costData.daily.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="text-[9px] font-black uppercase tracking-wider text-muted-foreground">Daily Breakdown</div>
                {costData.daily.slice(0, 5).map(d => (
                  <div key={d.date} className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground w-16 shrink-0 font-mono">{d.date.slice(5)}</span>
                    <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{
                          width: costData.summary.totalCostUsd > 0
                            ? `${Math.max(4, (d.estimatedCostUsd / Math.max(...costData.daily.map(x => x.estimatedCostUsd), 0.0001)) * 100)}%`
                            : "4%",
                        }}
                      />
                    </div>
                    <span className="text-[10px] font-bold text-foreground w-14 text-right shrink-0">
                      ${d.estimatedCostUsd.toFixed(4)}
                    </span>
                    {d.failedCalls > 0 && (
                      <span className="text-[9px] text-destructive shrink-0">{d.failedCalls}✗</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        ) : !costLoading ? (
          <div className="text-[11px] text-muted-foreground text-center py-3">
            Cost data unavailable — nia-service may be offline
          </div>
        ) : null}
      </div>

      {/* Confirm sheet */}
      <AnimatePresence>
        {confirmPending !== null && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
              onClick={() => setConfirmPending(null)}
            />
            <motion.div
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border rounded-t-3xl p-6"
              style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-center mb-4"><div className="w-9 h-1 bg-border rounded-full" /></div>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                  confirmPending ? "bg-green-500/10" : "bg-destructive/10"
                }`}>
                  <Power className={`w-6 h-6 ${confirmPending ? "text-green-500" : "text-destructive"}`} />
                </div>
                <div>
                  <div className="font-black text-base">{confirmPending ? "Enable Nia AI?" : "Disable Nia AI?"}</div>
                  <div className="text-xs text-muted-foreground">
                    {confirmPending ? "Nia becomes available immediately." : "Users see unavailability message."}
                  </div>
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => setConfirmPending(null)}
                  style={{ touchAction: "manipulation" }}
                  className="flex-1 h-12 rounded-2xl border border-border text-sm font-black active:bg-muted"
                >Cancel</button>
                <button
                  onClick={() => submitToggle(confirmPending)}
                  disabled={toggling}
                  style={{ touchAction: "manipulation" }}
                  className={`flex-1 h-12 rounded-2xl text-sm font-black text-white disabled:opacity-50 ${
                    confirmPending ? "bg-green-500 active:bg-green-600" : "bg-destructive active:bg-destructive/80"
                  }`}
                >
                  {toggling ? <span className="flex items-center justify-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" />Saving…</span>
                    : confirmPending ? "Enable Nia" : "Disable Nia"}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Reports Tab ───────────────────────────────────────────────────────────────
// ── Flagged Help Requests — content moderation ────────────────────────────────
function FlaggedRequestsSection() {
  const [items, setItems] = useState<FlaggedRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/requests/flagged`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setItems(await res.json());
      else { const b = await res.json().catch(() => ({})) as {error?:string}; setLoadError(b.error ?? `Error ${res.status}`); }
    } catch { setLoadError("Could not reach server"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (id: number, action: "approve" | "reject") => {
    setProcessing(id);
    try {
      const res = await fetch(`${BASE}/api/admin/requests/${id}/moderate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify({ action }),
      });
      if (res.ok) {
        toast({ title: action === "approve" ? "Request approved — now visible" : "Request rejected and cancelled" });
        setItems(prev => prev.filter(r => r.id !== id));
      } else {
        const body = await res.json().catch(() => ({})) as { error?: string };
        toast({ title: body.error ?? "Action failed", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  if (loading) return <div className="flex justify-center py-10"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>;
  if (loadError) return <div className="flex items-center gap-2 text-sm text-destructive py-6 justify-center"><AlertCircle className="w-4 h-4 shrink-0" />{loadError}<button onClick={load} className="ml-2 underline text-xs">Retry</button></div>;

  if (items.length === 0) return (
    <div className="text-center py-14">
      <ShieldAlert className="w-10 h-10 mx-auto mb-3 text-green-400/40" />
      <div className="font-bold text-sm text-muted-foreground">No flagged requests</div>
      <div className="text-xs text-muted-foreground/60 mt-1">All help requests passed automated moderation</div>
    </div>
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-2xl px-4 py-3">
        <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0" />
        <span className="text-sm font-bold text-yellow-600 dark:text-yellow-400">{items.length} request{items.length !== 1 ? "s" : ""} flagged by automated moderation</span>
        <button onClick={load} className="ml-auto w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted"><RefreshCw className="w-3 h-3" /></button>
      </div>
      {items.map(item => (
        <div key={item.id} className="bg-card border border-yellow-500/20 rounded-2xl p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm">{item.title}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{item.requester_name} · {item.requester_email}</div>
              {item.category && <div className="text-[10px] text-muted-foreground mt-0.5">Category: {item.category}</div>}
              {item.moderation_reason && (
                <div className="mt-1.5 flex items-start gap-1.5 bg-yellow-500/10 rounded-xl px-2.5 py-1.5">
                  <AlertTriangle className="w-3 h-3 text-yellow-500 mt-0.5 shrink-0" />
                  <span className="text-[11px] text-yellow-600 dark:text-yellow-400 leading-relaxed">{item.moderation_reason}</span>
                </div>
              )}
              {item.description && <p className="text-xs text-muted-foreground mt-2 line-clamp-3 leading-relaxed">{item.description}</p>}
            </div>
            <span className="text-[10px] text-muted-foreground shrink-0">{fmtDate(item.created_at)}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => decide(item.id, "reject")}
              disabled={processing === item.id}
              className="h-9 rounded-xl border border-destructive/40 bg-destructive/10 text-destructive text-xs font-black disabled:opacity-50 active:scale-95 transition-all"
            >{processing === item.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto" /> : "✕ Reject"}</button>
            <button
              onClick={() => decide(item.id, "approve")}
              disabled={processing === item.id}
              className="h-9 rounded-xl bg-green-500 text-white text-xs font-black disabled:opacity-50 active:scale-95 transition-all"
            >{processing === item.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto" /> : "✓ Approve"}</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Post Moderation — gratitude posts pending review ──────────────────────────
function PostModerationSection() {
  const [posts, setPosts] = useState<GratitudePost[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/moderation-queue`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setPosts(await res.json());
      else { const b = await res.json().catch(() => ({})) as {error?:string}; setLoadError(b.error ?? `Error ${res.status}`); }
    } catch { setLoadError("Could not reach server"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (id: number, decision: "approve" | "reject") => {
    setProcessing(id);
    try {
      const res = await fetch(`${BASE}/api/admin/moderation-queue/${id}/decide`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify({ decision }),
      });
      if (res.ok) {
        toast({ title: decision === "approve" ? "Post approved — now live" : "Post rejected and removed" });
        setPosts(prev => prev.filter(p => p.id !== id));
      } else {
        toast({ title: "Action failed", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  if (loading) return <div className="flex justify-center py-10"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>;
  if (loadError) return <div className="flex items-center gap-2 text-sm text-destructive py-6 justify-center"><AlertCircle className="w-4 h-4 shrink-0" />{loadError}<button onClick={load} className="ml-2 underline text-xs">Retry</button></div>;

  if (posts.length === 0) return (
    <div className="text-center py-14">
      <CheckCircle2 className="w-10 h-10 mx-auto mb-3 text-green-400/40" />
      <div className="font-bold text-sm text-muted-foreground">No posts pending review</div>
      <div className="text-xs text-muted-foreground/60 mt-1">Community feed is fully moderated</div>
    </div>
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-2xl px-4 py-3">
        <Megaphone className="w-4 h-4 text-primary shrink-0" />
        <span className="text-sm font-bold text-primary">{posts.length} gratitude post{posts.length !== 1 ? "s" : ""} awaiting review</span>
        <button onClick={load} className="ml-auto w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted"><RefreshCw className="w-3 h-3" /></button>
      </div>
      {posts.map(post => (
        <div key={post.id} className="bg-card border border-border rounded-2xl p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm">{post.author_name}</div>
              {post.moderation_reason && (
                <div className="mt-1 text-[10px] text-yellow-500 bg-yellow-500/10 rounded-lg px-2 py-1">Flag: {post.moderation_reason}</div>
              )}
              <p className="text-sm text-foreground mt-2 leading-relaxed">{post.content}</p>
            </div>
            <span className="text-[10px] text-muted-foreground shrink-0">{fmtDate(post.created_at)}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => decide(post.id, "reject")}
              disabled={processing === post.id}
              className="h-9 rounded-xl border border-destructive/40 bg-destructive/10 text-destructive text-xs font-black disabled:opacity-50 active:scale-95 transition-all"
            >{processing === post.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto" /> : "Remove Post"}</button>
            <button
              onClick={() => decide(post.id, "approve")}
              disabled={processing === post.id}
              className="h-9 rounded-xl bg-green-500 text-white text-xs font-black disabled:opacity-50 active:scale-95 transition-all"
            >{processing === post.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin mx-auto" /> : "Publish ✓"}</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function UserReportsSection({ authed }: { authed: boolean }) {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);

  const fetchReports = useCallback(async (status?: string) => {
    setLoading(true);
    try {
      const url = status && status !== "all" ? `${BASE}/api/reports?status=${status}` : `${BASE}/api/reports`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed");
      setReports(await res.json() as Report[]);
    } catch { toast({ title: "Could not load reports", variant: "destructive" }); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { if (authed) fetchReports(statusFilter); }, [statusFilter, authed, fetchReports]);

  const handleReviewed = (updated: Report) => setReports(prev => prev.map(r => r.id === updated.id ? { ...r, ...updated } : r));
  const pendingCount = reports.filter(r => r.status === "pending").length;
  const filtered = statusFilter === "all" ? reports : reports.filter(r => r.status === statusFilter);

  return (
    <>
      {pendingCount > 0 && (
        <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-2xl px-4 py-3">
          <AlertCircle className="w-4 h-4 text-yellow-500 shrink-0" />
          <span className="text-sm font-bold text-yellow-600 dark:text-yellow-400">{pendingCount} report{pendingCount !== 1 ? "s" : ""} awaiting review</span>
          <button onClick={() => setStatusFilter("pending")} style={{ touchAction: "manipulation" }}
            className="ml-auto text-[10px] font-black bg-yellow-500 text-black px-2.5 py-1 rounded-full">View</button>
        </div>
      )}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1 -mx-4 px-4">
        {STATUS_FILTERS.map(s => {
          const meta = STATUS_LABELS[s];
          const isActive = statusFilter === s;
          return (
            <button key={s} onClick={() => setStatusFilter(s)} style={{ touchAction: "manipulation" }}
              className={`shrink-0 text-[11px] font-bold px-3 py-2 rounded-full border transition-all ${isActive ? s === "all" ? "bg-primary text-primary-foreground border-primary" : (meta?.color ?? "bg-primary text-primary-foreground border-primary") : "bg-card border-border text-muted-foreground"}`}>
              {s === "all" ? "All" : meta?.label ?? s}
            </button>
          );
        })}
      </div>
      {loading && <div className="flex items-center justify-center py-16 gap-2 text-muted-foreground"><RefreshCw className="w-5 h-5 animate-spin" /><span className="text-sm">Loading…</span></div>}
      {!loading && filtered.length === 0 && (
        <div className="text-center py-16"><CheckCircle2 className="w-10 h-10 mx-auto mb-3 text-green-400/40" /><div className="font-bold text-sm text-muted-foreground">{statusFilter === "all" ? "No reports yet" : "Queue is clear"}</div></div>
      )}
      {!loading && filtered.map(report => {
        const statusMeta = STATUS_LABELS[report.status] ?? { label: report.status, color: "bg-muted text-muted-foreground border-border" };
        return (
          <motion.button key={report.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            onClick={() => setSelectedReport(report)} style={{ touchAction: "manipulation" }}
            className="w-full text-left bg-card border border-border rounded-2xl p-4 active:border-primary/40 transition-all">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${statusMeta.color}`}>{statusMeta.label}</span>
                  <span className="text-[10px] font-semibold bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{TYPE_LABELS[report.type] ?? report.type}</span>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">{report.description}</p>
                <div className="flex items-center gap-3 mt-2 flex-wrap text-[10px] text-muted-foreground">
                  {report.reported_user_id && <span className="flex items-center gap-1"><UserIcon className="w-3 h-3" />User #{report.reported_user_id}</span>}
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{fmtDate(report.created_at)}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {report.status === "pending" && <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />}
                <Eye className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          </motion.button>
        );
      })}
      {selectedReport && <ReportDetailSheet report={selectedReport} onClose={() => setSelectedReport(null)} onReviewed={handleReviewed} />}
    </>
  );
}

// ── Reports Tab — 3-section moderation hub ────────────────────────────────────
function ReportsTab({ authed }: { authed: boolean }) {
  const [section, setSection] = useState<"user-reports" | "flagged" | "posts">("user-reports");

  const SECTIONS = [
    { key: "user-reports", label: "User Reports", icon: Flag },
    { key: "flagged",      label: "Flagged Requests", icon: ShieldAlert },
    { key: "posts",        label: "Post Moderation", icon: Megaphone },
  ] as const;

  return (
    <div className="space-y-4">
      {/* Section sub-nav */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1 -mx-4 px-4">
        {SECTIONS.map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setSection(key)} style={{ touchAction: "manipulation" }}
            className={`shrink-0 flex items-center gap-1.5 text-[11px] font-bold px-3.5 py-2 rounded-full border transition-all ${section === key ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-muted-foreground"}`}>
            <Icon className="w-3.5 h-3.5" />{label}
          </button>
        ))}
      </div>
      {section === "user-reports" && <UserReportsSection authed={authed} />}
      {section === "flagged"      && <FlaggedRequestsSection />}
      {section === "posts"        && <PostModerationSection />}
    </div>
  );
}


// ── Helper Applications Tab ───────────────────────────────────────────────────
interface PendingHelper {
  id: number;
  name: string;
  email: string;
  helper_status: string | null;
  helper_skills: string[] | null;
  helper_bio: string | null;
  helper_languages: string[] | null;
  helper_vehicle: string | null;
  created_at: string;
}

function HelperApplicationsTab() {
  const [pending, setPending] = useState<PendingHelper[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  useEffect(() => {
    const tok = getToken();
    fetch(`${BASE}/api/users?limit=500`, {
      headers: tok ? { Authorization: `Bearer ${tok}` } : {},
    })
      .then(r => r.json())
      .then((data: { users: PendingHelper[] }) => {
        const users = Array.isArray(data.users) ? data.users : [];
        setPending(users.filter(u => u.helper_status === "pending"));
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const decide = async (userId: number, decision: "approved" | "denied") => {
    setProcessing(userId);
    try {
      const tok = getToken();
      const res = await fetch(`${BASE}/api/users/${userId}/helper-application`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(tok ? { Authorization: `Bearer ${tok}` } : {}) },
        body: JSON.stringify({ status: decision }),
      });
      if (!res.ok) throw new Error("Failed");
      setPending(prev => prev.filter(u => u.id !== userId));
      toast({ title: decision === "approved" ? "Helper approved ✅" : "Application denied" });
    } catch {
      toast({ title: "Action failed", variant: "destructive" });
    } finally {
      setProcessing(null);
      setExpanded(null);
    }
  };

  if (loading) return (
    <div className="flex items-center justify-center py-16 gap-2 text-muted-foreground">
      <RefreshCw className="w-5 h-5 animate-spin" /><span className="text-sm">Loading applications…</span>
    </div>
  );

  if (pending.length === 0) return (
    <div className="text-center py-20">
      <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-green-400/40" />
      <div className="font-black text-base text-muted-foreground">No pending applications</div>
      <div className="text-xs text-muted-foreground/60 mt-1">All applications reviewed</div>
    </div>
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-2xl px-4 py-3">
        <UserIcon className="w-4 h-4 text-primary shrink-0" />
        <span className="text-sm font-bold text-primary">{pending.length} application{pending.length !== 1 ? "s" : ""} awaiting review</span>
      </div>
      {pending.map(u => (
        <div key={u.id} className="bg-card border border-border rounded-2xl overflow-hidden">
          <button
            onClick={() => setExpanded(expanded === u.id ? null : u.id)}
            style={{ touchAction: "manipulation" }}
            className="w-full flex items-center gap-3 p-4 active:bg-muted/40 transition-colors text-left"
          >
            <div className="w-11 h-11 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 font-black text-primary">
              {u.name[0]?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-sm truncate">{u.name}</div>
              <div className="text-[11px] text-muted-foreground truncate">{u.email}</div>
              {u.helper_skills && u.helper_skills.length > 0 && (
                <div className="flex gap-1 mt-1 flex-wrap">
                  {u.helper_skills.slice(0, 3).map(s => (
                    <span key={s} className="text-[10px] bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-full font-bold">{s}</span>
                  ))}
                  {u.helper_skills.length > 3 && <span className="text-[10px] text-muted-foreground">+{u.helper_skills.length - 3} more</span>}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[10px] text-muted-foreground">{fmtDate(u.created_at)}</span>
              {expanded === u.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>
          </button>
          <AnimatePresence>
            {expanded === u.id && (
              <motion.div
                initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden border-t border-border"
              >
                <div className="p-4 space-y-3">
                  {u.helper_bio && (
                    <div>
                      <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Bio</div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{u.helper_bio}</p>
                    </div>
                  )}
                  {u.helper_languages && u.helper_languages.length > 0 && (
                    <div>
                      <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Languages</div>
                      <div className="flex gap-1 flex-wrap">
                        {u.helper_languages.map(l => (
                          <span key={l} className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{l}</span>
                        ))}
                      </div>
                    </div>
                  )}
                  {u.helper_vehicle && (
                    <div>
                      <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-1">Transport</div>
                      <div className="text-sm">{u.helper_vehicle}</div>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => decide(u.id, "denied")}
                      disabled={processing === u.id}
                      style={{ touchAction: "manipulation" }}
                      className="h-11 rounded-xl border border-destructive/40 bg-destructive/10 text-destructive text-sm font-black disabled:opacity-50 active:opacity-70 transition-opacity"
                    >{processing === u.id ? <RefreshCw className="w-4 h-4 animate-spin mx-auto" /> : "Deny"}</button>
                    <button
                      onClick={() => decide(u.id, "approved")}
                      disabled={processing === u.id}
                      style={{ touchAction: "manipulation" }}
                      className="h-11 rounded-xl bg-green-500 text-white text-sm font-black disabled:opacity-50 active:opacity-70 transition-opacity"
                    >{processing === u.id ? <RefreshCw className="w-4 h-4 animate-spin mx-auto" /> : "Approve ✓"}</button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}

// ── Orgs Tab — businesses + government sponsor review queue ──────────────────
function OrgsTab({ authed }: { authed: boolean }) {
  const [businesses, setBusinesses] = useState<{
    id: number; legal_name: string; display_name: string;
    approval_status: string; created_at: string;
  }[]>([]);
  const [govSponsors, setGovSponsors] = useState<{
    id: number; entity_name: string; county: string; state: string;
    contact_name: string; contact_email: string; description: string | null;
    approval_status: string; created_at: string;
    submitter_name?: string | null; submitter_email?: string | null;
  }[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<string | null>(null);
  const [fundingId, setFundingId] = useState<number | null>(null);
  const [fundAmount, setFundAmount] = useState("");

  const authHeaders = (): Record<string, string> => {
    const t = getToken();
    return t ? { Authorization: `Bearer ${t}` } : {};
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [bRes, gRes] = await Promise.all([
        fetch(`${BASE}/api/admin/businesses`, { headers: authHeaders() }),
        fetch(`${BASE}/api/admin/gov-sponsors`, { headers: authHeaders() }),
      ]);
      if (bRes.ok) setBusinesses(await bRes.json());
      if (gRes.ok) setGovSponsors(await gRes.json());
    } catch { /* non-critical */ } finally { setLoading(false); }
  }, []);

  useEffect(() => { if (authed) load(); }, [authed, load]);

  const decideBusiness = async (id: number, status: "approved" | "rejected") => {
    const key = `b-${id}`;
    setProcessing(key);
    try {
      const res = await fetch(`${BASE}/api/admin/businesses/${id}/approve`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ approval_status: status }),
      });
      if (!res.ok) throw new Error("Failed");
      setBusinesses(prev => prev.map(b => b.id === id ? { ...b, approval_status: status } : b));
      toast({ title: `Business ${status}` });
    } catch { toast({ title: "Error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  const decideGovSponsor = async (id: number, status: "approved" | "rejected") => {
    const key = `g-${id}`;
    setProcessing(key);
    try {
      const res = await fetch(`${BASE}/api/admin/gov-sponsors/${id}/approve`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ approval_status: status }),
      });
      if (!res.ok) throw new Error("Failed");
      setGovSponsors(prev => prev.map(g => g.id === id ? { ...g, approval_status: status } : g));
      toast({ title: `Gov sponsor ${status}` });
    } catch { toast({ title: "Error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  const fundPool = async (id: number, entityName: string) => {
    const dollars = parseFloat(fundAmount);
    if (!Number.isFinite(dollars) || dollars <= 0) {
      toast({ title: "Enter a valid dollar amount", variant: "destructive" });
      return;
    }
    const key = `fund-${id}`;
    setProcessing(key);
    try {
      const res = await fetch(`${BASE}/api/gov-sponsors/${id}/fund`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ amount: dollars }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? "Funding failed");
      }
      const result = await res.json() as { new_pool_balance: number; backfilled_helpers: number };
      toast({
        title: `Pool funded! $${dollars.toFixed(2)} from ${entityName}`,
        description: `New balance: $${result.new_pool_balance.toFixed(2)}${result.backfilled_helpers > 0 ? ` · ${result.backfilled_helpers} helper(s) backfilled` : ""}`,
      });
      setFundingId(null);
      setFundAmount("");
    } catch (err) {
      toast({ title: err instanceof Error ? err.message : "Funding failed", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  const statusBadge = (s: string) => {
    if (s === "approved") return <span className="text-[10px] font-black text-green-500 bg-green-500/10 px-2 py-0.5 rounded-full border border-green-500/20">Approved</span>;
    if (s === "rejected") return <span className="text-[10px] font-black text-destructive bg-destructive/10 px-2 py-0.5 rounded-full border border-destructive/20">Rejected</span>;
    return <span className="text-[10px] font-black text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded-full border border-yellow-500/20">Pending</span>;
  };

  const ActionButtons = ({ id, kind, status }: { id: number; kind: "b" | "g"; status: string }) => {
    if (status !== "pending") return null;
    const key = `${kind}-${id}`;
    const decide = kind === "b" ? decideBusiness : decideGovSponsor;
    return (
      <div className="grid grid-cols-2 gap-2 mt-2">
        <button
          onClick={() => decide(id, "rejected")}
          disabled={processing === key}
          style={{ touchAction: "manipulation" }}
          className="h-9 rounded-xl border border-destructive/40 bg-destructive/10 text-destructive text-xs font-black disabled:opacity-50"
        >{processing === key ? <RefreshCw className="w-3 h-3 animate-spin mx-auto" /> : "Reject"}</button>
        <button
          onClick={() => decide(id, "approved")}
          disabled={processing === key}
          style={{ touchAction: "manipulation" }}
          className="h-9 rounded-xl bg-green-500 text-white text-xs font-black disabled:opacity-50"
        >{processing === key ? <RefreshCw className="w-3 h-3 animate-spin mx-auto" /> : "Approve ✓"}</button>
      </div>
    );
  };

  if (loading) return <div className="flex justify-center py-12"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>;

  const pendingBusinesses = businesses.filter(b => b.approval_status === "pending");
  const pendingGov = govSponsors.filter(g => g.approval_status === "pending");

  return (
    <div className="space-y-6 pb-8">
      {/* Business Applications */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5" />
            Business Applications
            {pendingBusinesses.length > 0 && (
              <span className="bg-yellow-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded-full">{pendingBusinesses.length}</span>
            )}
          </div>
        </div>
        {businesses.length === 0 ? (
          <div className="rounded-xl border border-border bg-card/50 p-4 text-center text-sm text-muted-foreground">No applications yet.</div>
        ) : (
          <div className="space-y-2">
            {businesses.map(b => (
              <div key={b.id} className="rounded-xl border border-border bg-card p-3 space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-bold">{b.display_name}</p>
                    <p className="text-[11px] text-muted-foreground">{b.legal_name}</p>
                    <p className="text-[10px] text-muted-foreground/70">{fmtDate(b.created_at)}</p>
                  </div>
                  {statusBadge(b.approval_status)}
                </div>
                <ActionButtons id={b.id} kind="b" status={b.approval_status} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Government Sponsor Applications */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Landmark className="w-3.5 h-3.5" />
            Gov Sponsor Applications
            {pendingGov.length > 0 && (
              <span className="bg-yellow-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded-full">{pendingGov.length}</span>
            )}
          </div>
        </div>
        {govSponsors.length === 0 ? (
          <div className="rounded-xl border border-border bg-card/50 p-4 text-center text-sm text-muted-foreground">No applications yet.</div>
        ) : (
          <div className="space-y-2">
            {govSponsors.map(g => (
              <div key={g.id} className="rounded-xl border border-border bg-card p-3 space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-bold">{g.entity_name}</p>
                    <p className="text-[11px] text-muted-foreground">{g.county}, {g.state}</p>
                    <p className="text-[11px] text-muted-foreground">{g.contact_name} · {g.contact_email}</p>
                    {g.submitter_name && (
                      <p className="text-[10px] text-muted-foreground/70">Submitted by {g.submitter_name} · {fmtDate(g.created_at)}</p>
                    )}
                    {g.description && <p className="text-[11px] text-muted-foreground/80 mt-1 leading-relaxed">{g.description}</p>}
                  </div>
                  {statusBadge(g.approval_status)}
                </div>
                <ActionButtons id={g.id} kind="g" status={g.approval_status} />
                {g.approval_status === "approved" && (
                  <div className="mt-2">
                    {fundingId === g.id ? (
                      <div className="flex gap-2 items-center">
                        <div className="relative flex-1">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">$</span>
                          <input
                            type="number"
                            min="1"
                            step="0.01"
                            placeholder="0.00"
                            value={fundAmount}
                            onChange={e => setFundAmount(e.target.value)}
                            className="w-full h-9 rounded-xl bg-muted/40 border border-primary/30 text-sm pl-6 pr-3 outline-none focus:ring-1 focus:ring-primary"
                            style={{ fontSize: "16px" }}
                          />
                        </div>
                        <button
                          onClick={() => fundPool(g.id, g.entity_name)}
                          disabled={processing === `fund-${g.id}`}
                          style={{ touchAction: "manipulation" }}
                          className="h-9 px-3 rounded-xl bg-primary text-black text-xs font-black disabled:opacity-50 shrink-0"
                        >{processing === `fund-${g.id}` ? <RefreshCw className="w-3 h-3 animate-spin" /> : "Fund Pool"}</button>
                        <button
                          onClick={() => { setFundingId(null); setFundAmount(""); }}
                          className="h-9 px-2 rounded-xl border border-border text-xs text-muted-foreground"
                        >✕</button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setFundingId(g.id)}
                        style={{ touchAction: "manipulation" }}
                        className="w-full h-9 rounded-xl border border-primary/40 bg-primary/10 text-primary text-xs font-black"
                      >+ Fund Community Pool</button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Crisis Mode Control ───────────────────────────────────────────────────────
function CrisisModeSection() {
  const [crisisStatus, setCrisisStatus] = useState<{
    active: boolean; level?: string; message?: string; activatedAt?: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState(false);
  const [showActivate, setShowActivate] = useState(false);
  const [level, setLevel] = useState<"info" | "warning" | "critical">("warning");
  const [message, setMessage] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch(`${BASE}/api/crisis/status`);
      if (res.ok) setCrisisStatus(await res.json());
    } catch { /* non-critical */ } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const activate = async () => {
    setActing(true);
    try {
      const res = await fetch(`${BASE}/api/crisis/activate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify({ level, message: message.trim() || undefined }),
      });
      if (res.ok) {
        setCrisisStatus(await res.json());
        toast({ title: `⚠️ Crisis mode activated (${level})` });
        setShowActivate(false);
        setMessage("");
      } else {
        const b = await res.json().catch(() => ({})) as { error?: string };
        toast({ title: b.error ?? "Failed to activate", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setActing(false); }
  };

  const deactivate = async () => {
    setActing(true);
    try {
      const res = await fetch(`${BASE}/api/crisis/deactivate`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        setCrisisStatus(await res.json());
        toast({ title: "Crisis mode deactivated" });
      } else {
        toast({ title: "Failed to deactivate", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setActing(false); }
  };

  const levelColor = (l?: string) => ({
    info: "text-blue-400 bg-blue-400/10 border-blue-400/30",
    warning: "text-yellow-400 bg-yellow-400/10 border-yellow-400/30",
    critical: "text-destructive bg-destructive/10 border-destructive/30",
  }[l ?? "warning"] ?? "text-muted-foreground bg-muted border-border");

  if (loading) return <div className="flex justify-center py-6"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Siren className="w-4 h-4 text-destructive" />
          <span className="text-sm font-black uppercase tracking-wider">Crisis Mode</span>
        </div>
        <div className={`flex items-center gap-1.5 text-[10px] font-black px-2.5 py-1 rounded-full border ${crisisStatus?.active ? levelColor(crisisStatus.level) : "text-green-400 bg-green-400/10 border-green-400/30"}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${crisisStatus?.active ? "bg-current animate-pulse" : "bg-green-400"}`} />
          {crisisStatus?.active ? `ACTIVE — ${(crisisStatus.level ?? "warning").toUpperCase()}` : "INACTIVE"}
        </div>
      </div>

      <p className="text-xs text-muted-foreground leading-relaxed">
        Activating crisis mode broadcasts an emergency banner to all users, surfaces crisis resource links, and triggers priority dispatch for nearby helpers. Use only for real community emergencies.
      </p>

      {crisisStatus?.active && (
        <div className={`rounded-xl border p-3 space-y-1 ${levelColor(crisisStatus.level)}`}>
          {crisisStatus.message && <p className="text-sm font-semibold leading-relaxed">{crisisStatus.message}</p>}
          {crisisStatus.activatedAt && <p className="text-[10px] opacity-70">Activated: {new Date(crisisStatus.activatedAt).toLocaleString()}</p>}
        </div>
      )}

      {crisisStatus?.active ? (
        <button onClick={deactivate} disabled={acting}
          className="w-full h-11 rounded-xl bg-green-500 text-white text-sm font-black disabled:opacity-50 active:scale-95 transition-all flex items-center justify-center gap-2">
          {acting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
          Deactivate Crisis Mode
        </button>
      ) : (
        <>
          {!showActivate ? (
            <button onClick={() => setShowActivate(true)}
              className="w-full h-11 rounded-xl border border-destructive/50 bg-destructive/10 text-destructive text-sm font-black active:scale-95 transition-all flex items-center justify-center gap-2">
              <Siren className="w-4 h-4" /> Activate Crisis Mode
            </button>
          ) : (
            <div className="space-y-3">
              <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">Severity Level</div>
              <div className="grid grid-cols-3 gap-2">
                {(["info", "warning", "critical"] as const).map(l => (
                  <button key={l} onClick={() => setLevel(l)}
                    className={`h-9 rounded-xl border text-xs font-black capitalize transition-all ${level === l ? levelColor(l) : "border-border text-muted-foreground"}`}>
                    {l}
                  </button>
                ))}
              </div>
              <textarea value={message} onChange={e => setMessage(e.target.value)}
                placeholder="Optional custom message shown to users…"
                rows={2}
                className="w-full text-sm bg-background border border-border rounded-xl p-3 resize-none focus:outline-none focus:ring-1 focus:ring-primary text-foreground placeholder:text-muted-foreground"
                maxLength={400}
              />
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setShowActivate(false)}
                  className="h-10 rounded-xl border border-border text-sm text-muted-foreground font-bold">Cancel</button>
                <button onClick={activate} disabled={acting}
                  className="h-10 rounded-xl bg-destructive text-white text-sm font-black disabled:opacity-50 active:scale-95">
                  {acting ? <RefreshCw className="w-4 h-4 animate-spin mx-auto" /> : "⚠️ Activate"}
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── Civic Suggestions Review ──────────────────────────────────────────────────
function CivicSuggestionsSection() {
  const [items, setItems] = useState<CivicSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/civic-suggestions?status=pending`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setItems(await res.json());
      else { const b = await res.json().catch(() => ({})) as {error?:string}; setLoadError(b.error ?? `Error ${res.status}`); }
    } catch { setLoadError("Could not reach server"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (id: number, status: "approved" | "dismissed") => {
    setProcessing(id);
    try {
      const res = await fetch(`${BASE}/api/admin/civic-suggestions/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        toast({ title: status === "approved" ? "Resource approved — added to directory" : "Suggestion dismissed" });
        setItems(prev => prev.filter(i => i.id !== id));
      } else { toast({ title: "Action failed", variant: "destructive" }); }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-primary" />
          <span className="text-sm font-black uppercase tracking-wider">Civic Resource Suggestions</span>
          {items.length > 0 && <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400/10 text-yellow-400 border border-yellow-400/20">{items.length}</span>}
        </div>
        <button onClick={load} className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted"><RefreshCw className="w-3.5 h-3.5" /></button>
      </div>
      <p className="text-xs text-muted-foreground">Community-submitted links to local food banks, shelters, clinics, and services. Approve to add to the civic directory; dismiss if not relevant.</p>
      {loading ? (
        <div className="flex justify-center py-4"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : loadError ? (
        <div className="flex items-center gap-2 text-sm text-destructive py-4 justify-center"><AlertCircle className="w-4 h-4" />{loadError}<button onClick={load} className="ml-2 underline text-xs">Retry</button></div>
      ) : items.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-3">No pending suggestions.</p>
      ) : (
        <div className="space-y-3">
          {items.map(item => (
            <div key={item.id} className="border border-border rounded-xl p-3 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{item.name}</div>
                  {item.category && <div className="text-[10px] text-muted-foreground">{item.category}</div>}
                  {item.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{item.description}</p>}
                  <div className="flex gap-3 mt-1 text-[10px] text-muted-foreground">
                    {item.phone && <span className="flex items-center gap-1">📞 {item.phone}</span>}
                    {item.website && <span className="flex items-center gap-1"><Link className="w-3 h-3" />{item.website}</span>}
                  </div>
                </div>
                <span className="text-[10px] text-muted-foreground shrink-0">{fmtDate(item.created_at)}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => decide(item.id, "dismissed")} disabled={processing === item.id}
                  className="h-8 rounded-lg border border-border text-[11px] font-black text-muted-foreground disabled:opacity-50 active:scale-95">Dismiss</button>
                <button onClick={() => decide(item.id, "approved")} disabled={processing === item.id}
                  className="h-8 rounded-lg bg-green-500 text-white text-[11px] font-black disabled:opacity-50 active:scale-95">Approve ✓</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Settings Tab — Community Pool wage floors and feature toggles ─────────────
function SettingsTab() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<{
    pool_enabled: boolean;
    pool_minimum_hourly_rate: number;
    pool_guaranteed_minimum: number;
  } | null>(null);

  const [form, setForm] = useState({
    pool_enabled: true,
    pool_minimum_hourly_rate: "15",
    pool_guaranteed_minimum: "20",
  });

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/admin/pool-settings", {
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        if (!res.ok) throw new Error("Failed to load");
        const data = await res.json() as typeof settings;
        setSettings(data);
        if (data) {
          setForm({
            pool_enabled: data.pool_enabled,
            pool_minimum_hourly_rate: String(data.pool_minimum_hourly_rate),
            pool_guaranteed_minimum: String(data.pool_guaranteed_minimum),
          });
        }
      } catch {
        toast({ title: "Failed to load pool settings", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const handleSave = async () => {
    const hourlyRate = parseFloat(form.pool_minimum_hourly_rate);
    const flatMin = parseFloat(form.pool_guaranteed_minimum);
    if (!Number.isFinite(hourlyRate) || hourlyRate <= 0) {
      toast({ title: "Invalid hourly rate", description: "Must be a positive number.", variant: "destructive" });
      return;
    }
    if (!Number.isFinite(flatMin) || flatMin < 0) {
      toast({ title: "Invalid flat minimum", description: "Must be 0 or greater.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/admin/pool-settings", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${getToken()}`,
        },
        body: JSON.stringify({
          pool_enabled: form.pool_enabled,
          pool_minimum_hourly_rate: hourlyRate,
          pool_guaranteed_minimum: flatMin,
        }),
      });
      if (!res.ok) {
        const err = await res.json() as { error?: string };
        throw new Error(err.error ?? "Failed to save");
      }
      setSettings({ pool_enabled: form.pool_enabled, pool_minimum_hourly_rate: hourlyRate, pool_guaranteed_minimum: flatMin });
      toast({ title: "Pool settings saved", description: "Changes take effect immediately for all new payouts." });
    } catch (err) {
      toast({ title: "Save failed", description: String(err), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const changed =
    form.pool_enabled !== (settings?.pool_enabled ?? true) ||
    parseFloat(form.pool_minimum_hourly_rate) !== (settings?.pool_minimum_hourly_rate ?? 15) ||
    parseFloat(form.pool_guaranteed_minimum) !== (settings?.pool_guaranteed_minimum ?? 20);

  return (
    <div className="space-y-6 pb-8">
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1">Community Pool Settings</div>

      {/* Pool on/off toggle */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-bold text-sm">Community Pool</div>
            <div className="text-xs text-muted-foreground mt-0.5">
              When disabled, the pool will not front payments or pay guaranteed minimums.
            </div>
          </div>
          <button
            onClick={() => setForm((f) => ({ ...f, pool_enabled: !f.pool_enabled }))}
            className={`relative w-11 h-6 rounded-full transition-colors ${form.pool_enabled ? "bg-primary" : "bg-muted"}`}
            style={{ touchAction: "manipulation" }}
          >
            <span
              className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${form.pool_enabled ? "translate-x-5" : "translate-x-0"}`}
            />
          </button>
        </div>
        <div className={`text-xs font-bold text-center py-1.5 rounded-xl ${form.pool_enabled ? "bg-green-500/10 text-green-400" : "bg-destructive/10 text-destructive"}`}>
          {form.pool_enabled ? "Pool is ACTIVE — helpers will be paid" : "Pool is PAUSED — no payouts will be issued"}
        </div>
      </div>

      {/* Wage floor settings */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-5">
        <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">Helper Wage Floors</div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold">Minimum Hourly Rate</label>
          <p className="text-xs text-muted-foreground">
            Used to compute the guaranteed minimum when a request has an estimated duration
            (guaranteed = max(flat minimum, hours × hourly rate)).
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span className="text-muted-foreground font-bold">$</span>
            <input
              type="number"
              min="1"
              max="999"
              step="0.25"
              value={form.pool_minimum_hourly_rate}
              onChange={(e) => setForm((f) => ({ ...f, pool_minimum_hourly_rate: e.target.value }))}
              className="flex-1 px-4 py-2.5 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <span className="text-muted-foreground text-sm">/ hr</span>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold">Flat Guaranteed Minimum</label>
          <p className="text-xs text-muted-foreground">
            Fallback floor when no hours estimate exists. Also used as the minimum when
            the hourly calculation is lower than this value.
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span className="text-muted-foreground font-bold">$</span>
            <input
              type="number"
              min="0"
              max="9999"
              step="1"
              value={form.pool_guaranteed_minimum}
              onChange={(e) => setForm((f) => ({ ...f, pool_guaranteed_minimum: e.target.value }))}
              className="flex-1 px-4 py-2.5 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <span className="text-muted-foreground text-sm">flat</span>
          </div>
        </div>
      </div>

      {/* Current live values (from last save) */}
      {settings && (
        <div className="bg-muted/40 border border-border rounded-2xl p-4 space-y-2">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-2">Current Live Values</div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Pool status</span>
            <span className={`font-bold ${settings.pool_enabled ? "text-green-400" : "text-destructive"}`}>
              {settings.pool_enabled ? "Active" : "Paused"}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Hourly rate</span>
            <span className="font-bold">${settings.pool_minimum_hourly_rate.toFixed(2)}/hr</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Flat minimum</span>
            <span className="font-bold">${settings.pool_guaranteed_minimum.toFixed(2)}</span>
          </div>
        </div>
      )}

      <button
        onClick={handleSave}
        disabled={saving || !changed}
        className="w-full py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider bg-primary text-primary-foreground flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed active:opacity-80 transition-opacity"
        style={{ touchAction: "manipulation" }}
      >
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
        {saving ? "Saving…" : changed ? "Save Changes" : "No Changes"}
      </button>

      {/* ToS version info (informational — no editable setting) */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-2">
        <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">ToS Version Gate</div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Current enforced version: <span className="font-bold text-foreground">2026-07</span>. Users who accepted an older version are blocked from
          posting waiver-gated requests until they re-accept. To update the version, change{" "}
          <code className="bg-muted px-1 py-0.5 rounded text-[10px]">CURRENT_TOS_VERSION</code> in both{" "}
          <code className="bg-muted px-1 py-0.5 rounded text-[10px]">WaiverModal.tsx</code> and{" "}
          <code className="bg-muted px-1 py-0.5 rounded text-[10px]">requests.ts</code>.
        </p>
      </div>

      {/* ── Crisis Mode ─────────────────────────────────────────────────────── */}
      <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 pt-2">Emergency Controls</div>
      <CrisisModeSection />

      {/* ── Civic Suggestions ───────────────────────────────────────────────── */}
      <CivicSuggestionsSection />
    </div>
  );
}

// ── Neighborhoods Management ──────────────────────────────────────────────────
function NeighborhoodsSection() {
  const [items, setItems] = useState<Neighborhood[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/city-neighborhoods`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setItems(await res.json());
      else { const b = await res.json().catch(() => ({})) as {error?:string}; setLoadError(b.error ?? `Error ${res.status}`); }
    } catch { setLoadError("Could not reach server"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleVerify = async (item: Neighborhood) => {
    setProcessing(item.id);
    try {
      const res = await fetch(`${BASE}/api/admin/city-neighborhoods/${item.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify({ verified: !item.verified }),
      });
      if (res.ok) {
        toast({ title: item.verified ? "Neighborhood unverified" : "Neighborhood verified ✓" });
        setItems(prev => prev.map(n => n.id === item.id ? { ...n, verified: !n.verified } : n));
      } else { toast({ title: "Failed", variant: "destructive" }); }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  const deleteItem = async (id: number) => {
    setProcessing(id);
    try {
      const res = await fetch(`${BASE}/api/admin/city-neighborhoods/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        toast({ title: "Neighborhood removed" });
        setItems(prev => prev.filter(n => n.id !== id));
      } else { toast({ title: "Delete failed", variant: "destructive" }); }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  const unverified = items.filter(n => !n.verified);
  const verified = items.filter(n => n.verified);

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Map className="w-4 h-4 text-primary" />
          <span className="text-sm font-black uppercase tracking-wider">Neighborhoods</span>
          {unverified.length > 0 && <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400/10 text-yellow-400 border border-yellow-400/20">{unverified.length} pending</span>}
        </div>
        <button onClick={load} className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted"><RefreshCw className="w-3.5 h-3.5" /></button>
      </div>
      <p className="text-xs text-muted-foreground">Geo-fenced neighborhood zones that appear in request matching and community feeds. Verify to make them available to users.</p>
      {loading ? (
        <div className="flex justify-center py-4"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : loadError ? (
        <div className="flex items-center gap-2 text-sm text-destructive py-4 justify-center"><AlertCircle className="w-4 h-4" />{loadError}<button onClick={load} className="ml-2 underline text-xs">Retry</button></div>
      ) : items.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-3">No neighborhoods configured.</p>
      ) : (
        <div className="space-y-2">
          {[...unverified, ...verified].map(n => (
            <div key={n.id} className={`flex items-center gap-3 py-2.5 px-3 rounded-xl border ${n.verified ? "border-green-500/20 bg-green-500/5" : "border-yellow-500/20 bg-yellow-500/5"}`}>
              <span className="text-lg shrink-0">{n.emoji ?? "📍"}</span>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm truncate">{n.name}</div>
                <div className="text-[10px] text-muted-foreground">{n.city_key}</div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button onClick={() => toggleVerify(n)} disabled={processing === n.id}
                  className={`text-[10px] font-black px-2.5 py-1 rounded-lg border transition-all disabled:opacity-50 ${n.verified ? "border-green-500/30 text-green-400 bg-green-500/10" : "border-border text-muted-foreground hover:border-green-500/30 hover:text-green-400"}`}>
                  {processing === n.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : n.verified ? "✓ Verified" : "Verify"}
                </button>
                <button onClick={() => deleteItem(n.id)} disabled={processing === n.id}
                  className="w-7 h-7 rounded-lg border border-destructive/30 text-destructive flex items-center justify-center hover:bg-destructive/10 disabled:opacity-50 transition-colors">
                  <X className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Region Crisis Resources ───────────────────────────────────────────────────
function RegionCrisisSection() {
  const [items, setItems] = useState<RegionCrisisResource[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [processing, setProcessing] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/region-crisis-resources`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setItems(await res.json());
      else { const b = await res.json().catch(() => ({})) as {error?:string}; setLoadError(b.error ?? `Error ${res.status}`); }
    } catch { setLoadError("Could not reach server"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleVerify = async (item: RegionCrisisResource) => {
    setProcessing(item.id);
    try {
      const res = await fetch(`${BASE}/api/admin/region-crisis-resources/${item.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
        body: JSON.stringify({ verified: !item.verified }),
      });
      if (res.ok) {
        toast({ title: item.verified ? "Region unverified" : "Region crisis resources verified ✓" });
        setItems(prev => prev.map(r => r.id === item.id ? { ...r, verified: !r.verified } : r));
      } else { toast({ title: "Failed", variant: "destructive" }); }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  const deleteItem = async (id: number) => {
    setProcessing(id);
    try {
      const res = await fetch(`${BASE}/api/admin/region-crisis-resources/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        toast({ title: "Region removed" });
        setItems(prev => prev.filter(r => r.id !== id));
      } else { toast({ title: "Delete failed", variant: "destructive" }); }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setProcessing(null); }
  };

  const unverified = items.filter(r => !r.verified);

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-destructive" />
          <span className="text-sm font-black uppercase tracking-wider">Region Crisis Resources</span>
          {unverified.length > 0 && <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400/10 text-yellow-400 border border-yellow-400/20">{unverified.length} unverified</span>}
        </div>
        <button onClick={load} className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted"><RefreshCw className="w-3.5 h-3.5" /></button>
      </div>
      <p className="text-xs text-muted-foreground">Emergency service hotlines and resources per region. Verify entries to surface them during crisis mode activation.</p>
      {loading ? (
        <div className="flex justify-center py-4"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : loadError ? (
        <div className="flex items-center gap-2 text-sm text-destructive py-4 justify-center"><AlertCircle className="w-4 h-4" />{loadError}<button onClick={load} className="ml-2 underline text-xs">Retry</button></div>
      ) : items.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-3">No region crisis resources configured.</p>
      ) : (
        <div className="space-y-2">
          {items.map(item => (
            <div key={item.id} className={`rounded-xl border p-3 space-y-2 ${item.verified ? "border-green-500/20" : "border-yellow-500/20"}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{item.region_display}</div>
                  {item.state_code && <div className="text-[10px] text-muted-foreground">{item.state_code}</div>}
                  <div className="text-[10px] text-muted-foreground mt-1">{item.resources.length} resource{item.resources.length !== 1 ? "s" : ""}: {item.resources.map(r => r.label).join(", ")}</div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button onClick={() => toggleVerify(item)} disabled={processing === item.id}
                    className={`text-[10px] font-black px-2 py-1 rounded-lg border transition-all disabled:opacity-50 ${item.verified ? "border-green-500/30 text-green-400" : "border-border text-muted-foreground"}`}>
                    {item.verified ? "✓" : "Verify"}
                  </button>
                  <button onClick={() => deleteItem(item.id)} disabled={processing === item.id}
                    className="w-7 h-7 rounded-lg border border-destructive/30 text-destructive flex items-center justify-center hover:bg-destructive/10 disabled:opacity-50">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Cashout Queue — admin overview of all payout attempts ─────────────────────
function CashoutSection() {
  const [cashouts, setCashouts] = useState<AdminCashout[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");

  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/cashouts`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setCashouts(await res.json());
      else { const b = await res.json().catch(() => ({})) as {error?:string}; setLoadError(b.error ?? `Error ${res.status}`); }
    } catch { setLoadError("Could not reach server"); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const STATE_COLORS: Record<string, string> = {
    pending:                  "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
    failed:                   "text-destructive bg-destructive/10 border-destructive/20",
    completed:                "text-green-400 bg-green-400/10 border-green-400/20",
    reversed:                 "text-orange-400 bg-orange-400/10 border-orange-400/20",
    permanently_failed:       "text-destructive bg-destructive/10 border-destructive/30",
    reconciliation_required:  "text-purple-400 bg-purple-400/10 border-purple-400/20",
  };

  const STATES = ["all", "pending", "failed", "reconciliation_required", "permanently_failed", "completed", "reversed"];
  const filtered = filter === "all" ? cashouts : cashouts.filter(c => c.state === filter);
  const actionRequired = cashouts.filter(c => ["pending", "failed", "reconciliation_required", "permanently_failed"].includes(c.state)).length;

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Banknote className="w-4 h-4 text-primary" />
          <span className="text-sm font-black uppercase tracking-wider">Cashout Queue</span>
          {actionRequired > 0 && <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-destructive/10 text-destructive border border-destructive/20">{actionRequired} action needed</span>}
        </div>
        <button onClick={load} className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted"><RefreshCw className="w-3.5 h-3.5" /></button>
      </div>
      <p className="text-xs text-muted-foreground">All helper cashout attempts. Stuck rows ("pending" older than 10min, "reconciliation_required") may need manual Stripe verification.</p>
      {/* State filter pills */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1 -mx-1 px-1">
        {STATES.map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={`shrink-0 text-[10px] font-black px-2.5 py-1 rounded-full border transition-all capitalize ${filter === s ? (STATE_COLORS[s] ?? "bg-primary text-primary-foreground border-primary") : "border-border text-muted-foreground"}`}>
            {s === "all" ? "All" : s.replace(/_/g, " ")}
          </button>
        ))}
      </div>
      {loading ? (
        <div className="flex justify-center py-4"><RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : loadError ? (
        <div className="flex items-center gap-2 text-sm text-destructive py-4 justify-center"><AlertCircle className="w-4 h-4" />{loadError}<button onClick={load} className="ml-2 underline text-xs">Retry</button></div>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-3">{filter === "all" ? "No cashout records yet." : `No ${filter.replace(/_/g, " ")} cashouts.`}</p>
      ) : (
        <div className="space-y-2">
          {filtered.map(c => (
            <div key={c.id} className="flex items-center gap-3 py-2.5 px-3 rounded-xl border border-border">
              <div className={`text-[10px] font-black px-2 py-0.5 rounded-full border shrink-0 ${STATE_COLORS[c.state] ?? "border-border text-muted-foreground"}`}>
                {c.state.replace(/_/g, " ")}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold">{c.user_name ?? `User #${c.user_id}`}</div>
                <div className="text-[10px] text-muted-foreground">{c.user_email}</div>
                {c.notes && <div className="text-[10px] text-yellow-400 mt-0.5">{c.notes}</div>}
              </div>
              <div className="text-right shrink-0">
                <div className="font-black text-sm">${c.amount.toFixed(2)}</div>
                <div className="text-[10px] text-muted-foreground">{fmtDate(c.created_at)}</div>
                {c.stripe_transfer_id && (
                  <div className="text-[9px] text-primary truncate max-w-[80px]">{c.stripe_transfer_id}</div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── System Tab — worker health + hardship queue ───────────────────────────────
interface WorkerEntry {
  name: string;
  label: string;
  status: "running" | "stopped" | "no_redis" | "error";
  redisRequired: boolean;
  startedAt?: string;
  errorMessage?: string;
}

interface HardshipRequest {
  id: number;
  title: string;
  pledge_amount: number | null;
  pledge_paid: number | null;
  pledge_status: string;
  hardship_note: string | null;
  hardship_requested_at: string | null;
  requester_id: number;
  requester_name: string;
  requester_email: string;
}

// ── Global Ops ───────────────────────────────────────────────────────────────

interface GlobalOpsData {
  gps_health: {
    helpers_online_with_gps: number;
    helpers_online_no_gps: number;
    total_online_helpers: number;
  };
  regions: Array<{
    region: string;
    helpers_online: number;
    open_requests: number;
    recent_completions: number;
  }>;
  language_distribution: Array<{ lang: string; count: number }>;
  feature_checks: {
    database: "ok" | "error";
    mapbox_token: boolean;
    nia_ai: boolean;
    nia_api_key?: boolean;         // legacy alias
    internal_secret: boolean;
    redis: boolean;
    push_vapid: boolean;
    stripe: boolean;
    background_checks: boolean;
    workers_ok: boolean;
  };
  // Actionable config status — which secrets are missing
  config_status?: {
    critical_missing: string[];
    optional_missing: string[];
    fully_configured: boolean;
    nia_service_url: string;
    notes: string;
  };
  summary: {
    total_open_requests: number;
    total_online_helpers: number;
    regions_active: number;
    last_updated: string;
  };
}

const REGION_ICONS: Record<string, string> = {
  "Africa": "🌍",
  "North America": "🌎",
  "Europe": "🏛️",
  "Caribbean": "🌴",
  "South America": "🌎",
  "Middle East": "🕌",
  "Asia": "🌏",
  "Oceania": "🏝️",
  "Other": "🌐",
};

const LANG_NAMES: Record<string, string> = {
  en: "English", es: "Spanish", fr: "French", pt: "Portuguese",
  sw: "Swahili", so: "Somali",  am: "Amharic", yo: "Yoruba",
  ha: "Hausa",   ig: "Igbo",    tw: "Twi",     wo: "Wolof",
  ht: "Haitian Creole", ar: "Arabic", zu: "Zulu",
};

/**
 * GlobalOpsSection — Real-time global coverage snapshot for the admin.
 *
 * Shows GPS signal health, region-by-region helper / request counts, top
 * languages in use, and automated feature-flag checks. Auto-refreshes every
 * 60 seconds so the admin always has a current picture without a manual poll.
 */
function GlobalOpsSection() {
  const [data, setData] = useState<GlobalOpsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/global-ops`, {
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        setData(await res.json());
        setLastRefresh(new Date());
      } else {
        const b = await res.json().catch(() => ({})) as { error?: string };
        setError(b.error ?? `Server returned ${res.status}`);
      }
    } catch { setError("Network error"); } finally { setLoading(false); }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 60_000); // auto-refresh every 60 s
    return () => clearInterval(id);
  }, [load]);

  const checks = data?.feature_checks;

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-5">

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-primary" />
          <span className="text-sm font-black uppercase tracking-wider">Global Ops</span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">Live · 60s refresh</span>
        </div>
        <div className="flex items-center gap-2">
          {lastRefresh && (
            <span className="text-[10px] text-muted-foreground hidden sm:block">
              Updated {lastRefresh.toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={load}
            disabled={loading}
            className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-3 py-2">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {loading && !data && (
        <div className="flex items-center justify-center py-8 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin" />
        </div>
      )}

      {data && (
        <>
          {/* ── Summary numbers ─────────────────────────────────────── */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-muted/40 rounded-xl p-3 text-center">
              <div className="text-xl font-black text-primary">{data.summary.total_online_helpers}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">Online<br/>Helpers</div>
            </div>
            <div className="bg-muted/40 rounded-xl p-3 text-center">
              <div className="text-xl font-black text-yellow-400">{data.summary.total_open_requests}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">Open<br/>Requests</div>
            </div>
            <div className="bg-muted/40 rounded-xl p-3 text-center">
              <div className="text-xl font-black text-green-400">{data.summary.regions_active}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">Regions<br/>Active</div>
            </div>
          </div>

          {/* ── GPS Signal Health ────────────────────────────────────── */}
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-2">GPS Signal Health</div>
            <div className="flex items-center gap-3">
              {/* Visual bar */}
              <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                {data.gps_health.total_online_helpers > 0 ? (
                  <div
                    className="h-full bg-green-400 rounded-full transition-all"
                    style={{
                      width: `${Math.round((data.gps_health.helpers_online_with_gps / data.gps_health.total_online_helpers) * 100)}%`,
                    }}
                  />
                ) : (
                  <div className="h-full bg-muted-foreground/20 rounded-full w-full" />
                )}
              </div>
              <div className="text-xs font-black shrink-0">
                {data.gps_health.total_online_helpers > 0
                  ? `${Math.round((data.gps_health.helpers_online_with_gps / data.gps_health.total_online_helpers) * 100)}%`
                  : "—"}
              </div>
            </div>
            <div className="flex gap-4 mt-1.5 text-[10px] text-muted-foreground">
              <span><span className="text-green-400 font-bold">{data.gps_health.helpers_online_with_gps}</span> with GPS</span>
              <span><span className="text-yellow-400 font-bold">{data.gps_health.helpers_online_no_gps}</span> IP-only</span>
            </div>
          </div>

          {/* ── Regional Coverage ────────────────────────────────────── */}
          {data.regions.length > 0 ? (
            <div>
              <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-2">Coverage by Region</div>
              <div className="divide-y divide-border">
                {data.regions.map(r => (
                  <div key={r.region} className="flex items-center gap-3 py-2">
                    <span className="text-base w-6 text-center shrink-0">{REGION_ICONS[r.region] ?? "🌐"}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold">{r.region}</div>
                    </div>
                    <div className="flex gap-3 text-[11px] shrink-0">
                      <span className="text-primary font-bold" title="Online helpers">{r.helpers_online} 🧑</span>
                      <span className="text-yellow-400 font-bold" title="Open requests">{r.open_requests} 📋</span>
                      <span className="text-green-400 font-bold" title="Completed last 7 days">{r.recent_completions} ✓</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-4 mt-1.5 text-[9px] text-muted-foreground">
                <span>🧑 helpers online</span>
                <span>📋 open requests</span>
                <span>✓ completed 7d</span>
              </div>
            </div>
          ) : (
            <div className="text-xs text-muted-foreground text-center py-3 border border-dashed border-border rounded-xl">
              No active regions — no helpers online or open requests at the moment.
            </div>
          )}

          {/* ── Language Distribution ────────────────────────────────── */}
          {data.language_distribution.length > 0 && (
            <div>
              <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mb-2">Languages in Use (7 days)</div>
              <div className="flex flex-wrap gap-1.5">
                {data.language_distribution.map(({ lang, count }) => (
                  <span
                    key={lang}
                    className="text-[10px] font-semibold px-2 py-1 rounded-full bg-primary/10 text-primary border border-primary/20"
                  >
                    {LANG_NAMES[lang] ?? lang} · {count}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* ── Feature Verification ─────────────────────────────────── */}
          {checks && (
            <div className="space-y-3">
              <div className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">Feature Verification</div>

              {/* Config health banner — shown when critical secrets are missing */}
              {data.config_status && (
                <div className={`flex items-start gap-2 px-3 py-2.5 rounded-xl border text-xs ${
                  data.config_status.fully_configured
                    ? "bg-green-400/10 border-green-400/20 text-green-400"
                    : data.config_status.critical_missing.length > 0
                    ? "bg-destructive/10 border-destructive/20 text-destructive"
                    : "bg-yellow-400/10 border-yellow-400/20 text-yellow-400"
                }`}>
                  {data.config_status.fully_configured
                    ? <CheckCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    : <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />}
                  <div>
                    <p className="font-semibold leading-snug">{data.config_status.notes}</p>
                    {data.config_status.critical_missing.length > 0 && (
                      <p className="text-[10px] mt-1 opacity-80">
                        Missing: {data.config_status.critical_missing.join(" · ")}
                      </p>
                    )}
                    {!data.config_status.fully_configured && (
                      <p className="text-[10px] mt-1 opacity-70">
                        Add secrets in Replit → Secrets tab, then restart the API Server workflow.
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-1.5">
                {([
                  ["Database",          checks.database === "ok"],
                  ["Map / Navigation",  checks.mapbox_token],
                  ["Nia AI (Anthropic)", checks.nia_ai ?? checks.nia_api_key ?? false],
                  ["Internal Secret",   checks.internal_secret],
                  ["Redis / BullMQ",    checks.redis],
                  ["Push / VAPID",      checks.push_vapid],
                  ["Stripe Payments",   checks.stripe],
                  ["Background Checks", checks.background_checks],
                  ["Workers OK",        checks.workers_ok],
                ] as [string, boolean][]).map(([label, ok]) => (
                  <div
                    key={label}
                    className={`flex items-center gap-1.5 px-2.5 py-2 rounded-xl border text-[11px] font-semibold ${
                      ok
                        ? "text-green-400 bg-green-400/10 border-green-400/20"
                        : "text-destructive bg-destructive/10 border-destructive/20"
                    }`}
                  >
                    {ok
                      ? <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                      : <AlertCircle className="w-3.5 h-3.5 shrink-0" />}
                    {label}
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── Smart Dispatch Suggest Panel ──────────────────────────────────────────────
// Calls POST /helpers/auto-assign/:requestId to get an AI-ranked suggestion
// of the best available helper. This is advisory only — it never writes to DB.
function DispatchSuggestSection() {
  const [requestIdInput, setRequestIdInput] = useState("");
  const [radiusInput, setRadiusInput] = useState("10");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    helper_id: number | null;
    helper_name: string;
    match_score: number;
    eta_minutes: number;
    distance_miles: number;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runSuggest = async () => {
    const rid = parseInt(requestIdInput.trim());
    if (isNaN(rid) || rid <= 0) { setError("Enter a valid request ID"); return; }
    const rawRadius = parseFloat(radiusInput);
    const radius = Math.min(50, Math.max(1, isNaN(rawRadius) ? 10 : rawRadius));
    setLoading(true); setResult(null); setError(null);
    try {
      const res = await fetch(`${BASE}/api/helpers/auto-assign/${rid}?radius_miles=${radius}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken() ?? ""}` },
      });
      if (res.ok) {
        setResult(await res.json());
      } else {
        const b = await res.json().catch(() => ({})) as { error?: string };
        setError(b.error ?? `Server returned ${res.status}`);
      }
    } catch { setError("Network error"); } finally { setLoading(false); }
  };

  const trafficColors: Record<string, string> = {
    low:      "text-green-400",
    moderate: "text-yellow-400",
    heavy:    "text-orange-400",
    severe:   "text-destructive",
    unknown:  "text-muted-foreground",
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Navigation2 className="w-4 h-4 text-primary" />
        <span className="text-sm font-black uppercase tracking-wider">Smart Dispatch Suggest</span>
        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 ml-auto">Advisory Only</span>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed">
        Finds the highest-scoring available helper for any open request. Ranks by skills match, distance, availability, and urgency. This is read-only — it never assigns automatically.
      </p>
      <div className="flex gap-2">
        <input
          type="number"
          min="1"
          value={requestIdInput}
          onChange={e => setRequestIdInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter") runSuggest(); }}
          placeholder="Request ID…"
          className="flex-1 bg-background border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          style={{ fontSize: "16px" }}
        />
        <div className="flex items-center gap-1 bg-background border border-border rounded-xl px-2">
          <span className="text-[10px] text-muted-foreground font-semibold whitespace-nowrap">radius</span>
          <input
            type="number"
            min="1"
            max="50"
            value={radiusInput}
            onChange={e => setRadiusInput(e.target.value)}
            className="w-12 bg-transparent text-sm text-center focus:outline-none"
            style={{ fontSize: "16px" }}
          />
          <span className="text-[10px] text-muted-foreground">mi</span>
        </div>
        <button
          onClick={runSuggest}
          disabled={loading}
          style={{ touchAction: "manipulation" }}
          className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-black disabled:opacity-50 active:scale-95 transition-all flex items-center gap-1.5"
        >
          {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <><Zap className="w-4 h-4" />Suggest</>}
        </button>
      </div>
      {error && (
        <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-3 py-2">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {result && (
        <div className="border border-primary/30 rounded-xl p-4 space-y-2 bg-primary/5">
          <div className="text-[10px] font-black uppercase tracking-wider text-primary mb-1">Top Suggestion</div>
          <div className="flex items-center justify-between gap-2">
            <div>
              <div className="font-black text-sm">{result.helper_name}</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Helper ID #{result.helper_id} · {
                  detectUnits() === "metric"
                    ? `${(result.distance_miles * 1.60934).toFixed(1)} km`
                    : `${result.distance_miles.toFixed(1)} mi`
                } · ~{result.eta_minutes} min ETA
              </div>
            </div>
            <div className="text-right shrink-0">
              <div className={`text-lg font-black ${result.match_score >= 80 ? "text-green-400" : result.match_score >= 50 ? "text-yellow-400" : "text-muted-foreground"}`}>
                {result.match_score.toFixed(0)}
              </div>
              <div className="text-[9px] text-muted-foreground">Match Score</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SystemTab() {
  const [health, setHealth] = useState<{
    status: string;
    redis_configured: boolean;
    process_started_at: string;
    workers: WorkerEntry[];
  } | null>(null);
  const [healthLoading, setHealthLoading] = useState(true);
  const [hardship, setHardship] = useState<HardshipRequest[]>([]);
  const [hardshipLoading, setHardshipLoading] = useState(true);
  const [resolvingId, setResolvingId] = useState<number | null>(null);

  const [healthError, setHealthError] = useState<string | null>(null);
  const [hardshipError, setHardshipError] = useState<string | null>(null);

  const loadHealth = async () => {
    setHealthLoading(true);
    setHealthError(null);
    try {
      const res = await fetch(`${BASE}/api/admin/worker-health`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) {
        setHealth(await res.json());
      } else {
        const b = await res.json().catch(() => ({})) as { error?: string };
        setHealthError(b.error ?? `Server returned ${res.status}`);
      }
    } catch { setHealthError("Could not reach server"); } finally { setHealthLoading(false); }
  };

  const loadHardship = async () => {
    setHardshipLoading(true);
    try {
      const res = await fetch(`${BASE}/api/admin/hardship-requests`, { headers: { Authorization: `Bearer ${getToken() ?? ""}` } });
      if (res.ok) setHardship(await res.json());
    } catch { /* non-fatal */ } finally { setHardshipLoading(false); }
  };

  useEffect(() => {
    loadHealth();
    loadHardship();
    // Auto-refresh worker health every 30 s so the admin always sees live
    // worker status without having to click Refresh manually.
    const id = setInterval(loadHealth, 30_000);
    return () => clearInterval(id);
  }, []);

  const resolveHardship = async (requestId: number, action: "forgiven" | "written_off" | "dismiss") => {
    setResolvingId(requestId);
    try {
      let res: Response;
      if (action === "dismiss") {
        // Clears hardship_requested_at — removes from queue, pledge status unchanged
        res = await fetch(`${BASE}/api/admin/requests/${requestId}/hardship`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${getToken() ?? ""}` },
        });
      } else {
        res = await fetch(`${BASE}/api/admin/requests/${requestId}/pledge-status`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken() ?? ""}` },
          body: JSON.stringify({ pledge_status: action }),
        });
      }
      if (res.ok) {
        const label = action === "forgiven" ? "Pledge forgiven" : action === "written_off" ? "Pledge written off" : "Hardship dismissed — pledge kept active";
        toast({ title: label });
        loadHardship();
      } else {
        toast({ title: "Failed to update — please try again", variant: "destructive" });
      }
    } catch { toast({ title: "Network error", variant: "destructive" }); }
    finally { setResolvingId(null); }
  };

  const statusColor = (s: WorkerEntry["status"]) => ({
    running:  "text-green-400 bg-green-400/10 border-green-400/20",
    stopped:  "text-muted-foreground bg-muted border-border",
    no_redis: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
    error:    "text-destructive bg-destructive/10 border-destructive/20",
  }[s]);

  const statusIcon = (s: WorkerEntry["status"]) => ({
    running:  <CheckCircle className="w-3.5 h-3.5 text-green-400" />,
    stopped:  <Clock className="w-3.5 h-3.5 text-muted-foreground" />,
    no_redis: <WifiOff className="w-3.5 h-3.5 text-yellow-400" />,
    error:    <AlertCircle className="w-3.5 h-3.5 text-destructive" />,
  }[s]);

  return (
    <div className="space-y-5">

      {/* Worker Health */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-primary" />
            <span className="text-sm font-black uppercase tracking-wider">Worker Health</span>
          </div>
          <div className="flex items-center gap-3">
            {health && (
              <span className={`text-[10px] font-black px-2 py-1 rounded-full border ${
                health.status === "ok"
                  ? "text-green-400 bg-green-400/10 border-green-400/20"
                  : "text-destructive bg-destructive/10 border-destructive/20"
              }`}>
                {health.status === "ok" ? "All Systems OK" : "Degraded"}
              </span>
            )}
            <button onClick={loadHealth} className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {health && (
          <div className={`flex items-center gap-2 text-xs rounded-xl px-3 py-2 border ${
            health.redis_configured
              ? "text-green-400 bg-green-400/10 border-green-400/20"
              : "text-yellow-400 bg-yellow-400/10 border-yellow-400/20"
          }`}>
            <Server className="w-3.5 h-3.5 shrink-0" />
            <span><span className="font-black">Redis:</span> {health.redis_configured ? "Connected — BullMQ workers active" : "Not configured — BullMQ workers disabled, using legacy scheduler"}</span>
          </div>
        )}

        {healthLoading ? (
          <div className="flex items-center justify-center py-6 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
          </div>
        ) : health ? (
          <div className="space-y-1.5">
            {health.workers.map((w) => (
              <div key={w.name} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[10px] font-black shrink-0 ${statusColor(w.status)}`}>
                  {statusIcon(w.status)}
                  <span className="capitalize">{w.status === "no_redis" ? "No Redis" : w.status}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold">{w.label}</div>
                  {w.errorMessage && <div className="text-[10px] text-destructive truncate">{w.errorMessage}</div>}
                  {w.startedAt && <div className="text-[10px] text-muted-foreground">{new Date(w.startedAt).toLocaleTimeString()}</div>}
                </div>
                {w.redisRequired && (
                  <span className="text-[9px] uppercase tracking-wider text-muted-foreground border border-border rounded px-1.5 py-0.5 shrink-0">Redis</span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">Could not load worker health.</p>
        )}
      </div>

      {/* ── Global Ops (coverage, GPS, languages, feature checks) ──── */}
      <GlobalOpsSection />

      {/* ── Smart Dispatch Suggest ───────────────────────────────────── */}
      <DispatchSuggestSection />

      {/* ── Cashout Queue ────────────────────────────────────────────── */}
      <CashoutSection />

      {/* ── Neighborhoods ────────────────────────────────────────────── */}
      <NeighborhoodsSection />

      {/* ── Region Crisis Resources ───────────────────────────────────── */}
      <RegionCrisisSection />

      {/* Hardship Request Queue */}
      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LifeBuoy className="w-4 h-4 text-primary" />
            <span className="text-sm font-black uppercase tracking-wider">Hardship Requests</span>
            {hardship.length > 0 && (
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-yellow-400/10 text-yellow-400 border border-yellow-400/20">{hardship.length}</span>
            )}
          </div>
          <button onClick={loadHardship} className="w-7 h-7 rounded-lg border border-border flex items-center justify-center hover:bg-muted transition-colors">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Requesters who submitted a "I can't pay right now" hardship request. Review their situation and choose to forgive or write off the pledge. Forgiven = waived with care; written off = uncollectable after extended non-payment.
        </p>

        {hardshipLoading ? (
          <div className="flex items-center justify-center py-6 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
          </div>
        ) : hardship.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No pending hardship requests.</p>
        ) : (
          <div className="space-y-3">
            {hardship.map((h) => {
              const outstanding = (h.pledge_amount ?? 0) - (h.pledge_paid ?? 0);
              return (
                <div key={h.id} className="border border-yellow-500/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{h.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {h.requester_name} · {h.requester_email}
                      </div>
                      <div className="text-xs mt-1">
                        <span className="text-yellow-400 font-bold">${outstanding.toFixed(2)} outstanding</span>
                        {h.pledge_paid && h.pledge_paid > 0 && (
                          <span className="text-green-400 ml-2">· ${h.pledge_paid.toFixed(2)} paid</span>
                        )}
                        <span className={`ml-2 font-bold ${h.pledge_status === "defaulted" ? "text-destructive" : "text-muted-foreground"}`}>
                          · {h.pledge_status}
                        </span>
                      </div>
                      {h.hardship_requested_at && (
                        <div className="text-[10px] text-muted-foreground mt-0.5">
                          Filed: {new Date(h.hardship_requested_at).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </div>
                  {h.hardship_note && (
                    <div className="bg-muted rounded-xl p-3 text-xs text-muted-foreground italic leading-relaxed">
                      "{h.hardship_note}"
                    </div>
                  )}
                  <div className="flex gap-2">
                    <button
                      onClick={() => resolveHardship(h.id, "forgiven")}
                      disabled={resolvingId === h.id}
                      className="flex-1 py-2 text-xs font-black rounded-xl bg-green-500/10 border border-green-500/30 text-green-400 hover:border-green-500/60 transition-all disabled:opacity-50 active:scale-95"
                    >
                      {resolvingId === h.id ? <Loader2 className="w-3.5 h-3.5 animate-spin mx-auto" /> : "Forgive"}
                    </button>
                    <button
                      onClick={() => resolveHardship(h.id, "written_off")}
                      disabled={resolvingId === h.id}
                      className="flex-1 py-2 text-xs font-black rounded-xl bg-muted border border-border text-muted-foreground hover:border-border/80 transition-all disabled:opacity-50 active:scale-95"
                    >
                      Write Off
                    </button>
                    <button
                      onClick={() => resolveHardship(h.id, "dismiss")}
                      disabled={resolvingId === h.id}
                      className="flex-1 py-2 text-xs font-black rounded-xl bg-muted border border-border text-muted-foreground hover:border-border/80 transition-all disabled:opacity-50 active:scale-95"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main Admin Screen ─────────────────────────────────────────────────────────
export default function AdminScreen() {
  const [authed, setAuthed] = useState(false);

  // Primary auth: if the logged-in user has is_admin=true (verified by the
  // server on every API call via requireAdmin()), auto-authenticate them into
  // the admin session without requiring a separate secret.
  const { currentUser } = useAppContext();
  useEffect(() => {
    if (currentUser?.is_admin) setAuthed(true);
  }, [currentUser?.is_admin]);

  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"reports" | "helpers" | "users" | "pledges" | "audit" | "nia" | "analytics" | "orgs" | "settings" | "system">("reports");

  // ── Session timer ─────────────────────────────────────────────────────────
  const [sessionSecondsLeft, setSessionSecondsLeft] = useState(SESSION_DURATION_MS / 1000);
  const [showBumpPrompt, setShowBumpPrompt] = useState(false);
  const expiryRef = useRef<number | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearTimer = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  }, []);

  const logout = useCallback(() => {
    clearTimer();
    setAuthed(false);
    setShowBumpPrompt(false);
    toast({ title: "Admin session ended", description: "Session expired." });
  }, [clearTimer]);

  const startTimer = useCallback((durationMs = SESSION_DURATION_MS) => {
    clearTimer();
    expiryRef.current = Date.now() + durationMs;
    setShowBumpPrompt(false);
    timerRef.current = setInterval(() => {
      const remaining = (expiryRef.current ?? 0) - Date.now();
      if (remaining <= 0) { clearTimer(); logout(); return; }
      setSessionSecondsLeft(Math.ceil(remaining / 1000));
      if (remaining <= BUMP_OFFER_BEFORE_MS) setShowBumpPrompt(true);
    }, 1000);
  }, [clearTimer, logout]);

  useEffect(() => {
    if (authed) startTimer();
    return clearTimer;
  }, [authed]); // eslint-disable-line

  const bumpSession = useCallback(() => {
    setShowBumpPrompt(false);
    startTimer();
    toast({ title: "Session extended +15 min" });
  }, [startTimer]);

  const fmtCountdown = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  // ── Auth gate ─────────────────────────────────────────────────────────────
  // Admin access is granted exclusively via the is_admin flag on the user's
  // DB account — no client-side secret or separate password. This keeps
  // authorization authoritative on the server (requireAdmin() middleware) and
  // ensures all admin API calls carry a valid JWT.
  if (!authed) {
    const isLoggedInNonAdmin = !!currentUser && !currentUser.is_admin;
    return (
      <div
        className="fixed inset-0 bg-background flex flex-col items-center justify-center p-6 gap-5"
        style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
      >
        {/* Icon */}
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", damping: 22 }}
          className="w-20 h-20 bg-primary/10 border border-primary/20 rounded-3xl flex items-center justify-center"
        >
          <Shield className="w-10 h-10 text-primary" />
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-center"
        >
          <h1 className="text-2xl font-black tracking-tight">Admin Panel</h1>
          <p className="text-sm text-muted-foreground mt-1">Niakofa — restricted access</p>
        </motion.div>

        {/* State-specific content */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.18 }}
          className="w-full max-w-sm space-y-3"
        >
          {isLoggedInNonAdmin ? (
            /* Logged in but no admin rights */
            <>
              <div className="bg-destructive/10 border border-destructive/30 rounded-2xl p-5 text-center space-y-2">
                <AlertTriangle className="w-7 h-7 text-destructive mx-auto" />
                <p className="text-sm font-black text-destructive">No admin access</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  <strong>{currentUser.email}</strong> does not have admin privileges.
                  Contact the app administrator to grant access.
                </p>
              </div>
              <button
                onClick={() => setLocation("/")}
                style={{ touchAction: "manipulation" }}
                className="w-full py-4 rounded-2xl bg-primary text-primary-foreground font-black text-base active:opacity-80 transition-opacity"
              >
                Back to app
              </button>
            </>
          ) : (
            /* Not signed in — must sign in with admin account */
            <>
              <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <Shield className="w-4.5 h-4.5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-black text-foreground">Sign in required</p>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                      Sign in with your admin account. Access is verified by your account's admin status — no separate secret needed.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-muted/50 rounded-xl px-3 py-2 text-[11px] text-muted-foreground">
                  <Fingerprint className="w-3.5 h-3.5 shrink-0 text-primary" />
                  <span>All admin actions are logged and server-verified</span>
                </div>
              </div>
              <button
                onClick={() => setLocation("/login")}
                style={{ touchAction: "manipulation" }}
                className="w-full py-4 rounded-2xl bg-primary text-primary-foreground font-black text-base active:opacity-80 transition-opacity flex items-center justify-center gap-2"
              >
                <Shield className="w-4 h-4" />
                Sign In to Admin Account
              </button>
              <button
                onClick={() => setLocation("/")}
                style={{ touchAction: "manipulation" }}
                className="w-full py-3 text-sm text-muted-foreground active:text-foreground transition-colors"
              >
                Back to app
              </button>
            </>
          )}
        </motion.div>
      </div>
    );
  }

  const TABS = [
    { key: "reports",   label: "Reports",   icon: Flag },
    { key: "helpers",   label: "Helpers",   icon: UserIcon },
    { key: "users",     label: "Users",     icon: Users },
    { key: "pledges",   label: "Pledges",   icon: HandHeart },
    { key: "orgs",      label: "Orgs",      icon: Landmark },
    { key: "audit",     label: "Audit",     icon: FileText },
    { key: "nia",       label: "Nia AI",    icon: Bot },
    { key: "analytics", label: "Stats",     icon: BarChart2 },
    { key: "settings",  label: "Settings",  icon: SlidersHorizontal },
    { key: "system",    label: "System",    icon: Server },
  ] as const;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col"
      style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 72px)" }}>

      {/* Sticky header */}
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-border"
        style={{ paddingTop: "env(safe-area-inset-top)" }}>
        <div className="flex items-center gap-3 px-4 py-3">
          <button
            onClick={() => setLocation("/profile")}
            style={{ touchAction: "manipulation" }}
            className="w-9 h-9 rounded-xl border border-border flex items-center justify-center active:bg-muted"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h1 className="flex-1 text-lg font-black uppercase tracking-widest flex items-center gap-2">
            <Shield className="w-5 h-5 text-destructive" /> Admin
          </h1>
          {/* Session timer */}
          <span className={`flex items-center gap-1 text-[11px] font-black px-2.5 py-1.5 rounded-full border ${
            sessionSecondsLeft <= 60 ? "text-destructive border-destructive/30 bg-destructive/10" :
            sessionSecondsLeft <= BUMP_OFFER_BEFORE_MS / 1000 ? "text-yellow-500 border-yellow-500/30 bg-yellow-500/10" :
            "text-muted-foreground border-border bg-background"
          }`}>
            <Timer className="w-3 h-3" />
            {fmtCountdown(sessionSecondsLeft)}
          </span>
          <button onClick={bumpSession} style={{ touchAction: "manipulation" }}
            className="text-[10px] font-black px-2.5 py-1.5 rounded-full border border-border bg-background active:bg-muted"
          >+15</button>
        </div>

        {/* Bump prompt */}
        <AnimatePresence>
          {showBumpPrompt && (
            <motion.div
              initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="mx-4 mb-3 px-4 py-3 rounded-xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-between gap-3">
                <span className="text-[11px] text-yellow-600 dark:text-yellow-400 font-bold">
                  Session expires in {fmtCountdown(sessionSecondsLeft)}
                </span>
                <button onClick={bumpSession} style={{ touchAction: "manipulation" }}
                  className="text-[11px] font-black bg-yellow-500 text-black px-3 py-1.5 rounded-full">Extend</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Admin Live Banner — real-time pending-review counts */}
      <AdminLiveBanner onNavigate={(tab) => setActiveTab(tab as typeof activeTab)} />

      {/* Tab content */}
      <div className="flex-1 max-w-3xl mx-auto w-full px-4 pt-4 space-y-3">
        {activeTab === "orgs"      && <OrgsTab authed={authed} />}
        {activeTab === "pledges"   && (
          <div className="space-y-4">
            <PoolBalanceBanner />
            <PledgePoolDashboard />
            <div className="text-xs font-black uppercase tracking-wider text-muted-foreground px-1 mt-4">Resolve Outstanding Pledges</div>
            <PledgeWriteOffCard />
          </div>
        )}
        {activeTab === "audit"     && <AuditLogTable />}
        {activeTab === "analytics" && <AnalyticsTab />}
        {activeTab === "nia"       && <NiaTab />}
        {activeTab === "helpers"   && (
          <div className="space-y-6">
            <BackgroundCheckAdmin />
            <div className="border-t border-border pt-4">
              <HelperApplicationsTab />
            </div>
          </div>
        )}
        {activeTab === "users"     && <UsersTab />}
        {activeTab === "reports"   && <ReportsTab authed={authed} />}
        {activeTab === "settings"  && <SettingsTab />}
        {activeTab === "system"    && <SystemTab />}
      </div>

      {/* ── Bottom tab bar (mobile-native, horizontally scrollable) ───────── */}
      {/* 10 tabs don't fit a phone screen side-by-side at readable size.
          Horizontal scroll with snap lets the user swipe through all tabs
          while keeping 44px+ tap targets. A fade gradient on the right edge
          signals that more tabs exist beyond the viewport. */}
      <div
        className="fixed bottom-0 left-0 right-0 z-20 bg-card/95 backdrop-blur-xl border-t border-border"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        {/* Fade gradient on right edge — scroll indicator */}
        <div className="relative">
          <div
            role="tablist"
            aria-label="Admin sections"
            className="overflow-x-auto scrollbar-none overscroll-x-contain"
          >
            <div className="flex w-max min-w-full px-1">
              {TABS.map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  role="tab"
                  aria-selected={activeTab === key}
                  onClick={() => setActiveTab(key as typeof activeTab)}
                  style={{ touchAction: "manipulation" }}
                  className={`flex flex-col items-center gap-1 py-3.5 px-4 min-w-[72px] transition-colors relative ${
                    activeTab === key ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  {/* Active indicator pill */}
                  {activeTab === key && (
                    <span className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-primary" />
                  )}
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="text-[10px] font-bold whitespace-nowrap">{label}</span>
                </button>
              ))}
            </div>
          </div>
          {/* Right fade — subtle scroll hint */}
          <div className="pointer-events-none absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-card/95 to-transparent" />
        </div>
      </div>
    </div>
  );
}

