import { Switch, Route, Router as WouterRouter, useRoute } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppProvider, useAppContext } from "@/lib/AppContext";
import { BottomNav } from "@/components/BottomNav";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { NiaFab, NiaDrawer } from "@/components/NiaDrawer";
import { useState, useEffect, lazy, Suspense } from "react";
import { useServiceWorkerUpdate } from "@/hooks/useServiceWorkerUpdate";

// ── HelperApp ───────────────────────────────────────────────────────────────
// This is deliberately a near-mirror of App.tsx, not a wrapper around it —
// keeping two small, readable route tables is easier to reason about than
// one component branching on "which subdomain am I" everywhere. It reuses
// every shared piece (AppProvider/auth state, AppContext, BottomNav, Nia,
// design system components, the generated API client) so there is exactly
// one copy of the logic that actually matters (auth, data fetching, request
// lifecycle) — only the *route table* and *entry point* differ.
//
// Route selection: helper-facing screens plus the account screens every
// user needs regardless of role (login, onboarding, profile, settings,
// wallet/payouts, and the new cross-subdomain /handoff exchange page).
// Deliberately EXCLUDED: request creation/community/civic/business/admin
// screens — those stay on the requester bundle (niakofa.com). If a helper
// account is also admin, they still sign in at niakofa.com/admin; we didn't
// duplicate the admin screen here to avoid maintaining two copies of an
// admin auth surface.
import MapScreen from "@/pages/map";

const ProfileScreen         = lazy(() => import("@/pages/profile"));
const SettingsPage          = lazy(() => import("@/pages/settings"));
const WalletScreen          = lazy(() => import("@/pages/wallet"));
const NotFound              = lazy(() => import("@/pages/not-found"));
const LoginScreen           = lazy(() => import("@/pages/login"));
const HelperProfileScreen   = lazy(() => import("@/pages/helper-profile"));
const RequestDetailScreen   = lazy(() => import("@/pages/request-detail"));
const OnboardingScreen      = lazy(() => import("@/pages/onboarding"));
const StripeConnectedScreen = lazy(() => import("@/pages/stripe-connected"));
const HelperDashboardScreen = lazy(() => import("@/pages/helper-dashboard"));
const HelperOnboardingScreen = lazy(() => import("@/pages/helper-onboarding"));
const PendingApprovalScreen = lazy(() => import("@/pages/pending-approval"));
const ActiveRequestScreen   = lazy(() => import("@/pages/request-active"));
const RequestsBrowsePage    = lazy(() => import("@/pages/requests-browse"));
const HandoffScreen         = lazy(() => import("@/pages/handoff"));

function PageFallback() {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--color-background-primary, #0e1111)",
      }}
    >
      <div
        style={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          background: "var(--color-text-tertiary, #444)",
          animation: "pulse 1.2s ease-in-out infinite",
        }}
      />
    </div>
  );
}

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30000, retry: 1 } },
});

// Same NiaGlobal behavior as the requester app — Nia is not a
// requester-only or helper-only feature.
function NiaGlobal() {
  const { currentUser, myLocation, helperModeActive, activeRequestId, userPlace, niaEnabled } = useAppContext();
  const [niaOpen, setNiaOpen] = useState(false);
  const [niaInitialMessage, setNiaInitialMessage] = useState<string | undefined>(undefined);
  const [isOnboarding] = useRoute("/onboarding");
  const [isMap] = useRoute("/");
  const [isStripeConnected] = useRoute("/wallet/connected");

  useEffect(() => {
    (window as any).openNia = () => {
      if (niaEnabled === true) setNiaOpen(true);
    };
    return () => { delete (window as any).openNia; };
  }, [niaEnabled]);

  useEffect(() => {
    if (!niaEnabled && niaOpen) setNiaOpen(false);
  }, [niaEnabled, niaOpen]);

  if (isOnboarding || isStripeConnected) return null;

  const showFloatingFab = !isMap;

  if (niaEnabled === null) return null;

  return (
    <>
      {showFloatingFab && niaEnabled === true && (
        <NiaFab onClick={() => setNiaOpen(true)} enabled={true} />
      )}
      <NiaDrawer
        open={niaEnabled === true && niaOpen}
        onClose={() => { setNiaOpen(false); setNiaInitialMessage(undefined); }}
        initialMessage={niaInitialMessage}
        userId={currentUser?.id ?? null}
        userName={currentUser?.name ?? null}
        userLocation={myLocation ? { lat: myLocation.lat, lon: myLocation.lng } : null}
        userCity={userPlace?.city ?? null}
        userCounty={userPlace?.county ?? null}
        userState={userPlace?.state ?? null}
        helperModeActive={helperModeActive}
        activeRequestId={activeRequestId}
        accountType={currentUser?.account_type ?? null}
      />
    </>
  );
}

function HelperAppShell() {
  const { currentUser } = useAppContext();
  const [isActiveRequest] = useRoute("/request/:id");
  const [isLogin] = useRoute("/login");
  const [isOnboarding] = useRoute("/onboarding");
  const [isStripeConnected] = useRoute("/wallet/connected");
  const [isHandoff] = useRoute("/handoff");

  // /handoff must render before the auth gate below — it's how a session
  // arrives on this subdomain in the first place, so there is no
  // currentUser yet the first time this route is hit.
  if (isHandoff) {
    return (
      <Suspense fallback={<PageFallback />}>
        <HandoffScreen />
      </Suspense>
    );
  }

  if (!currentUser) {
    return (
      <Suspense fallback={<PageFallback />}>
        <LoginScreen />
      </Suspense>
    );
  }

  const extUser = currentUser as (typeof currentUser & { approval_status?: string }) | null;
  if (extUser?.approval_status === 'pending' || extUser?.approval_status === 'denied') {
    return (
      <Suspense fallback={<PageFallback />}>
        <PendingApprovalScreen />
      </Suspense>
    );
  }

  return (
    <>
      <Suspense fallback={<PageFallback />}>
        <Switch>
          <Route path="/login" component={LoginScreen} />
          <Route path="/onboarding" component={OnboardingScreen} />
          <Route path="/helper/:id" component={HelperProfileScreen} />
          <Route path="/request/:id/view" component={RequestDetailScreen} />
          <Route path="/wallet/connected" component={StripeConnectedScreen} />
          <Route path="/" component={MapScreen} />
          <Route path="/request/:id" component={ActiveRequestScreen} />
          <Route path="/wallet" component={WalletScreen} />
          <Route path="/profile" component={ProfileScreen} />
          <Route path="/settings" component={SettingsPage} />
          <Route path="/helper-dashboard" component={HelperDashboardScreen} />
          <Route path="/helper-onboarding" component={HelperOnboardingScreen} />
          <Route path="/pending-approval" component={PendingApprovalScreen} />
          <Route path="/requests" component={RequestsBrowsePage} />
          <Route path="/handoff" component={HandoffScreen} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
      {!isActiveRequest && !isLogin && !isOnboarding && !isStripeConnected && <BottomNav />}
    </>
  );
}

function HelperAppContent() {
  useServiceWorkerUpdate();
  return (
    <>
      <HelperAppShell />
      <NiaGlobal />
    </>
  );
}

function HelperApp() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AppProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <HelperAppContent />
            </WouterRouter>
            <Toaster />
          </AppProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default HelperApp;
