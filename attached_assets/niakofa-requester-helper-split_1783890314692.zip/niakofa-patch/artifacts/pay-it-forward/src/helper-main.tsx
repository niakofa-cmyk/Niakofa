import { createRoot } from "react-dom/client";
import HelperApp from "./HelperApp";
import "./index.css";
import "./i18n";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { getToken } from "@/lib/auth";

// Same wiring as the requester bundle's main.tsx — the generated API client
// hooks pick up whatever token is currently in localStorage on this origin.
setAuthTokenGetter(getToken);

createRoot(document.getElementById("root")!).render(<HelperApp />);
