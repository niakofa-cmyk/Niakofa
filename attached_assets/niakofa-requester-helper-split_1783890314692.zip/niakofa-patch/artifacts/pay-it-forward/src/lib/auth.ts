const TOKEN_KEY = "niakofa_token";

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {}
}

export function clearToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {}
}

export function authHeaders(): Record<string, string> {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// ── Cross-subdomain handoff ──────────────────────────────────────────────
// Requests a short-lived, single-use code from the API (see
// artifacts/api-server/src/routes/auth-handoff.ts) and returns a full URL
// on the given target origin that will exchange it for a real session via
// the /handoff page. Used by "Switch to Helper" / "Switch to Requester"
// links — see SwitchAppLink.tsx.
export async function requestHandoffUrl(targetOrigin: string, redirectPath = "/"): Promise<string | null> {
  const token = getToken();
  if (!token) return null;

  try {
    const res = await fetch("/api/auth/handoff", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    });
    if (!res.ok) return null;
    const { code } = await res.json();
    if (!code) return null;
    const url = new URL("/handoff", targetOrigin);
    url.searchParams.set("code", code);
    url.searchParams.set("to", redirectPath);
    return url.toString();
  } catch {
    return null;
  }
}
