import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { setToken } from "@/lib/auth";
import { useAppContext } from "@/lib/AppContext";

// Lands here as e.g. https://helper.niakofa.com/handoff?code=... right after
// the OTHER subdomain minted a code via POST /api/auth/handoff. Exchanges it
// for a real session token, stores it in THIS origin's localStorage, then
// redirects into the app. See lib/db/src/schema/auth-handoff-codes.ts and
// artifacts/api-server/src/routes/auth-handoff.ts for the server side.
export default function HandoffScreen() {
  const [, setLocation] = useLocation();
  const { setCurrentUser } = useAppContext();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const redirectTo = params.get("to") || "/";

    if (!code) {
      setError("Missing login code.");
      return;
    }

    (async () => {
      try {
        const res = await fetch("/api/auth/handoff/exchange", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code }),
        });
        const data = await res.json();
        if (!res.ok) {
          setError(data?.error ?? "This login link has expired. Please log in again.");
          return;
        }
        setToken(data.token);
        setCurrentUser(data.user);
        // Strip ?code= from the URL immediately — it's single-use and
        // already consumed server-side, but there's no reason to leave it
        // sitting in browser history / the address bar any longer than
        // this render.
        window.history.replaceState({}, "", window.location.pathname);
        setLocation(redirectTo, { replace: true });
      } catch {
        setError("Couldn't complete sign-in. Please try again.");
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 16,
        background: "var(--color-background-primary, #0e1111)",
        color: "var(--color-text-primary, #fff)",
        textAlign: "center",
        padding: 24,
      }}
    >
      {error ? (
        <>
          <p>{error}</p>
          <a href="/login" style={{ color: "var(--color-primary, #6ee7b7)" }}>
            Go to login
          </a>
        </>
      ) : (
        <>
          <div
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              background: "var(--color-text-tertiary, #444)",
              animation: "pulse 1.2s ease-in-out infinite",
            }}
          />
          <p>Signing you in…</p>
        </>
      )}
    </div>
  );
}
