import { useState } from "react";
import { requestHandoffUrl } from "@/lib/auth";

// Drop this into ProfileScreen (both bundles) as:
//   <SwitchAppLink targetOrigin="https://helper.niakofa.com" label="Switch to Helper" redirectPath="/helper-dashboard" />
// on the requester side, and:
//   <SwitchAppLink targetOrigin="https://niakofa.com" label="Switch to Requester" redirectPath="/" />
// on the helper side. Reads targetOrigin from a prop (not hardcoded) so the
// same component works in both bundles and in local/staging environments —
// wire it to an env var (e.g. VITE_HELPER_ORIGIN / VITE_MAIN_ORIGIN) at the
// call site rather than hardcoding niakofa.com here.
export function SwitchAppLink({
  targetOrigin,
  redirectPath = "/",
  label,
}: {
  targetOrigin: string;
  redirectPath?: string;
  label: string;
}) {
  const [loading, setLoading] = useState(false);

  async function handleClick() {
    setLoading(true);
    const url = await requestHandoffUrl(targetOrigin, redirectPath);
    setLoading(false);
    if (url) {
      window.location.href = url;
    } else {
      // Fall back to a plain link to the target's login screen — better
      // than a dead button if the handoff request failed (e.g. expired
      // session, network hiccup).
      window.location.href = targetOrigin;
    }
  }

  return (
    <button
      onClick={handleClick}
      disabled={loading}
      className="w-full rounded-lg border border-border px-4 py-3 text-sm font-medium text-foreground hover:bg-muted transition-colors disabled:opacity-50"
    >
      {loading ? "Switching…" : label}
    </button>
  );
}
