import { Router } from "express";
import { randomBytes, createHash } from "crypto";
import { db, usersTable, authHandoffCodesTable } from "@workspace/db";
import { eq, and, isNull, gt } from "drizzle-orm";
import { authLimiter } from "../middlewares/rate-limit";
import { requireAuth } from "../middlewares/auth";
import { signTokenById } from "../middlewares/auth";
import { logger } from "../lib/logger";

// ── Cross-subdomain login handoff ───────────────────────────────────────────
//
// Auth here is a stateless Bearer token in localStorage (see
// pay-it-forward/src/lib/auth.ts), not a cookie — so it does NOT
// automatically carry over when a user moves from niakofa.com to
// helper.niakofa.com (or back). These two routes bridge that gap:
//
//   1. POST /auth/handoff          (requireAuth) — the CURRENTLY logged-in
//      app mints a short-lived, single-use code tied to the user.
//   2. POST /auth/handoff/exchange (public)       — the DESTINATION app
//      trades that code for a real, normal session token — same shape
//      as a fresh /users/login response.
//
// The raw code is only ever held in memory / the URL for a few seconds and
// is never stored — only its SHA-256 hash is persisted, mirroring the
// password_reset_codes pattern elsewhere in this codebase.

const CODE_TTL_MS = 60 * 1000; // 60 seconds — long enough for a redirect, short enough to limit replay risk

function hashCode(rawCode: string): string {
  return createHash("sha256").update(rawCode).digest("hex");
}

const router: Router = Router();

router.post("/auth/handoff", requireAuth, authLimiter, async (req, res) => {
  const userId = req.authenticatedUserId!;

  const rawCode = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + CODE_TTL_MS);

  await db.insert(authHandoffCodesTable).values({
    user_id: userId,
    code_hash: hashCode(rawCode),
    expires_at: expiresAt,
  });

  logger.info({ user_id: userId }, "auth-handoff: code issued");

  return res.json({ code: rawCode, expires_in_sec: CODE_TTL_MS / 1000 });
});

router.post("/auth/handoff/exchange", authLimiter, async (req, res) => {
  const { code } = req.body as { code?: string };
  if (!code || typeof code !== "string") {
    return res.status(400).json({ error: "code required" });
  }

  const codeHash = hashCode(code);

  // Single-use + not-expired lookup. Marking used_at happens in the same
  // request right after a successful match — there is a narrow window where
  // two near-simultaneous exchanges of the same code could both read
  // used_at IS NULL before either write lands; that only matters for a code
  // an attacker also has, and the 60s TTL plus one-time nature already caps
  // the blast radius. A stricter fix (UPDATE ... WHERE used_at IS NULL
  // RETURNING *) is a straightforward follow-up if this ever needs to be
  // airtight under concurrency.
  const [row] = await db
    .select()
    .from(authHandoffCodesTable)
    .where(and(
      eq(authHandoffCodesTable.code_hash, codeHash),
      isNull(authHandoffCodesTable.used_at),
      gt(authHandoffCodesTable.expires_at, new Date()),
    ))
    .limit(1);

  if (!row) {
    return res.status(401).json({ error: "This login link has expired or was already used. Please log in again." });
  }

  await db.update(authHandoffCodesTable)
    .set({ used_at: new Date() })
    .where(eq(authHandoffCodesTable.id, row.id));

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, row.user_id)).limit(1);
  if (!user) {
    return res.status(401).json({ error: "Account not found" });
  }
  if (user.is_suspended) {
    return res.status(403).json({ error: "Your account has been suspended. Please contact support@niakofa.app.", error_code: "ACCOUNT_SUSPENDED" });
  }

  const token = signTokenById(user.id, user.token_version);
  const { password_hash, password_reset_code, password_reset_expires_at, google_id: _gid, ...safeUser } = user;

  logger.info({ user_id: user.id }, "auth-handoff: code exchanged for session token");

  return res.json({ user: safeUser, token });
});

export default router;
