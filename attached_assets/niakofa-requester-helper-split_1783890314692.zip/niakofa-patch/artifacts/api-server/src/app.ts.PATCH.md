# Patch notes for artifacts/api-server/src/app.ts

This is a small, surgical patch — apply these two changes to the existing
file rather than replacing it wholesale (the file has a lot of surrounding
middleware ordering that matters and I don't want to risk clobbering it).

## 1. Mount the new auth-handoff router

In `artifacts/api-server/src/routes/index.ts`, alongside the other imports:

```ts
import authHandoffRouter from "./auth-handoff";
```

and alongside the other `router.use(...)` calls:

```ts
router.use(authHandoffRouter);
```

Same pattern as every other router in that file — no other change needed,
it's mounted under `/api` automatically by the existing `app.use("/api", router)`
line in app.ts.

## 2. Serve the requester or helper bundle by hostname

Replace this block in `artifacts/api-server/src/app.ts`:

```ts
// ── Production: serve built frontend static files ─────────────────────────────
if (process.env.NODE_ENV === "production" && process.env.SERVE_FRONTEND === "true") {
  const frontendDist = path.join(import.meta.dirname, "..", "..", "pay-it-forward", "dist", "public");

  app.use(express.static(frontendDist, {
    setHeaders(res, filePath) {
      if (filePath.endsWith("index.html") || filePath.endsWith("sw.js")) {
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");
      }
    },
  }));
  logger.info({ frontendDist }, "serving frontend static files");

  app.get("*path", (req, res) => {
    if (!req.path.startsWith("/api") && !req.path.startsWith("/ws")) {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.sendFile(path.join(frontendDist, "index.html"));
    }
  });
}
```

with:

```ts
// ── Production: serve built frontend static files ─────────────────────────────
if (process.env.NODE_ENV === "production" && process.env.SERVE_FRONTEND === "true") {
  const frontendDist = path.join(import.meta.dirname, "..", "..", "pay-it-forward", "dist", "public");

  // Two entry HTML files come out of the SAME `vite build` (see the
  // pay-it-forward/vite.config.ts multi-entry patch): index.html for the
  // requester/community bundle, helper.html for the helper bundle. Which
  // one a given visitor gets is decided purely by hostname — everything
  // else (API, DB, auth) is identical, unchanged, one service.
  //
  // HELPER_HOSTNAME defaults to "helper.niakofa.com"; override via Railway
  // env var if the helper subdomain is ever renamed. Comparison is exact
  // on req.hostname (Express strips the port already), so this does not
  // accidentally also match e.g. "not-helper.niakofa.com".
  const HELPER_HOSTNAME = process.env.HELPER_HOSTNAME ?? "helper.niakofa.com";

  function entryFileFor(req: import("express").Request): string {
    return req.hostname === HELPER_HOSTNAME ? "helper.html" : "index.html";
  }

  app.use(express.static(frontendDist, {
    // index: false — do NOT let express.static auto-serve dist/public/index.html
    // for a bare "/" request. With two entry files in the same directory we
    // need the hostname check below to run for "/" too, not just the
    // catch-all for unknown paths.
    index: false,
    setHeaders(res, filePath) {
      if (filePath.endsWith(".html") || filePath.endsWith("sw.js")) {
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");
      }
    },
  }));
  logger.info({ frontendDist, HELPER_HOSTNAME }, "serving frontend static files");

  app.get("*path", (req, res) => {
    if (!req.path.startsWith("/api") && !req.path.startsWith("/ws")) {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.sendFile(path.join(frontendDist, entryFileFor(req)));
    }
  });
}
```

### Also needed
- Add a `helper.niakofa.com` custom domain to the SAME `zesty-ambition`
  Railway service (Railway → service → Settings → Domains → Add Domain).
  Do NOT create a second Railway service for this — the whole point of the
  hostname-based static serving above is that one running `api-server`
  process serves both bundles.
- DNS: `helper.niakofa.com` CNAME → the same Railway-provided target
  `niakofa.com` already points at.
