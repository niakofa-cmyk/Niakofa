import { pgTable, serial, integer, text, timestamp, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

// Short-lived, single-use codes that let an already-authenticated user carry
// their session from one Niakofa subdomain to another (e.g. niakofa.com ->
// helper.niakofa.com) without re-entering a password.
//
// Why this exists: auth is a stateless Bearer token kept in localStorage
// (see artifacts/pay-it-forward/src/lib/auth.ts), NOT a cookie. localStorage
// is origin-scoped (scheme+host+port) and does not cross subdomains the way
// a `Domain=.niakofa.com` cookie would. This table is the bridge: the source
// app asks the API to mint a code tied to the logged-in user, hands the raw
// code to the destination subdomain via a short redirect, and the
// destination exchanges it for a real session token. The raw code is never
// stored — only its SHA-256 hash — same reasoning as password_reset_codes:
// a leaked DB row should not itself be a usable credential.
export const authHandoffCodesTable = pgTable("auth_handoff_codes", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  code_hash: text("code_hash").notNull(),
  // withTimezone: expiry comparisons must be timezone-correct regardless of
  // the server's local TZ — same reasoning as password_reset_codes.
  expires_at: timestamp("expires_at", { withTimezone: true }).notNull(),
  used_at: timestamp("used_at", { withTimezone: true }),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => [
  index("auth_handoff_codes_user_id_idx").on(t.user_id),
  index("auth_handoff_codes_expires_at_idx").on(t.expires_at),
]);

export type AuthHandoffCode = typeof authHandoffCodesTable.$inferSelect;
export type InsertAuthHandoffCode = typeof authHandoffCodesTable.$inferInsert;
