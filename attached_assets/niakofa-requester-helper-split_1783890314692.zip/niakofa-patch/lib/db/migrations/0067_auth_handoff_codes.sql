-- Migration 0067: cross-subdomain login handoff codes.
--
-- Supports splitting the frontend into two subdomains (niakofa.com for
-- requesters/community, helper.niakofa.com for helpers) while keeping ONE
-- api-server and ONE auth system. Auth is a Bearer token in localStorage,
-- which does not cross subdomains, so a short-lived single-use code bridges
-- an already-logged-in session from one subdomain to the other.
--
-- Idempotent-safe pattern per CLAUDE.md Incident #2 conventions.

CREATE TABLE IF NOT EXISTS auth_handoff_codes (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS auth_handoff_codes_user_id_idx ON auth_handoff_codes (user_id);
CREATE INDEX IF NOT EXISTS auth_handoff_codes_expires_at_idx ON auth_handoff_codes (expires_at);
