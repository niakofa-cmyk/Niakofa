# Niakofa: Requester/Helper frontend split — patch set

This implements the recommendation from our conversation:
- **Split the frontend** into two Vite entry bundles (requester vs helper),
  served from two subdomains, by ONE `api-server` — not two Railway services.
- **Bridge login** across the two subdomains with a short-lived, single-use
  handoff code, because auth here is a Bearer token in `localStorage`
  (`artifacts/pay-it-forward/src/lib/auth.ts`), which does NOT carry across
  subdomains the way a cookie would.

Nothing here touches `artifacts/nia-service` or the database's core request/
payment logic — this is additive.

## Files in this patch, and where they go

```
lib/db/src/schema/auth-handoff-codes.ts       NEW  — drizzle schema
lib/db/migrations/0067_auth_handoff_codes.sql NEW  — check this is really
                                                       the next free number;
                                                       your repo was at 0066
                                                       as of this audit.

artifacts/api-server/src/routes/auth-handoff.ts   NEW — issue/exchange routes
artifacts/api-server/src/app.ts.PATCH.md          READ ME — manual 2-part
                                                    patch to app.ts + routes/index.ts
                                                    (small, surgical — see file)

artifacts/pay-it-forward/vite.config.ts       REPLACE — multi-entry build
artifacts/pay-it-forward/helper.html          NEW
artifacts/pay-it-forward/public/helper-manifest.json  NEW
artifacts/pay-it-forward/src/helper-main.tsx  NEW
artifacts/pay-it-forward/src/HelperApp.tsx    NEW — filtered helper route table
artifacts/pay-it-forward/src/pages/handoff.tsx        NEW
artifacts/pay-it-forward/src/lib/auth.ts      REPLACE — adds requestHandoffUrl()
artifacts/pay-it-forward/src/components/SwitchAppLink.tsx  NEW
```

## Two one-line additions I didn't auto-apply (small, but you should place
them by hand next to their siblings)

**`lib/db/src/schema/index.ts`** — add, near the other `export * from` lines:
```ts
export * from "./auth-handoff-codes";
```

**`artifacts/api-server/src/routes/index.ts`** — add near the other route
imports/mounts:
```ts
import authHandoffRouter from "./auth-handoff";
// ...
router.use(authHandoffRouter);
```

## Deploy steps

1. Apply the two one-line additions above.
2. Apply `app.ts.PATCH.md` (2 small edits — hostname-based static serving,
   mount the handoff router).
3. Run the migration: `pnpm --filter @workspace/db run migrate` (confirm the
   filename number doesn't collide with anything added to the repo since
   this audit — rename to the next free number if needed).
4. `pnpm --filter @workspace/api-spec run codegen` is NOT needed for this —
   the new routes aren't in the OpenAPI-generated client, they're called
   with plain `fetch()` directly (see `handoff.tsx` / `lib/auth.ts`), same
   as `login.tsx` already does for `/users/login`.
5. In Railway, add `helper.niakofa.com` as an additional custom domain on
   the **existing** `zesty-ambition` service (not a new service), and point
   its DNS CNAME the same way `niakofa.com` is already pointed.
6. Set `HELPER_HOSTNAME=helper.niakofa.com` if you ever rename the
   subdomain (defaults to that value already).

## Known follow-ups I deliberately left for you, not silently guessed at

- **`BottomNav.tsx` already has a helper-mode tab set** (I found it: lines
  ~24-28, includes `/community` and `/request/new`). Since `HelperApp.tsx`
  reuses `BottomNav` unmodified but its route table doesn't include those
  two paths, tapping them on the helper bundle will currently hit
  `NotFound`. Cleanest fix: either (a) add those two routes to
  `HelperApp.tsx`'s Switch if helpers should be able to request things too
  from the same account, or (b) add a small prop to `BottomNav` (e.g.
  `variant="helper-only"`) that swaps those two tabs for something helper-
  relevant (e.g. `/wallet`, `/helper-dashboard`). I didn't guess which
  product decision you want here.
- **App icons**: `helper-manifest.json` currently reuses the same
  `favicon.svg` as the requester app so the two installed PWAs are visually
  identical on a home screen. Swap in a distinct Helper icon before you
  actually want people installing both.
- **SwitchAppLink placement**: I built the component but didn't wire it into
  `profile.tsx` — drop it in wherever fits your existing profile screen
  layout, with `targetOrigin` read from an env var
  (`VITE_HELPER_ORIGIN` / `VITE_MAIN_ORIGIN`) rather than hardcoded, so it
  keeps working in staging/local.
