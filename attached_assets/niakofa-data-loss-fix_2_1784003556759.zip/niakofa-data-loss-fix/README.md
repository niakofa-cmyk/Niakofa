# Niakofa — data-loss fix (drop-in files)

## Where these go (paths relative to `artifacts/pay-it-forward/`)
- `src/App.tsx` → replaces the existing file
- `src/pages/map.tsx` → replaces the existing file
- `src/hooks/useStableCenter.ts` → new file
- `src/hooks/useResilientData.ts` → new file

## What was actually happening
This was not the Postgres database dropping rows. It was React Query's
default behavior:

1. **GPS-driven cache-key churn** — `map.tsx` built its query params/keys
   straight from live GPS coordinates. GPS emits a new lat/lng on almost
   every render while moving, so `useGetNearbyRequests`, `useGetOnlineHelpers`,
   `useGetCivicNeedsNearby`, and `useGetCivicResourcesNearby` were each
   starting a **brand-new cache entry** (`data: undefined`) on nearly every
   tick. Code like `const { data: requests = [] } = useGetNearbyRequests(...)`
   turned that into a visibly empty map for a moment — open requests,
   online helpers, and civic pins all "disappearing" while someone simply
   walked or drove with the app open.
2. **No `placeholderData`** — anywhere in the app, not just the map. Any
   query whose key changes (switching helper/community mode, changing a
   filter, revisiting a page after its cache entry expired) reset to
   `undefined` while the new fetch was in flight, by design in React Query —
   this app just wasn't opting out of that default.
3. **A transient network error also reads as "data gone"** — a single
   dropped request/timeout resolves a query to `data: undefined` with no
   distinction from "there's really nothing here," so a brief connectivity
   blip could blank a list that had real data a second earlier.

## The fix
- **`useStableCenter`** (new hook) rounds + debounces the GPS center used
  *for querying* (map rendering still uses the raw, precise location) so
  the four map queries above stop tearing down and recreating their cache
  entry on every GPS tick.
- **`placeholderData: keepPreviousData`** is now set:
  - Globally, in `App.tsx`'s `QueryClient` defaults — this fixes the same
    class of flash-to-empty on every other page in the app (Circles,
    Civic Portal, wallet ledger, community pool, etc.), not just the map.
  - Per-query in `map.tsx` as well, since those four queries' `queryKey` is
    passed explicitly rather than relying on the client default alone.
- **`useResilientData`** (new hook) additionally keeps the *last successful*
  result through a transient fetch error, since `placeholderData` alone only
  covers the pending→success gap, not pending→error. Only a new confirmed
  success is allowed to replace what's on screen.
- **`gcTime` raised to 10 minutes** (library default is 5) in the global
  `QueryClient`, so quick navigation away from the map and back doesn't
  garbage-collect its cache and force a from-scratch reload.

## Not touched (out of scope for this pass, flagged for awareness)
- `useGetRoute` (the live helper-route line) uses the same "no placeholderData"
  pattern — lower risk since it's a single line overlay, not a data list, but
  worth the same treatment if you see the route line blink during navigation.
- Backend: the claim/complete/cancel endpoints already use atomic
  `WHERE status = 'open'` updates and `db.transaction(...)` where it matters —
  I didn't find an actual server-side data-loss bug in the request/claim flow.
  If you're also seeing data missing *after a full server restart/redeploy*
  (not just in a live session), that would point at the Postgres
  container/volume itself rather than app code — worth checking Railway's
  restart/recovery logs for that service, which is a different kind of
  problem than what's fixed here.
