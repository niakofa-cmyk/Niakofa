# Integration

### Viewer
Use `StoryMediaPlayer` for the selected media item and advance on `onComplete`.
Pass `selectedStory.elements` so persisted text/stickers/mentions/music metadata
are actually visible.

### Preview lifecycle
Do not call `URL.createObjectURL()` during render. Use `useObjectUrl(file)`.

### Upload
Run `normalizeStoryFiles(Array.from(input.files ?? []))` before encoding.
Server-side validation remains authoritative.

### Story → Messages
Use `sendStoryContextMessage({ recipientId, storyId, body })`.
The existing server validates that the Story is published/unexpired and that
the author is a valid participant in the direct conversation.

### Reactions/shares/views
Use the functions in `src/lib/community-story-client.ts`; do not keep these
as local-only UI state.

### Music/effects
Music remains metadata until a licensed audio catalog + server-side mixing
pipeline exists. CSS effects are preview effects, not baked media.

### Validation
Run the repository's normal lint/typecheck/test commands after integration.
