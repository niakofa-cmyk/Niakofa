import { useEffect, useMemo, useState } from "react";

const MAX_FILES = 6;
const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
const MAX_VIDEO_BYTES = 100 * 1024 * 1024;

export function validateStoryFile(file: File): string | null {
  if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
    return "Only image and video files can be used in a Story.";
  }
  const limit = file.type.startsWith("video/") ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;
  if (file.size > limit) {
    return `That file is too large. Maximum is ${file.type.startsWith("video/") ? "100 MB" : "15 MB"}.`;
  }
  return null;
}

export function normalizeStoryFiles(files: File[]) {
  const errors: string[] = [];
  const accepted: File[] = [];
  for (const file of files) {
    const error = validateStoryFile(file);
    if (error) errors.push(`${file.name}: ${error}`);
    else accepted.push(file);
  }
  return { files: accepted.slice(0, MAX_FILES), errors };
}

export function useObjectUrl(file: File | null): string | null {
  const urls = useMemo(() => (file ? [URL.createObjectURL(file)] : []), [file]);
  useEffect(() => () => urls.forEach((url) => URL.revokeObjectURL(url)), [urls]);
  return urls[0] ?? null;
}
