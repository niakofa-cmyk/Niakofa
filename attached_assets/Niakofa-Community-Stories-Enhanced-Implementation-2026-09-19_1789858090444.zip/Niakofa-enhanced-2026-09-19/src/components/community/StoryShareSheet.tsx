import { useState } from "react";
import { sendStoryContextMessage } from "@/lib/community-story-client";
import { authHeaders } from "@/lib/auth";

type Person = { id: number; name: string; avatar_url: string | null };

export function StoryShareSheet({ storyId, onClose }: { storyId: number; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const [people, setPeople] = useState<Person[]>([]);
  const [message, setMessage] = useState("");
  const [sendingTo, setSendingTo] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const search = async (value: string) => {
    setQuery(value);
    if (!value.trim()) return setPeople([]);
    const response = await fetch(`/api/users/search?q=${encodeURIComponent(value.trim())}`, { headers: authHeaders() });
    if (!response.ok) return setPeople([]);
    const data = await response.json().catch(() => ({})) as { users?: Person[]; results?: Person[] };
    setPeople(Array.isArray(data.users) ? data.users : Array.isArray(data.results) ? data.results : []);
  };

  const send = async (person: Person) => {
    if (sendingTo !== null) return;
    setSendingTo(person.id);
    setError(null);
    try {
      await sendStoryContextMessage({ recipientId: person.id, storyId, body: message });
      onClose();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not share the Story.");
    } finally {
      setSendingTo(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-3 sm:items-center">
      <div className="w-full max-w-md rounded-3xl border border-border bg-background p-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="font-black">Send Story</h2>
          <button type="button" onClick={onClose} className="rounded-full px-3 py-2 text-sm font-bold text-muted-foreground">Close</button>
        </div>
        <input value={query} onChange={(event) => void search(event.target.value)} placeholder="Search a neighbor" className="mt-3 min-h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" />
        <textarea value={message} onChange={(event) => setMessage(event.target.value)} maxLength={500} rows={3} placeholder="Add a message (optional)" className="mt-2 w-full resize-none rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" />
        {error && <p className="mt-2 rounded-xl bg-rose-500/10 px-3 py-2 text-xs text-rose-200">{error}</p>}
        <div className="mt-3 max-h-64 overflow-y-auto">
          {people.map((person) => (
            <button key={person.id} type="button" disabled={sendingTo !== null} onClick={() => void send(person)} className="flex min-h-12 w-full items-center gap-3 rounded-xl px-3 py-2 text-left hover:bg-muted disabled:opacity-50">
              <span className="font-bold">{person.name}</span>
              <span className="ml-auto text-xs text-muted-foreground">{sendingTo === person.id ? "Sending…" : "Send"}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
