import { useEffect, useMemo, useRef, useState } from "react";
import { StoryElementLayer, storyEffectFilter, type StoryElement } from "./StoryElementLayer";

export type StoryPlayerMedia = {
  id: number;
  media_type: "photo" | "video";
  mime_type: string;
  media_url: string;
  duration_ms: number | null;
};

const DEFAULT_PHOTO_MS = 5000;

export function StoryMediaPlayer({
  media, elements, onComplete, onProgress,
}: {
  media: StoryPlayerMedia | null;
  elements: StoryElement[];
  onComplete: () => void;
  onProgress?: (fraction: number) => void;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [loaded, setLoaded] = useState(false);
  const durationMs = useMemo(
    () => media?.media_type === "video" && media.duration_ms
      ? Math.max(1000, media.duration_ms)
      : DEFAULT_PHOTO_MS,
    [media],
  );
  const filter = useMemo(() => storyEffectFilter(elements), [elements]);

  useEffect(() => {
    setLoaded(false);
    if (!media || media.media_type === "video") return;
    const started = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const fraction = Math.min(1, (now - started) / durationMs);
      onProgress?.(fraction);
      if (fraction >= 1) return onComplete();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [media, durationMs, onComplete, onProgress]);

  useEffect(() => {
    if (!media || media.media_type !== "video") return;
    const video = videoRef.current;
    if (!video) return;
    const update = () => {
      if (video.duration && Number.isFinite(video.duration)) {
        onProgress?.(Math.min(1, video.currentTime / video.duration));
      }
    };
    video.addEventListener("timeupdate", update);
    return () => video.removeEventListener("timeupdate", update);
  }, [media, onProgress]);

  if (!media) return <div className="grid h-full place-items-center bg-black text-sm text-white/70">This Story has no media.</div>;

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-black">
      {media.media_type === "video" ? (
        <video
          ref={videoRef}
          key={media.id}
          src={media.media_url}
          autoPlay
          playsInline
          muted
          preload="auto"
          onCanPlay={() => setLoaded(true)}
          onEnded={onComplete}
          className="max-h-full max-w-full object-contain"
          style={{ filter }}
        />
      ) : (
        <img
          key={media.id}
          src={media.media_url}
          alt=""
          onLoad={() => setLoaded(true)}
          className="max-h-full max-w-full object-contain"
          style={{ filter }}
        />
      )}
      {!loaded && <div className="absolute inset-0 grid place-items-center bg-black/30 text-xs text-white/70">Loading…</div>}
      <StoryElementLayer elements={elements} />
    </div>
  );
}
