import { useEffect } from "react";
import { toast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";

/**
 * useServiceWorkerUpdate
 *
 * Registers the service worker and watches for new versions.
 *
 * Why this exists: sw.js uses skipWaiting() + clients.claim(), so a new
 * service worker takes control of *future* fetches almost immediately after
 * it installs. But any tab that's already open keeps running the JS modules
 * it already loaded into memory — those don't magically swap out. Without
 * this hook, a user could sit on an old build indefinitely unless they
 * happened to manually refresh after the new worker took over.
 *
 * This hook:
 *   1. Registers /sw.js once, on mount.
 *   2. Listens for `updatefound` → a new worker is installing.
 *   3. When that worker reaches `installed` AND there's already an active
 *      controller (i.e. this is an update, not the very first install),
 *      shows a toast prompting the user to refresh.
 *   4. Listens for `controllerchange` (fires once the new worker actually
 *      takes control) and reloads — guarded so we can never get stuck in a
 *      reload loop.
 */
export function useServiceWorkerUpdate() {
  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;

    let refreshing = false;

    // Reload once the new service worker takes control. Guarded by
    // `refreshing` so a second controllerchange event can't trigger a
    // reload loop.
    const handleControllerChange = () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    };
    navigator.serviceWorker.addEventListener(
      "controllerchange",
      handleControllerChange
    );

    const notifyUpdateAvailable = (registration: ServiceWorkerRegistration) => {
      toast({
        title: "A new version of Niakofa is available",
        description: "Refresh to get the latest updates.",
        duration: 1000 * 60 * 10, // keep it up for 10 min rather than the usual few seconds
        action: (
          <ToastAction
            altText="Refresh now"
            onClick={() => {
              // Tell the waiting worker to skip waiting and activate now.
              // Its activate handler runs self.clients.claim(), which fires
              // the controllerchange listener above and reloads the page.
              registration.waiting?.postMessage({ type: "SKIP_WAITING" });
            }}
          >
            Refresh
          </ToastAction>
        ),
      });
    };

    const onLoad = () => {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .then((registration) => {
          // An update may already be waiting if this tab was open across a
          // deploy, before this listener was even attached.
          if (registration.waiting && navigator.serviceWorker.controller) {
            notifyUpdateAvailable(registration);
          }

          registration.addEventListener("updatefound", () => {
            const installingWorker = registration.installing;
            if (!installingWorker) return;

            installingWorker.addEventListener("statechange", () => {
              // "installed" + an existing controller means this is an
              // update to an already-running app, not the first-ever install.
              if (
                installingWorker.state === "installed" &&
                navigator.serviceWorker.controller
              ) {
                notifyUpdateAvailable(registration);
              }
            });
          });
        })
        .catch(() => {});
    };

    window.addEventListener("load", onLoad);

    return () => {
      window.removeEventListener("load", onLoad);
      navigator.serviceWorker.removeEventListener(
        "controllerchange",
        handleControllerChange
      );
    };
  }, []);
}
