import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Service worker registration (and update detection) now lives in
// useServiceWorkerUpdate, mounted inside <App /> — see App.tsx. Keeping it
// there rather than here lets it show a toast via the app's own Toaster
// when a new version is available.

createRoot(document.getElementById("root")!).render(<App />);
