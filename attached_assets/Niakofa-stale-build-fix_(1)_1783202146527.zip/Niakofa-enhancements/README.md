# Niakofa — Stale-Build / Service Worker Update Fix

This package contains the 4 files touched to fix "stuck on an old build"
after a deploy. Drop each file into your repo at the **same relative path**
shown below, overwriting the existing file (2 files are brand-new).

```
artifacts/api-server/src/app.ts                              (MODIFIED)
artifacts/pay-it-forward/src/main.tsx                         (MODIFIED)
artifacts/pay-it-forward/src/App.tsx                          (MODIFIED)
artifacts/pay-it-forward/src/hooks/useServiceWorkerUpdate.tsx (NEW)
```

## What each change does

### 1. `app.ts`
`/sw.js` now gets the same `Cache-Control: no-cache, no-store, must-revalidate`
headers `index.html` already had. Previously only `index.html` was
exempted from caching — `sw.js` fell through to `express.static`'s default
(no explicit cache header), which meant browsers were spec-allowed to reuse
a stale service worker file for up to 24 hours before re-checking. That's
the root cause of "always stuck on an old build."

### 2. `useServiceWorkerUpdate.tsx` (new)
A hook that:
- Registers `/sw.js`.
- Detects when a *new* service worker has finished installing while an
  older one is already controlling the page (i.e. a real update, not the
  first-ever install).
- Shows a toast — "A new version of Niakofa is available" — with a
  **Refresh** button.
- Clicking Refresh sends `{ type: "SKIP_WAITING" }` to the waiting worker
  (your existing `sw.js` already listens for this message, so no service
  worker changes were needed there). That triggers `controllerchange`,
  which the hook uses to reload the page automatically.
- Guarded against reload loops with a `refreshing` flag.

### 3. `App.tsx`
Calls `useServiceWorkerUpdate()` once at the root of the app, inside the
existing `<Toaster />`/`QueryClientProvider` tree, so the update toast can
use your app's existing toast system.

### 4. `main.tsx`
Removed the old bare `navigator.serviceWorker.register(...)` call (now
superseded by the hook, which needs to live inside the React tree to use
`toast()`).

## Before deploying
This zip does not include `node_modules`, so no type-check or build was run
against your actual dependency graph. Please run your normal `tsc` / build
step once these files are dropped in, before pushing to production.

## Note on the separate Nia AI question
No files here relate to the `nia_enabled` toggle — that system is already
correct in your codebase (fail-closed, seeded `false` by default). If Nia
is showing as enabled, check the live value of the `nia_enabled` row in
`system_settings` — that's a persisted admin setting, not something a
build or cache issue can cause.
