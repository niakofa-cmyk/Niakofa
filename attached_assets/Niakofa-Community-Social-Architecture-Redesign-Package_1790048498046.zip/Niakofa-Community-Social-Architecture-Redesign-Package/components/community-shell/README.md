# Community Shell Component Map

- CommunityShell — responsive desktop/mobile shell and navigation.
- CommunityHeader — search, create actions, account, notifications, messages.
- CommunitySidebar — primary social navigation.
- CommunityMobileNav — mobile navigation.
- CommunityComposer — Post / Request Help / Offer Help / Share Story.
- CommunityFeed — paginated feed.
- CommunityStories — story rail and viewer.
- CommunityPost / CommunityComments — social primitives.
- CommunityPeople — discovery, connection, follow, profile, DM.
- CommunityHubs — My Hubs / Discover / Popular and selected Hub.
- CommunityRequests — For You / Open / Mine / Helping / Completed / Nearby.
- CommunityServices — Skills and service discovery.
- CommunityMedia — photos, video, audio, albums, shared media.
- CommunityNotifications — unified activity center.
- CommunityMessages — entry points to the unified Messages product.
- CommunityProfile — community identity and profile surface.
