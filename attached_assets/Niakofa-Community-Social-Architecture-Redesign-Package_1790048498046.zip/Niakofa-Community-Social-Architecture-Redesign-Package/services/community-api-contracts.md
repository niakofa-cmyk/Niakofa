# Existing Backend Integration Rules

1. Preserve the existing Community Hub API and membership authorization.
2. Preserve Hub-scoped realtime filtering and durable Hub assignment.
3. Preserve the single Messages product.
4. Preserve durable media storage and processing.
5. Preserve Requests, routing, completion, gratitude, Community Pool, Spirals, Circles, Skills,
   Civic Resources, and Diaspora contracts.
6. Add social capabilities as composable modules rather than duplicate identity or messaging systems.
7. Every feed object should have an explicit scope: user, Hub, Community, or service.
8. Realtime events should include durable scope information so clients can filter safely.
