# Niakofa Community Social Architecture

## Core experience
A Facebook-class social network adapted to Niakofa's purpose: connect people, help people,
organize Hubs, complete Requests, discover Services, share Stories, and build community.

## Primary navigation
Home · People · Hubs · Stories · Circles · Requests · Services · Media · Notifications · Messages · Profile

## Experience layers
1. Social: posts, comments, reactions, stories, media, shares, connections, follows, saved items.
2. Community: Hubs, Hub feeds, people, events, media, membership.
3. Niakofa services: Requests, Helpers, Routing, Skills, Services, Civic Resources, Community Pool,
   Gratitude, Spirals, Circles.
4. Identity: Users, Profiles, Hub Membership, Circles, Diaspora.
5. Realtime: WebSockets, presence, notifications, live location, RTC.

## Key flow
Discover Request → Message → Route → Help → Complete → Gratitude → Story → Community

## Messaging rule
Keep one Messages product. Community entry points deep-link into `/messages`; use internal modes
such as All, Direct, Requests, and Hubs instead of creating a second messaging backend.

## ZIP usage
Use the strongest Facebook clone ZIP for UI/interaction patterns such as Header, Sidebar, Feed,
Stories, Post, Comments, People discovery, and responsive mobile navigation. Do not merge its
Firebase, NextAuth, Flask, SQLite, or duplicate identity/data architecture into Niakofa.

## Suggested views
/community
/community/people
/community/hubs
/community/stories
/community/circles
/community/requests
/community/services
/community/media
/community/notifications
/messages
/profile/:id

These can also be implemented as shell tabs if the existing router favors a single Community route.
