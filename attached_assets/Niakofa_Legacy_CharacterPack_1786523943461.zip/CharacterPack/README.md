# Niakofa Legacy — Character Asset Pack

4,226 layered character-generator assets, cleaned and organized. See `catalog.json`
for the full machine-readable breakdown (counts per category/gender/layer).

## Structure

```
CharacterPack/
├── Face/{Male,Female,Kid}/     1,138 assets — portraits (dialogue, journal, Family Tree)
├── TV/{Male,Female,Kid}/         946 assets — 48x48 map-walking sprites (144x192 sheet)
├── TVD/{Male,Female,Kid}/        726 assets — alternate/damaged map sprite state
├── SV/{Male,Female,Kid}/         744 assets — side-view battle sprite (optional future use)
├── Variation/{Male,Female,Kid}/  668 assets — small selector-icon thumbnails
├── grad_skin.png, grad_hair.png, grad_eyes.png, grad_common.png   — recolor gradients
└── catalog.json
```

## How to compose a character

Every representation is layered. A character = one file per layer, stacked in order:

```
Body → Clothing → RearHair → FrontHair → (Beard) → (Glasses) → (Accessories) → (FacialMark)
```

Example — a young adult male villager:
```
TV/Male/TV_Body_p01.png
+ TV/Male/TV_Clothing2_p03.png
+ TV/Male/TV_RearHair1_p05.png
+ TV/Male/TV_FrontHair1_p05.png
```
Use the **same layer indices** (`p01`, `p05`, etc. — an "appearance seed") across
`TV`, `TVD`, and `Face` for a given character, so the walking sprite, the damaged
map state, and the dialogue portrait are recognizably the same person.

## Deterministic identity (per design notes)

Store the appearance as data, not a baked image:

```json
{
  "characterId": "kwame-mensah",
  "appearanceSeed": { "body": "p01", "clothing": "p03", "rearHair": "p05", "frontHair": "p05" },
  "lifeStage": "youth",
  "era": "1890"
}
```

Re-resolving this record should always produce the same character. Advancing
`lifeStage`/`era` (e.g. youth → adult → elder, 1890 → 1910 → present) should swap
in different clothing/hair layers while keeping face/body identity constant — this
is the "Character Evolution" system the design notes call out as the next milestone.

## What NOT to use as-is

`catalog.json` → `tier_notes.tier3_not_for_niakofa_fantasy_layers` lists generator
layers (beast ears, tails, wings, cloaks) that belong to the generic fantasy-RPG
vocabulary this generator ships with. They're present in the files for completeness
but shouldn't appear in the Niakofa cast.

## Boundary to respect

This pack answers "what should this person look like?" — never "who is this
person?". Identity, relationships, and history come only from the Family Vault /
Knowledge Graph.
