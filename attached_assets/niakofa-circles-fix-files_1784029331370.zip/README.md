# Changed files — drop-in replacements

Paths are relative to your repo root (`Niakofa-main/`).

## The bug this fixes
Refreshing the page while hosting an Audio Circle ended the session for
every other participant — "the circles disappear." A page refresh fires
the same `/leave` API call as an intentional exit, and the host branch of
that endpoint treated any leave as permanent.

## Files

1. **lib/db/migrations/0073_audio_circle_host_grace_period.sql** — new
   migration, adds `host_disconnected_at` to `audio_circle_sessions`.
2. **lib/db/src/schema/audio-circles.ts** — schema field for the same column.
3. **artifacts/api-server/src/routes/audio-circles.ts** — the actual fix.
   `/leave`, when the host leaves, no longer ends the session — it starts a
   90-second reconnect grace period instead. `/join` clears that flag
   automatically when the host reconnects (their participant row was never
   marked "left," so the existing rejoin logic picks it up with no new code
   path). Any session read lazily ends it if the host never comes back
   within the window. The explicit "End Session" button (a different
   endpoint, `/end`) is untouched — that still ends immediately, as intended.
4. **artifacts/api-server/src/lib/ws-hub.ts** — two new WS event types,
   `circle_host_disconnected` / `circle_host_reconnected`.
5. **artifacts/api-server/src/__tests__/audio-circles.test.ts** — added 2
   regression tests for this exact path, which had zero coverage before
   (despite being the most consequential branch in the file).
6. **artifacts/pay-it-forward/src/lib/wsClient.ts** — matching frontend WS
   event types.
7. **artifacts/pay-it-forward/src/pages/audio-circle-room.tsx** — shows a
   "Host reconnecting…" toast instead of kicking everyone out, and "Host is
   back" when they return.

## Verified before packaging
Full monorepo typecheck, full build, and all three test suites — 194 tests
(141 backend + 34 nia-service + 19 frontend) — pass with these files in
place.
