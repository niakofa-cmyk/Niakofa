import { useState, useCallback, useRef, useEffect, type RefObject } from "react";
import type mapboxgl from "mapbox-gl";

export type OrientationMode = "north-up" | "heading-up";

interface UseMapOrientationReturn {
  mode: OrientationMode;
  setMode: (mode: OrientationMode) => void;
  applyHeading: (headingDeg: number) => void;
}

function shortestDelta(target: number, current: number): number {
  return ((target - current + 540) % 360) - 180;
}

// Exponential approach rate (1/s). Higher = snappier. Tuned so a 90° turn
// settles in ~300-400ms with no overshoot — the same feel as Google Maps'
// heading-up camera.
const ROTATION_STIFFNESS = 10;

/**
 * useMapOrientation
 *
 * Manages north-up vs heading-up map rotation.
 *
 * ── Bug fix (was causing heading-up to "jump") ──────────────────────────────
 * The previous version called `map.easeTo({ bearing, duration: 300 })` on
 * every single heading update. Compass/GPS heading updates can arrive faster
 * than a 300ms tween can finish, so each new call interrupted the previous
 * animation mid-flight — Mapbox has to restart its rotation tween from
 * whatever bearing it happened to be at, which is exactly what reads as a
 * "jump" or stutter to the eye.
 *
 * Fix: instead of issuing discrete tweens, we run one continuous
 * requestAnimationFrame loop for the whole heading-up session. Each frame
 * nudges the camera bearing a fraction of the way toward the latest target
 * heading (frame-rate-independent exponential smoothing), and the delta is
 * always computed as the shortest angular path so the camera never spins the
 * long way around when heading crosses the 0°/360° boundary. This is the
 * same technique turn-by-turn nav apps use for their camera.
 */
export function useMapOrientation(
  mapRef: RefObject<mapboxgl.Map | null>
): UseMapOrientationReturn {
  const [mode, setModeState] = useState<OrientationMode>("heading-up");
  const modeRef = useRef(mode);
  const targetHeadingRef = useRef<number>(0);
  const rafRef = useRef<number | null>(null);
  const lastFrameTimeRef = useRef<number>(0);

  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  const tick = useCallback((t: number) => {
    const map = mapRef.current;
    if (!map || modeRef.current !== "heading-up") {
      rafRef.current = null;
      return;
    }

    const dt = lastFrameTimeRef.current
      ? Math.min((t - lastFrameTimeRef.current) / 1000, 0.1)
      : 0.016;
    lastFrameTimeRef.current = t;

    const current = map.getBearing();
    const delta = shortestDelta(targetHeadingRef.current, current);

    if (Math.abs(delta) < 0.05) {
      rafRef.current = requestAnimationFrame(tick);
      return;
    }

    const alpha = 1 - Math.exp(-ROTATION_STIFFNESS * dt);
    const next = ((current + delta * alpha) % 360 + 360) % 360;
    map.setBearing(next);

    rafRef.current = requestAnimationFrame(tick);
  }, [mapRef]);

  const ensureLoop = useCallback(() => {
    if (rafRef.current == null) {
      lastFrameTimeRef.current = 0;
      rafRef.current = requestAnimationFrame(tick);
    }
  }, [tick]);

  useEffect(() => {
    return () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const setMode = useCallback((next: OrientationMode) => {
    setModeState(next);
    modeRef.current = next;
    const map = mapRef.current;
    if (!map) return;

    if (next === "north-up") {
      if (rafRef.current != null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      map.easeTo({ bearing: 0, duration: 600, easing: (t) => t * (2 - t) });
    } else {
      targetHeadingRef.current = map.getBearing();
      ensureLoop();
    }
  }, [mapRef, ensureLoop]);

  const applyHeading = useCallback((headingDeg: number) => {
    targetHeadingRef.current = headingDeg;
    if (modeRef.current === "heading-up") ensureLoop();
  }, [ensureLoop]);

  return { mode, setMode, applyHeading };
}
