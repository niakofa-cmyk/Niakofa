import { useEffect, useRef, useState } from "react";

/**
 * useFusedHeading
 *
 * This is the piece that was never wired up. `AppContext`'s GPS watcher
 * already computes `myLocation.heading` — a course-over-ground bearing, either
 * straight from `GeolocationCoordinates.heading` or derived from consecutive
 * fixes when the browser doesn't supply one. That signal is far more stable
 * than the phone's magnetometer once you're actually moving (a compass in a
 * car dashboard mount swings wildly near the engine/frame; GPS course does
 * not), but the map's heading-up mode was built to read only from the
 * compass and never looked at it.
 *
 * This hook fuses the two exactly the way Google Maps / Waze do:
 *  - Below walking speed, GPS course is noisy/undefined → trust the compass.
 *  - Above a small speed threshold, blend toward GPS course, fully trusting
 *    it once the user is moving at a normal walking/driving pace.
 *  - The blend is a complementary filter (shortest-path angular smoothing),
 *    so there's never a visible "pop" when the dominant source changes.
 */

interface FusedHeadingInput {
  gpsHeading: number | null | undefined;
  gpsSpeed: number | null | undefined; // meters/second
  compassHeading: number | null;
}

export interface FusedHeadingResult {
  heading: number | null;
  source: "gps" | "compass" | null;
}

// Below this speed (m/s), GPS course-over-ground is unreliable/undefined —
// lean entirely on the compass. ~0.8 m/s ≈ a slow walk.
const MIN_SPEED_FOR_GPS = 0.8;
// Above this speed, fully trust GPS course (typical brisk walk / driving).
const GPS_TRUST_SPEED = 2.5;

function shortestDelta(target: number, current: number): number {
  return ((target - current + 540) % 360) - 180;
}

export function useFusedHeading({
  gpsHeading,
  gpsSpeed,
  compassHeading,
}: FusedHeadingInput): FusedHeadingResult {
  const [heading, setHeading] = useState<number | null>(null);
  const sourceRef = useRef<"gps" | "compass" | null>(null);

  useEffect(() => {
    const speed = gpsSpeed ?? 0;
    const gpsUsable = gpsHeading != null && !Number.isNaN(gpsHeading) && speed >= MIN_SPEED_FOR_GPS;
    const target = gpsUsable ? gpsHeading! : compassHeading;
    if (target == null) return;

    sourceRef.current = gpsUsable ? "gps" : "compass";

    setHeading((prev) => {
      if (prev == null) return target;
      const trust = gpsUsable
        ? Math.min(1, (speed - MIN_SPEED_FOR_GPS) / (GPS_TRUST_SPEED - MIN_SPEED_FOR_GPS))
        : 0;
      // Weight: fast movement snaps hard to GPS; otherwise ease toward
      // whichever source is active so switches never pop.
      const weight = Math.max(0.18, trust);
      const delta = shortestDelta(target, prev);
      return (prev + delta * weight + 360) % 360;
    });
  }, [gpsHeading, gpsSpeed, compassHeading]);

  return { heading, source: sourceRef.current };
}
