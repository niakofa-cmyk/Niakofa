import { useState, useEffect, useRef } from "react";

/**
 * useDeviceHeading
 *
 * Returns the device's compass heading in degrees (0–360, true north = 0),
 * or null if the device doesn't support orientation events.
 *
 * On iOS 13+ we must request permission before reading DeviceOrientationEvent.
 * We do this lazily on the first user gesture that calls requestPermission().
 *
 * ── Bug fix (was causing heading-up to "jump") ──────────────────────────────
 * The previous version listened to BOTH `deviceorientationabsolute` and
 * `deviceorientation` simultaneously. On Android/Chrome both fire for the same
 * physical rotation, but `deviceorientation`'s `alpha` is relative to whatever
 * the device happened to be facing when the page loaded, while
 * `deviceorientationabsolute` is locked to true north. Feeding both into the
 * same setState call made the reported heading alternate between two
 * different reference frames — that's the visible "jump". Fix: once a true
 * absolute reading has ever arrived, the relative listener is ignored for the
 * rest of the session.
 *
 * We also apply circular exponential smoothing (averaging via sin/cos, so it
 * behaves correctly across the 0°/360° wrap) to remove magnetometer jitter,
 * and throttle React state updates to ~20fps since raw sensor events can fire
 * well above 60Hz on some devices — that alone was enough to make the camera
 * animation thrash.
 */

declare global {
  interface DeviceOrientationEvent {
    webkitCompassHeading?: number;
  }
  interface DeviceOrientationEventConstructor {
    requestPermission?: () => Promise<"granted" | "denied" | "default">;
  }
}

function smoothAngle(prev: number | null, next: number, alpha: number): number {
  if (prev == null) return next;
  const rad = (deg: number) => (deg * Math.PI) / 180;
  const sin = Math.sin(rad(prev)) * (1 - alpha) + Math.sin(rad(next)) * alpha;
  const cos = Math.cos(rad(prev)) * (1 - alpha) + Math.cos(rad(next)) * alpha;
  const deg = (Math.atan2(sin, cos) * 180) / Math.PI;
  return (deg + 360) % 360;
}

export function useDeviceHeading(): number | null {
  const [heading, setHeading] = useState<number | null>(null);
  const smoothedRef = useRef<number | null>(null);
  const lastEmitRef = useRef(0);

  useEffect(() => {
    let active = true;
    let hasAbsoluteSource = false; // true-north events win once they appear

    function emit(raw: number) {
      const smoothed = smoothAngle(smoothedRef.current, raw, 0.35);
      smoothedRef.current = smoothed;

      const now = performance.now();
      if (now - lastEmitRef.current < 50) return; // ~20fps ceiling on renders
      lastEmitRef.current = now;
      setHeading(smoothed);
    }

    function readHeading(e: DeviceOrientationEvent): number | null {
      if (typeof e.webkitCompassHeading === "number") return e.webkitCompassHeading;
      if (e.alpha != null) return (360 - e.alpha) % 360;
      return null;
    }

    function handleAbsolute(e: DeviceOrientationEvent) {
      if (!active) return;
      hasAbsoluteSource = true;
      const h = readHeading(e);
      if (h != null) emit(h);
    }

    function handleRelative(e: DeviceOrientationEvent) {
      if (!active || hasAbsoluteSource) return; // never mix reference frames
      const h = readHeading(e);
      if (h != null) emit(h);
    }

    async function start() {
      const DC = DeviceOrientationEvent as DeviceOrientationEventConstructor;
      if (typeof DC.requestPermission === "function") {
        try {
          const perm = await DC.requestPermission();
          if (perm !== "granted") return;
        } catch {
          return;
        }
      }

      window.addEventListener("deviceorientationabsolute", handleAbsolute as EventListener, true);
      window.addEventListener("deviceorientation", handleRelative as EventListener, true);
    }

    start();

    return () => {
      active = false;
      window.removeEventListener("deviceorientationabsolute", handleAbsolute as EventListener, true);
      window.removeEventListener("deviceorientation", handleRelative as EventListener, true);
    };
  }, []);

  return heading;
}
