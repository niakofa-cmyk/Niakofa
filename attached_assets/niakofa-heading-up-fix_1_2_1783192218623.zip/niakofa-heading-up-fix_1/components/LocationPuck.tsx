/**
 * LocationPuck
 *
 * Replaces the plain glowing dot with a Google-Maps/Waze-style "puck": a
 * pulsing accuracy halo plus a directional cone pointing the way the user is
 * actually facing (fused GPS course + compass heading).
 *
 * Rotation is `heading - mapBearing`, not just `heading` — that's what makes
 * it correct in BOTH modes with the same component:
 *  - Heading-up: the map itself rotates to match heading, so the cone's
 *    relative rotation is ~0 and it always points straight up (classic
 *    "driving mode" look).
 *  - North-up: the map bearing is 0, so the cone rotates to the raw heading —
 *    exactly what you want when the map is static and you need to see which
 *    way you're actually facing.
 */

interface LocationPuckProps {
  heading: number | null;
  mapBearing: number;
  accuracy?: number | null;
}

export function LocationPuck({ heading, mapBearing, accuracy }: LocationPuckProps) {
  const showCone = heading != null;
  const rotation = showCone ? ((heading! - mapBearing) % 360 + 360) % 360 : 0;

  // Wider accuracy ring for poor GPS fixes, capped so it never overwhelms the map.
  const ringScale = accuracy != null ? Math.min(2.2, Math.max(1, accuracy / 15)) : 1;

  return (
    <div className="relative flex items-center justify-center w-8 h-8">
      <div
        className="absolute bg-primary rounded-full opacity-10 animate-ping"
        style={{ width: 32 * ringScale, height: 32 * ringScale, animationDuration: "2s" }}
      />
      <div
        className="absolute bg-primary rounded-full opacity-20 animate-ping"
        style={{ width: 20 * ringScale, height: 20 * ringScale, animationDuration: "2s", animationDelay: "0.5s" }}
      />

      {showCone && (
        <div
          className="absolute w-8 h-8 transition-transform duration-150 ease-linear"
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          <svg viewBox="0 0 32 32" className="w-8 h-8 overflow-visible">
            <path
              d="M16 -2 L26 14 A13 13 0 0 1 6 14 Z"
              fill="hsl(190, 100%, 55%)"
              opacity="0.35"
            />
          </svg>
        </div>
      )}

      <div className="w-3 h-3 bg-primary rounded-full shadow-[0_0_12px_rgba(0,212,255,0.9)] border-2 border-background z-10" />
    </div>
  );
}
