# ⚠️ DEPRECATED — NOT THE REAL APP

This directory is a stale, disconnected duplicate. It is **not** part of the
pnpm workspace (not listed in `pnpm-workspace.yaml`), is not built, and is
not served in production.

The real frontend lives at **`artifacts/pay-it-forward/`**.

Do not add code here. This directory should be deleted once confirmed
unnecessary by the team.
