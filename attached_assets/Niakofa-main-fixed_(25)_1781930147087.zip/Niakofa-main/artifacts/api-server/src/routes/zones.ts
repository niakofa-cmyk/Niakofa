import { Router } from "express";
import { db, h3CellsTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";
import { toH3Cell, h3CellAndNeighbors } from "../lib/h3";

const router = Router();

/**
 * Returns zone status for the H3 cell containing a given lat/lng, plus
 * whether any immediate neighbor cell is active — exactly the same cell set
 * zone-based dispatch itself considers, so the UI is never showing a
 * different picture than what dispatch is actually using. Public/
 * unauthenticated: this is purely informational map data, same sensitivity
 * level as /helpers/online.
 */
router.get("/h3-zones/status", async (req, res) => {
  const lat = req.query.lat ? parseFloat(req.query.lat as string) : undefined;
  const lng = req.query.lng ? parseFloat(req.query.lng as string) : undefined;
  if (lat === undefined || lng === undefined || isNaN(lat) || isNaN(lng)) {
    return res.status(400).json({ error: "lat and lng are required" });
  }

  const cellId = toH3Cell(lat, lng);
  const neighborIds = h3CellAndNeighbors(cellId).filter(id => id !== cellId);

  const [cell] = await db.select().from(h3CellsTable).where(eq(h3CellsTable.h3_id, cellId)).limit(1);
  const neighborCells = neighborIds.length > 0
    ? await db.select({ is_active_zone: h3CellsTable.is_active_zone })
        .from(h3CellsTable)
        .where(inArray(h3CellsTable.h3_id, neighborIds))
    : [];
  const neighborsActive = neighborCells.some(n => n.is_active_zone);

  if (!cell) {
    // No activity recorded here yet — not an error, just means this exact
    // cell has never had enough density to be evaluated. Always radius-based.
    return res.json({
      h3_id: cellId,
      is_active_zone: false,
      zone_status: "slow",
      neighbors_active: neighborsActive,
    });
  }

  return res.json({
    h3_id: cell.h3_id,
    is_active_zone: cell.is_active_zone,
    zone_status: cell.zone_status,
    request_count_24h: cell.request_count_24h,
    helper_count_now: cell.helper_count_now,
    neighbors_active: cell.is_active_zone ? false : neighborsActive,
  });
});

export default router;
