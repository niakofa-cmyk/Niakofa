import { Router } from "express";
import { requireAuth } from "../middlewares/auth";
import { requireOwnership } from "../middlewares/authz";
import { db, requestsTable, usersTable, transactionsTable, stripeAccountsTable, paymentTransactionsTable, ratingsTable, requestOffersTable } from "@workspace/db";
import { eq, and, sql, inArray, desc, type SQL } from "drizzle-orm";
import {
  GetRequestsQueryParams,
  GetRequestParams,
  CreateRequestBody,
  UpdateRequestParams,
  UpdateRequestBody,
  ClaimRequestParams,
  CompleteRequestParams,
  GetNearbyRequestsQueryParams,
  MarkEnRouteParams,
  MarkArrivedParams,
} from "@workspace/api-zod";
import { broadcast, broadcastRequestEvent } from "../lib/ws-hub";
import { requestCreationLimiter } from "../middlewares/rate-limit";
import { enqueuePayoutRetry } from "../lib/queue";
import { sendPushToNearbyHelpers, sendPushToAllHelpers, sendPushToUser } from "./push";
import { broadcastLeaderboardUpdate } from "./leaderboard";
import { logger } from "../lib/logger";
import { sendReceipt, sendAlertEmail } from "../lib/mailer";
import { dispatchNext, supersedePendingOffers } from "../lib/dispatch";
import { toH3Cell } from "../lib/h3";
import Stripe from "stripe";

// Lazy Stripe client — null when STRIPE_SECRET_KEY is not configured
const _STRIPE_SK = process.env["STRIPE_SECRET_KEY"] ?? "";
const _stripe = _STRIPE_SK
  ? new Stripe(_STRIPE_SK, { apiVersion: "2024-06-20" as Stripe.LatestApiVersion })
  : null;

const router = Router();

function distanceMiles(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function enrichRequest(r: typeof requestsTable.$inferSelect, userMap: Record<number, { name: string; avatar_url: string | null }>, helperName?: string | null, extraFields?: Record<string, unknown>) {
  return {
    ...r,
    requester_name: userMap[r.requester_id]?.name ?? null,
    requester_avatar: userMap[r.requester_id]?.avatar_url ?? null,
    helper_name: helperName ?? null,
    distance_miles: null,
    estimated_duration_min: null,
    ...extraFields,
  };
}

router.get("/requests/stats", requireAuth, async (_req, res) => {
  // All aggregations done at the DB level — no full table scan into memory
  const [statusCounts, categoryCounts, recentCompletions, pledgeVolume, onlineHelpers] =
    await Promise.all([
      db
        .select({ status: requestsTable.status, count: sql<number>`COUNT(*)::int` })
        .from(requestsTable)
        .groupBy(requestsTable.status),

      db
        .select({ category: requestsTable.category, count: sql<number>`COUNT(*)::int` })
        .from(requestsTable)
        .groupBy(requestsTable.category),

      db
        .select({ count: sql<number>`COUNT(*)::int` })
        .from(requestsTable)
        .where(
          and(
            eq(requestsTable.status, "completed"),
            sql`${requestsTable.completed_at} > NOW() - INTERVAL '24 hours'`
          )
        ),

      db
        .select({ total: sql<number>`COALESCE(SUM(${requestsTable.pledge_paid}), 0)::float` })
        .from(requestsTable),

      db
        .select({ count: sql<number>`COUNT(*)::int` })
        .from(usersTable)
        .where(eq(usersTable.helper_mode_active, true)),
    ]);

  return res.json({
    total_open:             statusCounts.find(s => s.status === "open")?.count ?? 0,
    total_completed:        statusCounts.find(s => s.status === "completed")?.count ?? 0,
    total_helpers_online:   onlineHelpers[0]?.count ?? 0,
    requests_by_category:   categoryCounts,
    recent_completions:     recentCompletions[0]?.count ?? 0,
    total_pledge_volume:    pledgeVolume[0]?.total ?? 0,
  });
});

router.get("/requests/nearby", requireAuth, async (req, res) => {
  const parsed = GetNearbyRequestsQueryParams.safeParse({
    lat: parseFloat(req.query.lat as string),
    lng: parseFloat(req.query.lng as string),
    radius_miles: req.query.radius_miles ? parseFloat(req.query.radius_miles as string) : 5,
  });
  if (!parsed.success) return res.status(400).json({ error: "lat and lng are required" });
  const { lat, lng, radius_miles } = parsed.data;
  const radius = radius_miles ?? 5;
  const requests = await db.select().from(requestsTable).where(eq(requestsTable.status, "open"));
  const nearby = requests
    .map(r => ({ ...r, distance_miles: distanceMiles(lat, lng, r.lat, r.lng) }))
    .filter(r => r.distance_miles <= radius)
    .sort((a, b) => {
      const urgencyOrder: Record<string, number> = { emergency: 0, high: 1, medium: 2, low: 3 };
      const urgencyDiff = (urgencyOrder[a.urgency] ?? 2) - (urgencyOrder[b.urgency] ?? 2);
      if (urgencyDiff !== 0) return urgencyDiff;
      return a.distance_miles - b.distance_miles;
    });

  const userIds = [...new Set(nearby.map(r => r.requester_id))];
  const users = userIds.length > 0
    ? await db.select({ id: usersTable.id, name: usersTable.name, avatar_url: usersTable.avatar_url })
        .from(usersTable)
        .where(sql`${usersTable.id} = ANY(ARRAY[${sql.join(userIds.map(id => sql`${id}`), sql`, `)}]::int[])`)
    : [];
  const userMap = Object.fromEntries(users.map(u => [u.id, u]));

  return res.json(nearby.map(r => ({
    ...r,
    requester_name: userMap[r.requester_id]?.name ?? null,
    requester_avatar: userMap[r.requester_id]?.avatar_url ?? null,
    helper_name: null,
    estimated_duration_min: Math.round(r.distance_miles * 3),
  })));
});

router.get("/requests", requireAuth, async (req, res) => {
  const params = GetRequestsQueryParams.safeParse({
    status: req.query.status,
    lat: req.query.lat ? parseFloat(req.query.lat as string) : undefined,
    lng: req.query.lng ? parseFloat(req.query.lng as string) : undefined,
    radius_miles: req.query.radius_miles ? parseFloat(req.query.radius_miles as string) : undefined,
  });
  if (!params.success) return res.status(400).json({ error: "Invalid query parameters" });

  // Optional helper_id filter — used by helper profile page
  const helperId = req.query.helper_id ? parseInt(req.query.helper_id as string) : null;
  // Optional requester_id filter — used by profile page to fetch user's own requests
  const requesterId = req.query.requester_id ? parseInt(req.query.requester_id as string) : null;
  // Optional limit
  const limitParam = req.query.limit ? parseInt(req.query.limit as string) : null;

  const whereConditions: SQL[] = [];
  if (helperId) whereConditions.push(eq(requestsTable.helper_id, helperId));
  if (requesterId) whereConditions.push(eq(requestsTable.requester_id, requesterId));
  if (params.data.status) whereConditions.push(eq(requestsTable.status, params.data.status));

  // Use !== undefined rather than truthiness — lat/lng of exactly 0 (equator /
  // prime meridian) is a valid coordinate and must not silently skip the filter.
  if (params.data.lat !== undefined && params.data.lng !== undefined) {
    const radius = params.data.radius_miles ?? 10;
    const lat = params.data.lat;
    const lng = params.data.lng;

    // Cheap bounding-box pre-filter first, so Postgres can actually use the
    // existing (lat, lng) B-tree index — the precise acos() expression below
    // is a transcendental function over both columns and can't use an index
    // on its own. Same pattern already used in helpers.ts.
    const latDelta = radius / 69;
    const lngDelta = radius / (69 * Math.cos((lat * Math.PI) / 180));
    whereConditions.push(
      sql`${requestsTable.lat} BETWEEN ${lat - latDelta} AND ${lat + latDelta}`,
      sql`${requestsTable.lng} BETWEEN ${lng - lngDelta} AND ${lng + lngDelta}`,
    );

    // Precise Haversine distance, clamped to [-1, 1] before acos(). Without
    // the clamp, floating-point rounding on near-identical coordinates (e.g.
    // a requester querying from the exact location of their own open
    // request) can push the argument fractionally above 1 and make Postgres
    // raise "input is out of range", a 500 for an entirely normal query.
    whereConditions.push(sql`(
      3959 * acos(
        LEAST(1, GREATEST(-1,
          cos(radians(${lat})) * cos(radians(${requestsTable.lat})) *
          cos(radians(${requestsTable.lng}) - radians(${lng})) +
          sin(radians(${lat})) * sin(radians(${requestsTable.lat}))
        ))
      )
    ) <= ${radius}`);
  }

  let query = db.select().from(requestsTable).$dynamic();
  if (whereConditions.length > 0) {
    query = query.where(and(...whereConditions));
  }
  query = query.orderBy(desc(requestsTable.created_at));
  if (limitParam && limitParam > 0) {
    query = query.limit(limitParam);
  }

  const rows = await query;

  // Collect all relevant user IDs (requesters + helpers) for a single batch fetch
  const allUserIds = [...new Set([
    ...rows.map(r => r.requester_id),
    ...rows.map(r => r.helper_id).filter((id): id is number => id != null),
  ])];
  const users = allUserIds.length > 0
    ? await db.select({ id: usersTable.id, name: usersTable.name, avatar_url: usersTable.avatar_url })
        .from(usersTable)
        .where(sql`${usersTable.id} = ANY(ARRAY[${sql.join(allUserIds.map(id => sql`${id}`), sql`, `)}]::int[])`)
    : [];
  const userMap = Object.fromEntries(users.map(u => [u.id, u]));

  return res.json(rows.map(r => ({
    ...r,
    requester_name: userMap[r.requester_id]?.name ?? null,
    requester_avatar: userMap[r.requester_id]?.avatar_url ?? null,
    helper_name: r.helper_id ? (userMap[r.helper_id]?.name ?? null) : null,
    helper_avatar: r.helper_id ? (userMap[r.helper_id]?.avatar_url ?? null) : null,
    distance_miles: null,
    estimated_duration_min: null,
  })));
});

router.post("/requests", requireAuth, requireOwnership("requester_id"), requestCreationLimiter, async (req, res) => {
  const parsed = CreateRequestBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.message });

  // Max 5 active requests per user (open / claimed / en_route / arrived)
  const [activeCount] = await db
    .select({ count: sql<number>`COUNT(*)::int` })
    .from(requestsTable)
    .where(
      and(
        eq(requestsTable.requester_id, parsed.data.requester_id),
        inArray(requestsTable.status, ["open", "claimed", "en_route", "arrived"])
      )
    );
  if ((activeCount?.count ?? 0) >= 5) {
    return res.status(429).json({
      error:
        "You have 5 active requests already. " +
        "Please wait for one to complete before creating another — this keeps the map accurate for everyone.",
    });
  }

  const [request] = await db.insert(requestsTable).values({
    title: parsed.data.title,
    description: parsed.data.description ?? null,
    category: parsed.data.category ?? "other",
    urgency: parsed.data.urgency ?? "medium",
    payment_type: parsed.data.payment_type ?? "pay_it_forward",
    status: "open",
    requester_id: parsed.data.requester_id,
    lat: parsed.data.lat,
    lng: parsed.data.lng,
    h3_cell_id: toH3Cell(parsed.data.lat, parsed.data.lng),
    neighborhood: parsed.data.neighborhood ?? null,
    pay_it_forward_amount: parsed.data.pay_it_forward_amount ?? null,
    pledge_amount: parsed.data.pledge_amount ?? null,
  }).returning();

  const enriched = { ...request, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null };
  broadcastRequestEvent("REQUEST_CREATED", "new_request", enriched);

  // Kick off dispatch — sends an exclusive offer to the best nearby candidate.
  // Best-effort and non-blocking: the request is already visible and
  // claimable on the public map regardless of whether dispatch finds anyone.
  dispatchNext(request.id).catch(err => logger.warn({ err, request_id: request.id }, "dispatch: non-fatal failure"));

  // Push notifications — geolocation-targeted when request has coordinates
  if (request.urgency === "emergency" || request.urgency === "high") {
    const isEmergency = request.urgency === "emergency";
    const payload = {
      title: isEmergency ? "🚨 EMERGENCY — Help Needed Now!" : "🔴 Urgent Request Nearby",
      body: request.title,
      urgency: request.urgency,
      requestId: request.id,
    };
    // Notify helpers within 15 miles of the request; fall back to all helpers if no nearby ones found
    sendPushToNearbyHelpers(request.lat, request.lng, 15, payload).catch(() => {
      sendPushToAllHelpers(payload).catch(() => {});
    });
  } else {
    // For medium/low urgency, notify helpers within 5 miles
    sendPushToNearbyHelpers(request.lat, request.lng, 5, {
      title: "💙 Help Request Near You",
      body: request.title,
      urgency: request.urgency,
      requestId: request.id,
    }).catch(() => {});
  }

  return res.status(201).json(enriched);
});

router.get("/requests/:id", requireAuth, async (req, res) => {
  const parsed = GetRequestParams.safeParse({ id: parseInt(req.params.id as string) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
  const [request] = await db.select().from(requestsTable).where(eq(requestsTable.id, parsed.data.id)).limit(1);
  if (!request) return res.status(404).json({ error: "Not found" });
  const [requester] = await db.select({ id: usersTable.id, name: usersTable.name, avatar_url: usersTable.avatar_url })
    .from(usersTable).where(eq(usersTable.id, request.requester_id)).limit(1);
  let helperName = null;
  if (request.helper_id) {
    const [helper] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, request.helper_id)).limit(1);
    helperName = helper?.name ?? null;
  }
  return res.json({ ...request, requester_name: requester?.name ?? null, requester_avatar: requester?.avatar_url ?? null, helper_name: helperName, distance_miles: null, estimated_duration_min: null });
});

router.patch("/requests/:id", requireAuth, async (req, res) => {
  const authenticatedUserId = req.authenticatedUserId;
  const requestId = parseInt(req.params.id as string);
  const [existing] = await db.select().from(requestsTable).where(eq(requestsTable.id, requestId)).limit(1);
  if (!existing) return res.status(404).json({ error: "Request not found" });
  if (existing.requester_id !== authenticatedUserId) {
    return res.status(403).json({ error: "Forbidden: You can only update your own requests" });
  }
  const pParsed = UpdateRequestParams.safeParse({ id: requestId });
  const bParsed = UpdateRequestBody.safeParse(req.body);
  if (!pParsed.success || !bParsed.success) return res.status(400).json({ error: "Invalid" });
  const updates: Record<string, unknown> = {};
  if (bParsed.data.status !== undefined) updates.status = bParsed.data.status;
  if (bParsed.data.description !== undefined) updates.description = bParsed.data.description;
  if (bParsed.data.urgency !== undefined) updates.urgency = bParsed.data.urgency;
  const [updated] = await db.update(requestsTable).set(updates).where(eq(requestsTable.id, pParsed.data.id)).returning();
  if (!updated) return res.status(404).json({ error: "Not found" });
  const enriched = { ...updated, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null };
  broadcast({ type: "request_updated", payload: enriched });
  return res.json(enriched);
});

router.post("/requests/:id/claim", requireAuth, async (req, res) => {
  const helperId = req.authenticatedUserId!;
  const pParsed = ClaimRequestParams.safeParse({ id: parseInt(String(req.params.id)) });
  if (!pParsed.success) return res.status(400).json({ error: "Invalid request id" });

  // Prevent requester from claiming their own request
  const [existing] = await db.select({ requester_id: requestsTable.requester_id })
    .from(requestsTable).where(eq(requestsTable.id, pParsed.data.id)).limit(1);
  if (!existing) return res.status(404).json({ error: "Request not found" });
  if (existing.requester_id === helperId) return res.status(403).json({ error: "Cannot claim your own request" });

  const [request] = await db.update(requestsTable)
    .set({ status: "claimed", helper_id: helperId, claimed_at: new Date() })
    .where(and(eq(requestsTable.id, pParsed.data.id), eq(requestsTable.status, "open")))
    .returning();
  if (!request) return res.status(409).json({ error: "Request already claimed or not found" });

  // Whoever claimed it — via dispatch offer or the public claim button —
  // wins. Clear out any other still-pending offers for this request so
  // those helpers' UIs don't keep counting down toward a dead offer.
  supersedePendingOffers(request.id).catch(() => {});

  const [helper] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, helperId)).limit(1);
  const enriched = { ...request, requester_name: null, requester_avatar: null, helper_name: helper?.name ?? null, distance_miles: null, estimated_duration_min: null };
  broadcastRequestEvent("REQUEST_ACCEPTED", "request_updated", enriched);

  // Notify requester that their request has been claimed
  const [requesterRow] = await db.select({ email: usersTable.email, name: usersTable.name })
    .from(usersTable).where(eq(usersTable.id, request.requester_id)).limit(1);
  if (requesterRow?.email) {
    sendAlertEmail({
      to: requesterRow.email,
      subject: "Your request was claimed!",
      title: "A helper is coming 💙",
      body: `Great news, ${requesterRow.name}! ${helper?.name ?? "A helper"} just claimed your request: "${request.title}". They should be on their way shortly.`,
    }).catch(err => logger.warn({ err }, "claim: sendAlertEmail failed"));
  }

  return res.json(enriched);
});

// ── Accept a dispatch offer ──────────────────────────────────────────────────
// Wins the same atomic claim the public /claim button uses — dispatch never
// gets a separate, weaker guarantee than the public flow.
router.post("/requests/:id/offers/:offerId/accept", requireAuth, async (req, res) => {
  const helperId = req.authenticatedUserId!;
  const requestId = parseInt(String(req.params.id));
  const offerId = parseInt(String(req.params.offerId));
  if (isNaN(requestId) || isNaN(offerId)) return res.status(400).json({ error: "Invalid id" });

  const [offer] = await db.select().from(requestOffersTable).where(eq(requestOffersTable.id, offerId)).limit(1);
  if (!offer || offer.request_id !== requestId) return res.status(404).json({ error: "Offer not found" });
  if (offer.helper_id !== helperId) return res.status(403).json({ error: "This offer was not made to you" });
  if (offer.status !== "pending") return res.status(409).json({ error: `Offer already ${offer.status}` });
  if (offer.expires_at.getTime() < Date.now()) {
    return res.status(409).json({ error: "Offer has expired" });
  }

  // Same atomic guard as the public claim button — first writer wins,
  // whether they got here via dispatch or the public list.
  const [request] = await db.update(requestsTable)
    .set({ status: "claimed", helper_id: helperId, claimed_at: new Date() })
    .where(and(eq(requestsTable.id, requestId), eq(requestsTable.status, "open")))
    .returning();

  if (!request) {
    // Someone else (public claim, or another accepted offer) won the race
    // a moment earlier. Mark this offer expired rather than pending-forever.
    await db.update(requestOffersTable).set({ status: "expired", responded_at: new Date() }).where(eq(requestOffersTable.id, offerId));
    return res.status(409).json({ error: "Request was already claimed by someone else" });
  }

  await db.update(requestOffersTable)
    .set({ status: "accepted", responded_at: new Date() })
    .where(eq(requestOffersTable.id, offerId));
  supersedePendingOffers(requestId, offerId).catch(() => {});

  const [helper] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, helperId)).limit(1);
  const enriched = { ...request, requester_name: null, requester_avatar: null, helper_name: helper?.name ?? null, distance_miles: null, estimated_duration_min: null };
  broadcastRequestEvent("REQUEST_ACCEPTED", "request_updated", enriched);

  const [requesterRow] = await db.select({ email: usersTable.email, name: usersTable.name })
    .from(usersTable).where(eq(usersTable.id, request.requester_id)).limit(1);
  if (requesterRow?.email) {
    sendAlertEmail({
      to: requesterRow.email,
      subject: "Your request was claimed!",
      title: "A helper is coming 💙",
      body: `Great news, ${requesterRow.name}! ${helper?.name ?? "A helper"} just claimed your request: "${request.title}". They should be on their way shortly.`,
    }).catch(err => logger.warn({ err }, "offer-accept: sendAlertEmail failed"));
  }

  return res.json(enriched);
});

// ── Decline a dispatch offer ─────────────────────────────────────────────────
// Immediately cascades to the next candidate rather than waiting for the
// timeout — a fast "no thanks" shouldn't cost the requester 15 seconds.
router.post("/requests/:id/offers/:offerId/decline", requireAuth, async (req, res) => {
  const helperId = req.authenticatedUserId!;
  const requestId = parseInt(String(req.params.id));
  const offerId = parseInt(String(req.params.offerId));
  if (isNaN(requestId) || isNaN(offerId)) return res.status(400).json({ error: "Invalid id" });

  const [offer] = await db.select().from(requestOffersTable).where(eq(requestOffersTable.id, offerId)).limit(1);
  if (!offer || offer.request_id !== requestId) return res.status(404).json({ error: "Offer not found" });
  if (offer.helper_id !== helperId) return res.status(403).json({ error: "This offer was not made to you" });
  if (offer.status !== "pending") return res.status(409).json({ error: `Offer already ${offer.status}` });

  await db.update(requestOffersTable)
    .set({ status: "declined", responded_at: new Date() })
    .where(eq(requestOffersTable.id, offerId));

  dispatchNext(requestId).catch(err => logger.warn({ err, request_id: requestId }, "dispatch: non-fatal failure"));

  return res.json({ ok: true });
});

router.post("/requests/:id/en-route", requireAuth, async (req, res) => {
  const callerId = req.authenticatedUserId!;
  const pParsed = MarkEnRouteParams.safeParse({ id: parseInt(String(req.params.id)) });
  if (!pParsed.success) return res.status(400).json({ error: "Invalid request id" });

  // Verify caller is the assigned helper before updating
  const [current] = await db.select({ helper_id: requestsTable.helper_id })
    .from(requestsTable).where(eq(requestsTable.id, pParsed.data.id)).limit(1);
  if (!current) return res.status(404).json({ error: "Request not found" });
  if (current.helper_id !== callerId) return res.status(403).json({ error: "You are not the assigned helper for this request" });

  const [request] = await db.update(requestsTable)
    .set({ status: "en_route", en_route_at: new Date() })
    .where(and(eq(requestsTable.id, pParsed.data.id), eq(requestsTable.helper_id, callerId)))
    .returning();
  if (!request) return res.status(404).json({ error: "Not found" });
  const enriched = { ...request, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null };
  broadcastRequestEvent("HELPER_MOVING", "request_updated", enriched);

  // Notify requester that their helper is en route
  const [reqRow] = await db.select({ email: usersTable.email, name: usersTable.name })
    .from(usersTable).where(eq(usersTable.id, request.requester_id)).limit(1);
  const [helperRow] = await db.select({ name: usersTable.name })
    .from(usersTable).where(eq(usersTable.id, callerId)).limit(1);
  if (reqRow?.email) {
    sendAlertEmail({
      to: reqRow.email,
      subject: "Your helper is on the way!",
      title: "En route! 🚗",
      body: `${helperRow?.name ?? "Your helper"} is now on the way to help with "${request.title}". They should arrive soon — keep an eye out!`,
    }).catch(err => logger.warn({ err }, "en-route: sendAlertEmail failed"));
  }

  return res.json(enriched);
});

router.post("/requests/:id/arrived", requireAuth, async (req, res) => {
  const callerId = req.authenticatedUserId!;
  const pParsed = MarkArrivedParams.safeParse({ id: parseInt(String(req.params.id)) });
  if (!pParsed.success) return res.status(400).json({ error: "Invalid request id" });

  // Verify caller is the assigned helper before updating
  const [current] = await db.select({ helper_id: requestsTable.helper_id })
    .from(requestsTable).where(eq(requestsTable.id, pParsed.data.id)).limit(1);
  if (!current) return res.status(404).json({ error: "Request not found" });
  if (current.helper_id !== callerId) return res.status(403).json({ error: "You are not the assigned helper for this request" });

  const [request] = await db.update(requestsTable)
    .set({ status: "arrived", arrived_at: new Date() })
    .where(and(eq(requestsTable.id, pParsed.data.id), eq(requestsTable.helper_id, callerId)))
    .returning();
  if (!request) return res.status(404).json({ error: "Not found" });
  const enriched = { ...request, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null };
  broadcastRequestEvent("HELPER_ARRIVED", "request_updated", enriched);
  return res.json(enriched);
});

router.post("/requests/:id/complete", requireAuth, async (req, res) => {
  const callerId = req.authenticatedUserId!;
  const pParsed = CompleteRequestParams.safeParse({ id: parseInt(String(req.params.id)) });
  if (!pParsed.success) return res.status(400).json({ error: "Invalid request id" });

  // Verify caller is the assigned helper BEFORE making any mutations
  const [current] = await db.select({ helper_id: requestsTable.helper_id, status: requestsTable.status })
    .from(requestsTable).where(eq(requestsTable.id, pParsed.data.id)).limit(1);
  if (!current) return res.status(404).json({ error: "Request not found" });
  if (current.helper_id !== callerId) return res.status(403).json({ error: "You are not the assigned helper for this request" });
  if (current.status === "completed") return res.status(409).json({ error: "Request already completed" });

  const [request] = await db.update(requestsTable)
    .set({ status: "completed", completed_at: new Date() })
    .where(and(
      eq(requestsTable.id, pParsed.data.id),
      eq(requestsTable.helper_id, callerId),
      sql`${requestsTable.status} <> 'completed'`,
    ))
    .returning();
  // If another concurrent request already completed this job, `request` will
  // be undefined here even though `current` looked open a moment ago — the
  // atomic WHERE clause above is what actually prevents a double-payout.
  if (!request) return res.status(409).json({ error: "Request already completed" });

  // Capture pre-increment stats for tier-change detection + name for gratitude prompt
  const [helperBefore] = await db
    .select({ help_count: usersTable.help_count, trust_score: usersTable.trust_score, name: usersTable.name })
    .from(usersTable)
    .where(eq(usersTable.id, callerId))
    .limit(1);

  // Increment help_count
  await db.update(usersTable)
    .set({ help_count: sql`${usersTable.help_count} + 1` })
    .where(eq(usersTable.id, callerId));

  // Immediate-pay jobs: record in earnings history ONLY — do NOT credit benevolence_wallet.
  // benevolence_wallet is the goodwill/donation pot (pledges, sponsorships, tips).
  // The real money for immediate jobs arrives via the Stripe Connect transfer below.
  if (request.payment_type === "immediate" && request.pay_it_forward_amount && request.pay_it_forward_amount > 0) {
    await db.insert(transactionsTable).values({
      user_id: callerId,
      request_id: request.id,
      type: "earned",
      amount: request.pay_it_forward_amount,
      description: request.title,
    });
  }

  // Award goodwill point for volunteer missions
  if (request.payment_type === "goodwill") {
    await db.update(usersTable)
      .set({ goodwill_score: sql`${usersTable.goodwill_score} + 1` })
      .where(eq(usersTable.id, callerId));
    await db.insert(transactionsTable).values({
      user_id: callerId,
      request_id: request.id,
      type: "goodwill",
      amount: 0,
      description: request.title,
    });
  }

  // ── Real Stripe payout for immediate-pay completed requests ───────────────
  // Only fires when: payment_type === "immediate", amount > 0, Stripe configured,
  // and helper has a Connect account with payouts enabled.
  if (
    request.payment_type === "immediate" &&
    request.pay_it_forward_amount &&
    request.pay_it_forward_amount > 0 &&
    _stripe
  ) {
    let stripeAcct: typeof stripeAccountsTable.$inferSelect | undefined;
    try {
      // Safety check: never transfer platform funds to a helper unless we have
      // a confirmed, completed charge from the requester for THIS request.
      // Without this, a config edge case (e.g. Stripe enabled server-side but
      // the payment-intent step was skipped client-side) could pay a helper
      // out of the platform's Stripe balance for money that was never collected.
      const [confirmedPayment] = await db
        .select({ id: paymentTransactionsTable.id })
        .from(paymentTransactionsTable)
        .where(and(
          eq(paymentTransactionsTable.request_id, request.id),
          eq(paymentTransactionsTable.payment_type, "immediate"),
          eq(paymentTransactionsTable.state, "completed"),
        ))
        .limit(1);

      if (!confirmedPayment) {
        logger.warn(
          { request_id: request.id, helper_id: callerId },
          "payout: skipped — no confirmed payment_transactions row for this immediate request; will not transfer platform funds",
        );
      } else {
        [stripeAcct] = await db
          .select()
          .from(stripeAccountsTable)
          .where(eq(stripeAccountsTable.user_id, callerId))
          .limit(1);

        const amountCents = Math.round(request.pay_it_forward_amount * 100);
        const platformFeeCents = Math.round(amountCents * 0.05); // 5% platform fee

        if (stripeAcct?.payouts_enabled && stripeAcct.stripe_account_id) {
          const payoutCents = amountCents - platformFeeCents;

          const transfer = await _stripe.transfers.create({
            amount: payoutCents,
            currency: "usd",
            destination: stripeAcct.stripe_account_id,
            metadata: {
              request_id: String(request.id),
              helper_id: String(callerId),
              platform_fee_cents: String(platformFeeCents),
            },
          });

          // Record the completed payout
          await db.insert(paymentTransactionsTable).values({
            request_id: request.id,
            helper_id: callerId,
            requester_id: request.requester_id,
            amount: request.pay_it_forward_amount,
            platform_fee: platformFeeCents / 100,
            state: "completed",
            payment_type: "immediate",
            stripe_transfer_id: transfer.id,
            notes: `Auto-payout on completion. Platform fee: $${(platformFeeCents / 100).toFixed(2)}`,
          });

          broadcast({
            type: "payout_sent",
            payload: {
              helper_id: callerId,
              amount: payoutCents / 100,
              transfer_id: transfer.id,
            },
          });
        } else {
          // Helper hasn't finished Connect onboarding (or doesn't have an
          // account yet). This is NOT an error — it's an expected, common
          // case — but it still needs a retry, or the payout is lost forever
          // the moment the helper finishes onboarding later.
          logger.warn(
            { request_id: request.id, helper_id: callerId },
            "payout: helper has no active Stripe Connect payouts — enqueuing retry",
          );
          enqueuePayoutRetry({
            request_id:         request.id,
            helper_id:          callerId,
            requester_id:       request.requester_id,
            amount_cents:       amountCents,
            platform_fee_cents: platformFeeCents,
            stripe_account_id:  stripeAcct?.stripe_account_id ?? "",
            request_title:      request.title,
          }).catch(() => {});
        }
      }
    } catch (err: unknown) {
      // Non-fatal — wallet was already credited, but payout must be retried
      logger.error({ err, request_id: request.id }, "Stripe payout failed — enqueuing retry");
      // Enqueue for exponential-backoff retry via BullMQ (up to 5 attempts)
      if (stripeAcct?.stripe_account_id) {
        const amountCents = Math.round((request.pay_it_forward_amount ?? 0) * 100);
        const platformFeeCents = Math.round(amountCents * 0.05);
        enqueuePayoutRetry({
          request_id:         request.id,
          helper_id:          callerId,
          requester_id:       request.requester_id,
          amount_cents:       amountCents,
          platform_fee_cents: platformFeeCents,
          stripe_account_id:  stripeAcct.stripe_account_id,
          request_title:      request.title,
        }).catch(() => {});
      }
    }
  }

  const enriched = { ...request, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null };
  broadcastRequestEvent("REQUEST_COMPLETED", "request_updated", enriched);

  // Fire-and-forget leaderboard broadcast (doesn't block response)
  broadcastLeaderboardUpdate(
    callerId,
    helperBefore?.help_count ?? 0,
    helperBefore?.trust_score ?? 0
  ).catch(() => {});

  // Fire receipt email async (non-blocking)
  const [requester] = await db.select({ email: usersTable.email, name: usersTable.name })
    .from(usersTable).where(eq(usersTable.id, request.requester_id)).limit(1).catch(() => [null]);
  if (requester?.email) {
    sendReceipt({
      to: requester.email,
      helperName: helperBefore?.name ?? "Your helper",
      requesterName: requester.name,
      requestTitle: request.title,
      amount: request.payment_type === "immediate" ? (request.pay_it_forward_amount ?? undefined) : undefined,
      paymentType: request.payment_type,
      completedAt: new Date(),
    }).catch(() => {});
  }

  // Prompt the requester to write a public thank-you post
  broadcast({
    type: "new_gratitude_prompt",
    payload: {
      request_id: request.id,
      requester_id: request.requester_id,
      request_title: request.title,
      helper_name: helperBefore?.name ?? null,
      helper_id: callerId,
    },
  });

  return res.json(enriched);
});


router.post("/requests/:id/tip", requireAuth, async (req, res) => {
  const callerId = req.authenticatedUserId!;
  const requestId = parseInt(String(req.params.id));
  if (isNaN(requestId)) return res.status(400).json({ error: "Invalid id" });

  const { tip_amount } = req.body as { tip_amount: number };
  if (!tip_amount || tip_amount <= 0) {
    return res.status(400).json({ error: "tip_amount > 0 required" });
  }
  if (tip_amount > 500) {
    return res.status(400).json({ error: "tip_amount exceeds maximum of $500" });
  }

  const [request] = await db.select().from(requestsTable)
    .where(eq(requestsTable.id, requestId))
    .limit(1);
  if (!request) return res.status(404).json({ error: "Request not found" });
  // Only the actual requester (verified via auth token) can tip
  if (request.requester_id !== callerId) return res.status(403).json({ error: "Only the requester can tip on this request" });
  if (request.status !== "completed") return res.status(409).json({ error: "Can only tip completed requests" });
  if (!request.helper_id) return res.status(400).json({ error: "No helper to tip" });

  // Credit tip to helper benevolence_wallet
  await db.update(usersTable)
    .set({ benevolence_wallet: sql`${usersTable.benevolence_wallet} + ${tip_amount}` })
    .where(eq(usersTable.id, request.helper_id));

  await db.insert(transactionsTable).values({
    user_id: request.helper_id,
    request_id: requestId,
    type: "tip_received",
    amount: tip_amount,
    description: `Tip for: ${request.title}`,
  });

  broadcast({
    type: "payout_sent",
    payload: { helper_id: request.helper_id, amount: tip_amount, type: "tip" },
  });

  return res.status(201).json({ ok: true, tip_amount, helper_id: request.helper_id });
});

// POST /requests/:id/cancel
// Helper cancels → request re-opens to the pool (another helper can pick it up).
// Requester withdraws → request marked "cancelled" permanently.
router.post("/requests/:id/cancel", requireAuth, async (req, res) => {
  const callerId = req.authenticatedUserId!;
  const requestId = parseInt(String(req.params.id));
  if (isNaN(requestId)) return res.status(400).json({ error: "Invalid request id" });

  const [request] = await db.select()
    .from(requestsTable)
    .where(eq(requestsTable.id, requestId))
    .limit(1);

  if (!request) return res.status(404).json({ error: "Request not found" });

  if (["completed", "cancelled"].includes(request.status)) {
    return res.status(409).json({ error: `Request is already ${request.status}` });
  }

  const isRequester = request.requester_id === callerId;
  const isHelper = request.helper_id === callerId;

  if (!isRequester && !isHelper) {
    return res.status(403).json({ error: "Not authorized to cancel this request" });
  }

  let updated: typeof requestsTable.$inferSelect | undefined;

  if (isRequester) {
    // Requester permanently withdraws their request
    const [row] = await db.update(requestsTable)
      .set({ status: "cancelled", cancelled_at: new Date() })
      .where(eq(requestsTable.id, requestId))
      .returning();
    updated = row;
  } else {
    // Helper unclaims — re-opens to the pool so another helper can take it
    if (!["claimed", "en_route", "arrived"].includes(request.status)) {
      return res.status(409).json({ error: "Can only cancel an active claim" });
    }
    const [row] = await db.update(requestsTable)
      .set({
        status: "open",
        helper_id: null,
        claimed_at: null,
        en_route_at: null,
        arrived_at: null,
      })
      .where(eq(requestsTable.id, requestId))
      .returning();
    updated = row;
  }

  if (!updated) return res.status(500).json({ error: "Failed to cancel request" });

  // Either path ends any outstanding offers for this request — a withdrawn
  // request has nothing left to offer, and a reopened one needs a fresh
  // dispatch round rather than someone accepting a stale offer for the old
  // claim cycle.
  supersedePendingOffers(updated.id).catch(() => {});
  if (!isRequester) {
    // Helper unclaimed — request is back to "open". Try dispatch again
    // immediately rather than waiting on the next request's creation event.
    dispatchNext(updated.id).catch(err => logger.warn({ err, request_id: updated.id }, "dispatch: non-fatal failure"));
  }

  const enriched = {
    ...updated,
    requester_name: null, requester_avatar: null, helper_name: null,
    distance_miles: null, estimated_duration_min: null,
  };
  broadcast({ type: "request_updated", payload: enriched });

  // Push notification: when a helper cancels, immediately alert the requester so they know to look for a new helper
  if (!isRequester) {
    const [helperUser] = await db.select({ name: usersTable.name })
      .from(usersTable).where(eq(usersTable.id, callerId)).limit(1);
    const [requesterUser] = await db.select({ email: usersTable.email })
      .from(usersTable).where(eq(usersTable.id, request.requester_id)).limit(1);
    sendPushToUser(request.requester_id, {
      title: "Your helper cancelled",
      body: `${helperUser?.name ?? "Your helper"} can no longer help with "${request.title}". Your request is back in the pool — a new helper will be notified.`,
      urgency: request.urgency === "emergency" ? "high" : "normal",
      requestId: requestId,
    }, {
      fallbackEmail: requesterUser?.email,
      fallbackEmailSubject: "Your helper cancelled — look for a new helper",
    }).catch(err => logger.warn({ err }, "cancel: sendPushToUser to requester failed"));
  }

  // Email the other party
  const notifyId = isRequester ? (request.helper_id ?? null) : request.requester_id;
  if (notifyId) {
    const [notifyUser] = await db.select({ email: usersTable.email, name: usersTable.name })
      .from(usersTable).where(eq(usersTable.id, notifyId)).limit(1);
    const [actor] = await db.select({ name: usersTable.name })
      .from(usersTable).where(eq(usersTable.id, callerId)).limit(1);
    if (notifyUser?.email) {
      sendAlertEmail({
        to: notifyUser.email,
        subject: isRequester
          ? "A request you were helping has been withdrawn"
          : "A request is back in the pool",
        title: isRequester ? "Request withdrawn" : "Back to open 💙",
        body: isRequester
          ? `${actor?.name ?? "The requester"} has withdrawn their request "${request.title}". No further action is needed from you.`
          : `${actor?.name ?? "The helper"} is no longer available for "${request.title}". The request is now open for another helper to claim.`,
      }).catch(err => logger.warn({ err }, "cancel: sendAlertEmail failed"));
    }
  }

  return res.json(enriched);
});

// POST /requests/:id/rate
// Either participant (requester or helper) can rate the other after completion.
// Stars 1–5 are required; a short review text is optional.
// Recomputes the ratee's trust_score as a scaled average across all received ratings.
router.post("/requests/:id/rate", requireAuth, async (req, res) => {
  const callerId = req.authenticatedUserId!;
  const requestId = parseInt(String(req.params.id));
  if (isNaN(requestId)) return res.status(400).json({ error: "Invalid request id" });

  const { stars, review } = req.body as { stars?: number; review?: string };
  const starsNum = Number(stars);
  if (!starsNum || starsNum < 1 || starsNum > 5 || !Number.isInteger(starsNum)) {
    return res.status(400).json({ error: "stars must be an integer from 1 to 5" });
  }

  const [request] = await db.select()
    .from(requestsTable)
    .where(eq(requestsTable.id, requestId))
    .limit(1);

  if (!request) return res.status(404).json({ error: "Request not found" });
  if (request.status !== "completed") {
    return res.status(409).json({ error: "Can only rate completed requests" });
  }

  const isRequester = request.requester_id === callerId;
  const isHelper = request.helper_id === callerId;

  if (!isRequester && !isHelper) {
    return res.status(403).json({ error: "Only participants can rate this request" });
  }
  if (!request.helper_id) {
    return res.status(400).json({ error: "No helper to rate" });
  }

  const role = isRequester ? "requester" : "helper";
  const rateeId = isRequester ? request.helper_id : request.requester_id;

  // One rating per person per request
  const [existing] = await db.select({ id: ratingsTable.id })
    .from(ratingsTable)
    .where(and(eq(ratingsTable.request_id, requestId), eq(ratingsTable.rater_id, callerId)))
    .limit(1);
  if (existing) return res.status(409).json({ error: "You have already rated this request" });

  const [rating] = await db.insert(ratingsTable).values({
    request_id: requestId,
    rater_id: callerId,
    ratee_id: rateeId,
    stars: starsNum,
    review: typeof review === "string" && review.trim() ? review.trim() : null,
    role,
  }).returning();

  // Recompute trust_score for ratee: average-stars × 20 (1 star = 20, 5 stars = 100)
  const allRatings = await db.select({ stars: ratingsTable.stars })
    .from(ratingsTable)
    .where(eq(ratingsTable.ratee_id, rateeId));
  const avgStars = allRatings.reduce((s, r) => s + r.stars, 0) / allRatings.length;
  const newTrustScore = Math.round(avgStars * 20);

  await db.update(usersTable)
    .set({ trust_score: sql`GREATEST(${newTrustScore}, CASE WHEN ${usersTable.identity_verified} THEN 95 ELSE 0 END)` })
    .where(eq(usersTable.id, rateeId));

  logger.info({ request_id: requestId, rater_id: callerId, ratee_id: rateeId, stars: starsNum }, "rate: submitted");

  return res.status(201).json(rating);
});

export default router;
