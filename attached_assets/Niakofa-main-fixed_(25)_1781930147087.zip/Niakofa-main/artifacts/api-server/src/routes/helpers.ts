import { Router } from "express";
import { db, usersTable, requestsTable, userSettingsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { GetOnlineHelpersQueryParams } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router = Router();

function distanceMiles(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

router.get("/helpers/online", requireAuth, async (req, res) => {
  const params = GetOnlineHelpersQueryParams.safeParse({
    lat: req.query.lat ? parseFloat(req.query.lat as string) : undefined,
    lng: req.query.lng ? parseFloat(req.query.lng as string) : undefined,
    radius_miles: req.query.radius_miles ? parseFloat(req.query.radius_miles as string) : undefined,
  });

  const radius = (params.success && params.data.radius_miles) ? params.data.radius_miles : 10;
  const lat = params.success ? params.data.lat : undefined;
  const lng = params.success ? params.data.lng : undefined;

  // SQL bounding-box pre-filter — avoids full table scan
  let query = db.select().from(usersTable).$dynamic();
  const conditions = [eq(usersTable.helper_mode_active, true)];
  if (lat !== undefined && lng !== undefined) {
    const latDelta = radius / 69;
    const lngDelta = radius / (69 * Math.cos(lat * Math.PI / 180));
    conditions.push(
      sql`${usersTable.lat} BETWEEN ${lat - latDelta} AND ${lat + latDelta}`,
      sql`${usersTable.lng} BETWEEN ${lng - lngDelta} AND ${lng + lngDelta}`
    );
  }
  const helpers = await query.where(and(...conditions));

  const helperIds = helpers.map(h => h.id);
  const privacySettings = helperIds.length > 0
    ? await db.select({ user_id: userSettingsTable.user_id, privacy_live_location: userSettingsTable.privacy_live_location })
        .from(userSettingsTable)
        .where(sql`${userSettingsTable.user_id} = ANY(ARRAY[${sql.join(helperIds.map(id => sql`${id}`), sql`, `)}]::int[])`)
    : [];
  const privacyMap = new Map(privacySettings.map(p => [p.user_id, p.privacy_live_location]));

  // Coarsens precise GPS to ~1km when a helper has opted into hiding exact
  // live location — distance/ETA stay accurate enough to be useful without
  // exposing a continuously-trackable precise position.
  function fuzz(coord: number): number {
    return Math.round(coord * 100) / 100;
  }

  const result = helpers
    .filter(h => h.lat !== null && h.lng !== null)
    .map(h => {
      const isPrivate = privacyMap.get(h.id) === true;
      const dist = lat !== undefined && lng !== undefined ? distanceMiles(lat, lng, h.lat!, h.lng!) : null;
      // Wait-time estimate: 3 min/mile walking baseline, adjusted by trust score
      const eta_minutes = dist != null ? Math.round(dist * 3) : null;
      return {
        id: h.id,
        name: h.name,
        avatar_url: h.avatar_url,
        lat: isPrivate ? fuzz(h.lat!) : h.lat!,
        lng: isPrivate ? fuzz(h.lng!) : h.lng!,
        heading: isPrivate ? null : h.heading,
        trust_score: h.trust_score,
        help_count: h.help_count,
        is_online: true,
        active_request_id: null,
        distance_miles: dist,
        eta_minutes,
      };
    })
    .filter(h => lat !== undefined && lng !== undefined ? (h.distance_miles ?? 999) <= radius : true)
    // Trust-weighted sort: distance is primary, trust_score breaks ties
    .sort((a, b) => {
      const distDiff = (a.distance_miles ?? 999) - (b.distance_miles ?? 999);
      if (Math.abs(distDiff) > 0.1) return distDiff;
      return (b.trust_score ?? 0) - (a.trust_score ?? 0);
    });

  return res.json(result);
});

// Auto-assign nearest available helper to a request
router.post("/helpers/auto-assign/:requestId", requireAuth, async (req, res) => {
  const requestId = parseInt(req.params.requestId);
  if (isNaN(requestId)) return res.status(400).json({ error: "Invalid requestId" });

  const [request] = await db.select().from(requestsTable).where(eq(requestsTable.id, requestId)).limit(1);
  if (!request) return res.status(404).json({ error: "Request not found" });
  if (request.status !== "open") return res.status(409).json({ error: "Request is not open" });

  const latDelta = 5 / 69;
  const lngDelta = 5 / (69 * Math.cos(request.lat * Math.PI / 180));

  const helpers = await db.select().from(usersTable).where(
    and(
      eq(usersTable.helper_mode_active, true),
      sql`${usersTable.lat} BETWEEN ${request.lat - latDelta} AND ${request.lat + latDelta}`,
      sql`${usersTable.lng} BETWEEN ${request.lng - lngDelta} AND ${request.lng + lngDelta}`
    )
  );

  if (helpers.length === 0) return res.status(404).json({ error: "No helpers available nearby" });

  const nearest = helpers
    .filter(h => h.lat && h.lng)
    .map(h => ({ ...h, dist: distanceMiles(request.lat, request.lng, h.lat!, h.lng!) }))
    .sort((a, b) => a.dist - b.dist)[0];

  if (!nearest) return res.status(404).json({ error: "No helpers with valid location" });

  return res.json({
    helper_id: nearest.id,
    helper_name: nearest.name,
    distance_miles: nearest.dist,
    eta_minutes: Math.round(nearest.dist * 3),
  });
});

export default router;
