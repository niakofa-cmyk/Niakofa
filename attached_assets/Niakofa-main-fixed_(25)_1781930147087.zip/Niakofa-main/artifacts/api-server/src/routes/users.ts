import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, requestsTable, transactionsTable, scheduledPaymentsTable, userSettingsTable, paymentTransactionsTable, stripeAccountsTable, chatMessagesTable, ratingsTable, reportsTable, requestOffersTable, auditLogTable, pushSubscriptionsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import {
  GetUserParams,
  UpdateUserParams,
  UpdateUserBody,
  UpdateUserLocationParams,
  UpdateUserLocationBody,
  UpdateHelperModeParams,
  UpdateHelperModeBody,
  RegisterUserBody,
  MakePledgePaymentParams,
  MakePledgePaymentBody,
  CreateScheduledPaymentParams,
  CreateScheduledPaymentBody,
  GetScheduledPaymentsParams,
} from "@workspace/api-zod";
import { broadcast } from "../lib/ws-hub";
import { toSafeUser } from "../lib/safe-user";
import { authLimiter, gpsLimiter } from "../middlewares/rate-limit";
import { requireAuth, signTokenById } from "../middlewares/auth";
import { requireOwnership, requireAdmin } from "../middlewares/authz";
import { logger } from "../lib/logger";
import { toH3Cell } from "../lib/h3";
import { logAdminAction } from "../lib/audit-log";

const BCRYPT_ROUNDS = 12;

const router = Router();

router.get("/users/register", (_req, res) => {
  res.json({ message: "Use POST /api/users/register" });
});

router.post("/users/login", authLimiter, async (req, res) => {
  const { email, password } = req.body as { email?: string; password?: string };
  if (!email) return res.status(400).json({ error: "Email required" });
  if (!password) return res.status(400).json({ error: "Password required" });

  let user: typeof usersTable.$inferSelect | undefined;
  try {
    const rows = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email.trim().toLowerCase()))
      .limit(1);
    user = rows[0];
  } catch (err) {
    logger.error({ err }, "login: database error");
    return res.status(500).json({ error: "Database error — please try again" });
  }

  if (!user) return res.status(401).json({ error: "No account found with that email" });

  if (user.password_hash) {
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: "Incorrect password" });
  } else {
    // Legacy account (no password set) — do NOT issue a token.
    // The client must call POST /users/set-initial-password to create a
    // password before gaining access. There is no "skip" path.
    logger.warn({ user_id: user.id }, "login: legacy account must set password");
    return res.status(403).json({
      error_code: "LEGACY_PASSWORD_REQUIRED",
      error: "Please create a password to continue. Your account was created before passwords were required.",
      user_id: user.id,
      user_name: user.name,
      user_email: user.email,
    });
  }

  const token = signTokenById(user.id);
  const { password_hash: _ph, ...safeUser } = user as any;
  return res.json({ user: safeUser, token });
});

// POST /users/set-initial-password — unauthenticated, rate-limited one-time password setup.
// ONLY works for legacy accounts where password_hash is NULL (pre-password-era accounts).
// Verifies user_id + email match before allowing the change — proves account ownership.
// On success, returns a full auth token so the user lands directly in the app.
router.post("/users/set-initial-password", authLimiter, async (req, res) => {
  const { user_id, email, new_password } = req.body as {
    user_id?: number;
    email?: string;
    new_password?: string;
  };

  if (!user_id || !email || !new_password) {
    return res.status(400).json({ error: "user_id, email, and new_password are required" });
  }
  if (typeof new_password !== "string" || new_password.length < 8 || new_password.length > 128) {
    return res.status(400).json({ error: "Password must be 8-128 characters" });
  }

  let user: typeof usersTable.$inferSelect | undefined;
  try {
    const rows = await db.select().from(usersTable).where(eq(usersTable.id, Number(user_id))).limit(1);
    user = rows[0];
  } catch (err) {
    logger.error({ err }, "set-initial-password: database error");
    return res.status(500).json({ error: "Database error — please try again" });
  }

  if (!user) return res.status(404).json({ error: "User not found" });

  // Email must match to prove account ownership — no additional token needed
  if (user.email.toLowerCase() !== String(email).trim().toLowerCase()) {
    return res.status(403).json({ error: "Email does not match account" });
  }

  // This endpoint is only for legacy (no-password) accounts
  if (user.password_hash) {
    return res.status(409).json({
      error: "This account already has a password. Use the normal sign-in form.",
    });
  }

  const password_hash = await bcrypt.hash(new_password, BCRYPT_ROUNDS);
  const [updated] = await db
    .update(usersTable)
    .set({ password_hash, updated_at: new Date() })
    .where(eq(usersTable.id, user.id))
    .returning();

  if (!updated) return res.status(500).json({ error: "Failed to update password" });

  logger.info({ user_id: user.id }, "users: legacy account initial password set");
  const token = signTokenById(updated.id);
  const { password_hash: _ph, ...safeUser } = updated as any;
  return res.json({ user: safeUser, token });
});

router.post("/users/register", authLimiter, async (req, res) => {
  const parsed = RegisterUserBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.message });
  const { name, email, avatar_url, is_helper, neighborhood } = parsed.data;
  // Accept optional password from body (not part of OpenAPI spec to avoid codegen churn)
  const rawPassword = (req.body as Record<string, unknown>).password;
  const password_hash = rawPassword && typeof rawPassword === "string" && rawPassword.length >= 8 && rawPassword.length <= 128
    ? await bcrypt.hash(rawPassword, BCRYPT_ROUNDS)
    : null;

  try {
    const existing = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.email, email.trim().toLowerCase())).limit(1);
    if (existing.length > 0) return res.status(409).json({ error: "Email already registered" });

    const [user] = await db.insert(usersTable).values({
      name, email: email.trim().toLowerCase(),
      avatar_url: avatar_url ?? null,
      is_helper: is_helper ?? false,
      neighborhood: neighborhood ?? null,
      password_hash,
    }).returning();
    const token = signTokenById(user.id);
    const { password_hash: _ph, ...safeUser } = user;
    return res.status(201).json({ user: safeUser, token });
  } catch (err) {
    logger.error({ err }, "register: database error");
    return res.status(500).json({ error: "Registration failed — please try again" });
  }
});

// ── Public profile (any authenticated user can view; safe fields only) ─────
// Used by the "view helper profile" flow (/helper/:id). Never returns
// password_hash, email, phone, or other private fields.
router.get("/users/:id/public", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string, 10);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  const [user] = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      avatar_url: usersTable.avatar_url,
      neighborhood: usersTable.neighborhood,
      is_helper: usersTable.is_helper,
      helper_mode_active: usersTable.helper_mode_active,
      trust_score: usersTable.trust_score,
      help_count: usersTable.help_count,
      goodwill_score: usersTable.goodwill_score,
      identity_verified: usersTable.identity_verified,
      specialties: usersTable.specialties,
      created_at: usersTable.created_at,
    })
    .from(usersTable)
    .where(eq(usersTable.id, id))
    .limit(1);

  if (!user) return res.status(404).json({ error: "User not found" });
  return res.json(user);
});

router.get("/users/:id", requireAuth, requireOwnership(), async (req, res) => {
  const parsed = GetUserParams.safeParse({ id: parseInt(req.params.id as string) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, parsed.data.id)).limit(1);
  if (!user) return res.status(404).json({ error: "User not found" });
  const { password_hash: _ph, ...safeUser } = user;
  return res.json(safeUser);
});

router.patch("/users/:id", requireAuth, requireOwnership(), async (req, res) => {
  const pParsed = UpdateUserParams.safeParse({ id: parseInt(req.params.id as string) });
  const bParsed = UpdateUserBody.safeParse(req.body);
  if (!pParsed.success || !bParsed.success) return res.status(400).json({ error: "Invalid request" });
  const { name, avatar_url, neighborhood, is_helper } = bParsed.data;
  const updates: Partial<typeof usersTable.$inferInsert> = {};
  if (name !== undefined) updates.name = name;
  if (avatar_url !== undefined) updates.avatar_url = avatar_url;
  if (neighborhood !== undefined) updates.neighborhood = neighborhood;
  if (is_helper !== undefined) updates.is_helper = is_helper;
  const { specialties, phone_masked, quick_replies } = bParsed.data as any;
  if (specialties !== undefined) (updates as any).specialties = specialties;
  if (phone_masked !== undefined) (updates as any).phone_masked = phone_masked;
  if (quick_replies !== undefined) (updates as any).quick_replies = quick_replies;

  // ── Set-password flow for legacy accounts ─────────────────────────────────
  // The client sends `new_password` (plaintext) when a legacy user creates a
  // password for the first time. We hash it here — the plaintext never persists.
  const rawNewPassword = (req.body as Record<string, unknown>).new_password;
  if (rawNewPassword !== undefined) {
    if (typeof rawNewPassword !== "string" || rawNewPassword.length < 8 || rawNewPassword.length > 128) {
      return res.status(400).json({ error: "Password must be 8-128 characters" });
    }
    (updates as any).password_hash = await bcrypt.hash(rawNewPassword, BCRYPT_ROUNDS);
    logger.info({ user_id: pParsed.data.id }, "users: legacy account password set");
  }

  const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, pParsed.data.id)).returning();
  if (!user) return res.status(404).json({ error: "User not found" });
  // Never return the password hash to the client
  const { password_hash: _ph, ...safeUser } = user as any;
  return res.json(safeUser);
});

router.patch("/users/:id/location", requireAuth, requireOwnership(), gpsLimiter, async (req, res) => {
  const pParsed = UpdateUserLocationParams.safeParse({ id: parseInt(req.params.id as string) });
  const bParsed = UpdateUserLocationBody.safeParse(req.body);
  if (!pParsed.success || !bParsed.success) return res.status(400).json({ error: "Invalid request" });
  const { lat, lng, heading, speed } = bParsed.data;
  const [user] = await db.update(usersTable)
    .set({ lat, lng, heading: heading ?? null, speed: speed ?? null, h3_current_cell_id: toH3Cell(lat, lng) })
    .where(eq(usersTable.id, pParsed.data.id))
    .returning();
  if (!user) return res.status(404).json({ error: "User not found" });
  if (user.helper_mode_active) {
    broadcast({
      type: "helper_location",
      payload: { id: user.id, name: user.name, lat: user.lat, lng: user.lng, heading: user.heading },
    });
  }
  return res.json(toSafeUser(user));
});

router.patch("/users/:id/helper-mode", requireAuth, requireOwnership(), async (req, res) => {
  const pParsed = UpdateHelperModeParams.safeParse({ id: parseInt(req.params.id as string) });
  const bParsed = UpdateHelperModeBody.safeParse(req.body);
  if (!pParsed.success || !bParsed.success) return res.status(400).json({ error: "Invalid request" });
  const [user] = await db.update(usersTable)
    .set({ helper_mode_active: bParsed.data.active })
    .where(eq(usersTable.id, pParsed.data.id))
    .returning();
  if (!user) return res.status(404).json({ error: "User not found" });
  broadcast({
    type: bParsed.data.active ? "helper_online" : "helper_offline",
    payload: { id: user.id, name: user.name, lat: user.lat, lng: user.lng },
  });
  return res.json(toSafeUser(user));
});

router.post("/users/:id/pledge", requireAuth, requireOwnership(), async (req, res) => {
  const pParsed = MakePledgePaymentParams.safeParse({ id: parseInt(req.params.id as string) });
  const bParsed = MakePledgePaymentBody.safeParse(req.body);
  if (!pParsed.success || !bParsed.success) return res.status(400).json({ error: "Invalid request" });
  const { request_id, amount } = bParsed.data;
  const [request] = await db.select().from(requestsTable)
    .where(and(eq(requestsTable.id, request_id), eq(requestsTable.requester_id, pParsed.data.id)))
    .limit(1);
  if (!request) return res.status(404).json({ error: "Request not found or unauthorized" });
  const newPledgePaid = (request.pledge_paid || 0) + amount;
  const [updated] = await db.update(requestsTable)
    .set({ pledge_paid: newPledgePaid })
    .where(eq(requestsTable.id, request_id))
    .returning();

  if (request.helper_id && amount > 0) {
    await db.update(usersTable)
      .set({ benevolence_wallet: sql`${usersTable.benevolence_wallet} + ${amount}` })
      .where(eq(usersTable.id, request.helper_id));
    await db.insert(transactionsTable).values({
      user_id: request.helper_id,
      request_id: request_id,
      type: "pledge_received",
      amount: amount,
      description: request.title,
    });
  }
  await db.insert(transactionsTable).values({
    user_id: pParsed.data.id,
    request_id: request_id,
    type: "pledge_sent",
    amount: -amount,
    description: request.title,
  });

  await db.insert(paymentTransactionsTable).values({
    request_id: request_id,
    helper_id: request.helper_id ?? null,
    requester_id: pParsed.data.id,
    amount,
    state: "pending_contribution",
    payment_type: "pay_it_forward",
    notes: "Pay It Forward pledge",
  });

  broadcast({ type: "request_updated", payload: { ...updated, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null } });
  broadcast({ type: "pledge_paid", payload: { user_id: pParsed.data.id, request_id, amount, request_title: request.title } });
  return res.json({ ...updated, requester_name: null, requester_avatar: null, helper_name: null, distance_miles: null, estimated_duration_min: null });
});

// GET /users/:id/transactions — real activity history
router.get("/users/:id/transactions", requireAuth, requireOwnership(), async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const txns = await db.select().from(transactionsTable)
    .where(eq(transactionsTable.user_id, id))
    .orderBy(sql`${transactionsTable.created_at} DESC`)
    .limit(50);
  return res.json(txns);
});

// POST /users/:id/scheduled-payment — save a future repayment intent
router.post("/users/:id/scheduled-payment", requireAuth, requireOwnership(), async (req, res) => {
  const pParsed = CreateScheduledPaymentParams.safeParse({ id: parseInt(req.params.id as string) });
  const bParsed = CreateScheduledPaymentBody.safeParse(req.body);
  if (!pParsed.success || !bParsed.success) return res.status(400).json({ error: "Invalid request" });
  const { request_id, amount, scheduled_date, note } = bParsed.data;
  const userId = pParsed.data.id;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  if (!user) return res.status(404).json({ error: "User not found" });
  const [scheduled] = await db.insert(scheduledPaymentsTable).values({
    user_id: userId,
    request_id,
    amount,
    scheduled_date: new Date(scheduled_date),
    status: "pending",
    note: note ?? null,
  }).returning();
  broadcast({
    type: "pledge_scheduled",
    payload: { user_id: userId, request_id, amount, scheduled_date },
  });
  return res.status(201).json({ ...scheduled, scheduled_date: scheduled.scheduled_date.toISOString() });
});

// GET /users/:id/scheduled-payment — list future payment intents
router.get("/users/:id/scheduled-payment", requireAuth, requireOwnership(), async (req, res) => {
  const parsed = GetScheduledPaymentsParams.safeParse({ id: parseInt(req.params.id as string) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
  const rows = await db.select().from(scheduledPaymentsTable)
    .where(eq(scheduledPaymentsTable.user_id, parsed.data.id))
    .orderBy(scheduledPaymentsTable.scheduled_date);
  return res.json(rows.map(r => ({ ...r, scheduled_date: r.scheduled_date.toISOString() })));
});

// DELETE /users/:id/scheduled-payment/:paymentId — cancel a scheduled payment
router.delete("/users/:id/scheduled-payment/:paymentId", requireAuth, requireOwnership(), async (req, res) => {
  const userId = parseInt(req.params.id as string);
  const paymentId = parseInt(req.params.paymentId as string);
  if (isNaN(userId) || isNaN(paymentId)) return res.status(400).json({ error: "Invalid id" });
  const [deleted] = await db.delete(scheduledPaymentsTable)
    .where(and(
      eq(scheduledPaymentsTable.id, paymentId),
      eq(scheduledPaymentsTable.user_id, userId)
    ))
    .returning();
  if (!deleted) return res.status(404).json({ error: "Scheduled payment not found or does not belong to this user" });
  return res.json({ ok: true, deleted_id: paymentId });
});

// GET /users/:id/outstanding-pledges — requests with unpaid pledge balance
router.get("/users/:id/outstanding-pledges", requireAuth, requireOwnership(), async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const requests = await db.select().from(requestsTable)
    .where(
      and(
        eq(requestsTable.requester_id, id),
        eq(requestsTable.payment_type, "pay_it_forward"),
        eq(requestsTable.status, "completed"),
      )
    );
  const outstanding = requests.filter(r => (r.pledge_amount ?? 0) > (r.pledge_paid ?? 0));
  return res.json(outstanding.map(r => ({
    ...r,
    requester_name: null,
    requester_avatar: null,
    helper_name: null,
    distance_miles: null,
    estimated_duration_min: null,
  })));
});

// POST /users/:id/avatar — update profile photo (base64 data URL)
router.post("/users/:id/avatar", requireAuth, requireOwnership(), async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const { dataUrl } = req.body as { dataUrl?: string };
  if (!dataUrl || !dataUrl.startsWith("data:image/")) {
    return res.status(400).json({ error: "Invalid image data — must be a base64 data URL starting with data:image/" });
  }
  // SVG can carry embedded <script>/event-handler content. The prefix check
  // above only inspects the declared MIME string, which is trivially
  // spoofable — it proves nothing about the actual bytes that follow. Until
  // there's real magic-byte sniffing here, the safe move is to reject the
  // one image format that can execute script, rather than trust the label.
  if (/^data:image\/svg/i.test(dataUrl)) {
    return res.status(400).json({ error: "SVG avatars aren't supported — please use JPG, PNG, or WebP" });
  }
  if (dataUrl.length > 5 * 1024 * 1024) {
    return res.status(413).json({ error: "Image too large — max 5 MB" });
  }
  const [user] = await db
    .update(usersTable)
    .set({ avatar_url: dataUrl, updated_at: new Date() })
    .where(eq(usersTable.id, id))
    .returning();
  if (!user) return res.status(404).json({ error: "User not found" });
  return res.json(toSafeUser(user));
});

// GET /users/:id/settings — fetch user notification + privacy prefs (upserts defaults if first visit)
router.get("/users/:id/settings", requireAuth, requireOwnership(), async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const [existing] = await db.select().from(userSettingsTable).where(eq(userSettingsTable.user_id, id)).limit(1);
  if (existing) return res.json(existing);
  const [created] = await db.insert(userSettingsTable).values({ user_id: id }).returning();
  return res.status(201).json(created);
});

// PUT /users/:id/settings — persist notification + privacy prefs
router.put("/users/:id/settings", requireAuth, requireOwnership(), async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const allowed = [
    "notif_nearby_requests", "notif_emergency", "notif_task_accepted",
    "notif_wallet_updates", "notif_community_activity", "notif_pledge_reminders",
    "privacy_profile_visible", "privacy_live_location", "privacy_activity_sharing",
    "privacy_anonymous_giving", "service_radius_miles", "max_travel_miles", "specialties",
  ];
  const updates: Record<string, unknown> = { updated_at: new Date() };
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }
  const [existing] = await db.select().from(userSettingsTable).where(eq(userSettingsTable.user_id, id)).limit(1);
  if (existing) {
    const [updated] = await db.update(userSettingsTable).set(updates).where(eq(userSettingsTable.user_id, id)).returning();
    return res.json(updated);
  } else {
    const [created] = await db.insert(userSettingsTable).values({ user_id: id, ...updates }).returning();
    return res.json(created);
  }
});

// PATCH /users/:id/panic-contacts — update emergency contacts
router.patch("/users/:id/panic-contacts", requireAuth, requireOwnership(), async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const { contacts } = req.body as { contacts?: string[] };
  if (!Array.isArray(contacts)) return res.status(400).json({ error: "contacts must be an array" });
  if (contacts.length > 5) return res.status(400).json({ error: "Max 5 panic contacts" });
  const E164 = /^\+[1-9]\d{1,14}$/;
  const invalid = contacts.filter(c => !E164.test(c));
  if (invalid.length > 0) {
    return res.status(400).json({ error: "Invalid phone number format (use E.164, e.g. +14155551234)", invalid });
  }
  const [user] = await db.update(usersTable)
    .set({ panic_contacts: contacts })
    .where(eq(usersTable.id, id))
    .returning();
  return res.json(toSafeUser(user));
});

// DELETE /users/:id — permanently delete a user and all their data
router.delete("/users/:id", requireAuth, requireOwnership(), async (req, res) => {
  const userId = parseInt(req.params.id as string);
  if (isNaN(userId)) return res.status(400).json({ error: "Invalid id" });

  try {
    await db.delete(chatMessagesTable).where(eq(chatMessagesTable.sender_id, userId));
    await db.delete(ratingsTable).where(sql`${ratingsTable.rater_id} = ${userId} OR ${ratingsTable.ratee_id} = ${userId}`);
    await db.delete(reportsTable).where(sql`${reportsTable.reporter_id} = ${userId} OR ${reportsTable.reported_user_id} = ${userId}`);
    await db.delete(requestOffersTable).where(eq(requestOffersTable.helper_id, userId));
    await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.user_id, userId));
    await db.delete(transactionsTable).where(eq(transactionsTable.user_id, userId));
    // auditLogTable intentionally NOT cascaded — admin_user_id records which
    // admin took a moderation action; deleting it on account deletion would
    // destroy legitimate audit history rather than just removing this
    // user's own data.
    await db.delete(scheduledPaymentsTable).where(eq(scheduledPaymentsTable.user_id, userId));
    await db.delete(stripeAccountsTable).where(eq(stripeAccountsTable.user_id, userId));
    await db.delete(userSettingsTable).where(eq(userSettingsTable.user_id, userId));
    await db.delete(usersTable).where(eq(usersTable.id, userId));

    return res.json({ ok: true, message: "Account deleted successfully" });
  } catch (error) {
    logger.error({ err: error, user_id: userId }, "users: account deletion failed");
    return res.status(500).json({ error: "Failed to delete account" });
  }
});

// PATCH /users/:id/moderation — admin moderation actions
router.patch("/users/:id/moderation", requireAuth, requireAdmin(), async (req, res) => {
  const userId = parseInt(req.params.id as string);
  if (isNaN(userId)) return res.status(400).json({ error: "Invalid id" });
  const { action } = req.body as { action: "warn" | "ban" };
  if (!["warn", "ban"].includes(action)) return res.status(400).json({ error: "Invalid action" });

  if (action === "ban") {
    await db.update(usersTable)
      .set({ trust_score: -1, helper_mode_active: false })
      .where(eq(usersTable.id, userId));
  } else {
    await db.update(usersTable)
      .set({ trust_score: sql`GREATEST(0, ${usersTable.trust_score} - 10)` })
      .where(eq(usersTable.id, userId));
  }
  logAdminAction({
    adminUserId: req.authenticatedUserId!,
    action: "user_moderation",
    targetType: "user",
    targetId: userId,
    details: { moderation_action: action },
  });
  return res.json({ ok: true, action, user_id: userId });
});

// GET all users (admin)
router.get("/users", requireAuth, requireAdmin(), async (_req, res) => {
  const users = await db.select({
    id: usersTable.id,
    name: usersTable.name,
    email: usersTable.email,
    is_helper: usersTable.is_helper,
    trust_score: usersTable.trust_score,
    help_count: usersTable.help_count,
    created_at: usersTable.created_at,
  }).from(usersTable).limit(200);
  return res.json(users);
});

export default router;
