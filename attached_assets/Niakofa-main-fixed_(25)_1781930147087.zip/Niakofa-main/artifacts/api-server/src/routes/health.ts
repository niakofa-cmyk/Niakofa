import { Router, type IRouter } from "express";
import { BUILD_TIME } from "../build-stamp";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  res.json({ status: "ok", version: String(BUILD_TIME), built: BUILD_TIME });
});

router.get("/version", (_req, res) => {
  res.json({ version: String(BUILD_TIME), built: BUILD_TIME });
});

export default router;
