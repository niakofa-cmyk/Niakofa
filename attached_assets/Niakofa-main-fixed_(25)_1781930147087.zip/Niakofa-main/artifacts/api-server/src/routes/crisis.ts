import { Router } from "express";
import { requireAuth } from "../middlewares/auth";
import { requireAdmin } from "../middlewares/authz";
import { db, systemStateTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { broadcast } from "../lib/ws-hub";
import { logger } from "../lib/logger";
import { logAdminAction } from "../lib/audit-log";
import { REGION_COUNTY, REGION_EMERGENCY_CONTACTS } from "../lib/region-config";

const router = Router();

const CRISIS_KEY = "crisis";

export interface CrisisState {
  active: boolean;
  message: string;
  level: "info" | "warning" | "critical";
  activatedAt?: string;
  resources?: Array<{ label: string; phone?: string; url?: string }>;
}

const DEFAULT_STATE: CrisisState = {
  active: false,
  message: "",
  level: "warning",
  resources: [],
};

const VALID_LEVELS = new Set(["info", "warning", "critical"]);

async function readCrisisState(): Promise<CrisisState> {
  const [row] = await db
    .select()
    .from(systemStateTable)
    .where(eq(systemStateTable.key, CRISIS_KEY))
    .limit(1);
  return (row?.value as CrisisState | undefined) ?? DEFAULT_STATE;
}

async function writeCrisisState(state: CrisisState): Promise<void> {
  await db
    .insert(systemStateTable)
    .values({ key: CRISIS_KEY, value: state })
    .onConflictDoUpdate({
      target: systemStateTable.key,
      set: { value: state, updated_at: new Date() },
    });
}

router.get("/crisis/status", async (_req, res) => {
  try {
    const state = await readCrisisState();
    res.json(state);
  } catch (err) {
    logger.error({ err }, "crisis: failed to read state — defaulting to inactive");
    res.json(DEFAULT_STATE);
  }
});

router.post("/crisis/activate", requireAuth, requireAdmin(), async (req, res) => {
  const { message, level, resources: rawResources } = req.body as {
    message?: string;
    level?: string;
    resources?: unknown;
  };

  let resources: CrisisState["resources"] | undefined;
  if (rawResources !== undefined) {
    if (!Array.isArray(rawResources) || rawResources.length > 10) {
      return res.status(400).json({ error: "resources must be an array of at most 10 items" });
    }
    const isValid = rawResources.every(
      (r) =>
        r && typeof r === "object" &&
        typeof (r as Record<string, unknown>).label === "string" &&
        (r as Record<string, unknown>).label !== "" &&
        ((r as Record<string, unknown>).phone === undefined || typeof (r as Record<string, unknown>).phone === "string") &&
        ((r as Record<string, unknown>).url === undefined || typeof (r as Record<string, unknown>).url === "string")
    );
    if (!isValid) {
      return res.status(400).json({ error: "Each resource needs a non-empty string label, and optional string phone/url" });
    }
    resources = rawResources as CrisisState["resources"];
  }

  const safeLevel: CrisisState["level"] = VALID_LEVELS.has(level ?? "")
    ? (level as CrisisState["level"])
    : "warning";

  const crisisState: CrisisState = {
    active: true,
    message: message ?? `⚠️ Emergency situation active in ${REGION_COUNTY}. Check nearby requests and stay safe.`,
    level: safeLevel,
    activatedAt: new Date().toISOString(),
    resources: resources ?? REGION_EMERGENCY_CONTACTS,
  };

  await writeCrisisState(crisisState);
  broadcast({ type: "crisis_update", payload: crisisState });
  logger.warn({ crisisState, admin_user_id: req.authenticatedUserId }, "crisis: mode activated");
  logAdminAction({
    adminUserId: req.authenticatedUserId!,
    action: "crisis_activate",
    details: { ...crisisState },
  });
  res.json(crisisState);
});

router.post("/crisis/deactivate", requireAuth, requireAdmin(), async (req, res) => {
  await writeCrisisState(DEFAULT_STATE);
  broadcast({ type: "crisis_update", payload: DEFAULT_STATE });
  logger.info({ admin_user_id: req.authenticatedUserId }, "crisis: mode deactivated");
  logAdminAction({ adminUserId: req.authenticatedUserId!, action: "crisis_deactivate" });
  res.json(DEFAULT_STATE);
});

export default router;
