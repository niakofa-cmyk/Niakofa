/**
 * H3 Zone Activation Worker
 *
 * Runs every 15 minutes. For every H3 cell with recent request or helper
 * activity, recalculates density and decides whether the cell should be an
 * "active zone" (eligible for zone-based dispatch) or fall back to
 * radius-based dispatch.
 *
 * === The threshold-flapping fix ===
 * The hybrid dispatch proposal explicitly calls out a failure mode: a cell
 * hovering right at a single activation threshold would flip active/inactive
 * every single worker cycle, which is a confusing, inconsistent experience
 * for helpers ("am I in a zone or not?"). This worker prevents that with two
 * independent protections, applied together:
 *
 *   1. HYSTERESIS — activation and deactivation use DIFFERENT thresholds,
 *      with deactivation meaningfully lower than activation. A cell with
 *      request_count=4 won't activate (needs ≥5) but also won't deactivate
 *      if already active (only deactivates below 2). There's a dead zone
 *      between 2 and 5 where the cell simply stays in whatever state it was
 *      already in — this is what actually stops single-threshold flapping.
 *
 *   2. MINIMUM DWELL TIME — even if hysteresis is crossed, a cell can't flip
 *      state again until MIN_DWELL_MS has passed since its last flip. This
 *      protects against a burst of demand causing a flip, followed by a
 *      quiet 15 minutes immediately flipping it back.
 *
 * zone_status (busy/moderate/slow) is NOT subject to either protection —
 * it's a pure informational label and is safe to update every cycle.
 */
import { db, requestsTable, usersTable, h3CellsTable } from "@workspace/db";
import { eq, and, gte, isNotNull, sql } from "drizzle-orm";
import { h3CellCentroid } from "../lib/h3";
import { logger } from "../lib/logger";

const POLL_INTERVAL_MS = 15 * 60 * 1000; // 15 minutes
const MIN_DWELL_MS = 2 * 60 * 60 * 1000; // 2 hours minimum before a zone can flip state again

// Deliberately a real gap between these two, not the same number — this IS
// the hysteresis. Tune both together; never make them equal.
const ACTIVATE_REQUEST_THRESHOLD = 5;   // open/created requests in trailing 24h
const ACTIVATE_HELPER_THRESHOLD = 5;    // helpers currently online in this cell
const DEACTIVATE_REQUEST_THRESHOLD = 2; // below this, zone is eligible to deactivate
const DEACTIVATE_HELPER_THRESHOLD = 2;

function computeZoneStatus(requestCount: number, helperCount: number): string {
  const ratio = requestCount / Math.max(helperCount, 1);
  if (ratio >= 3) return "busy";
  if (ratio >= 1) return "moderate";
  return "slow";
}

async function recalculateZones(): Promise<void> {
  const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

  let requestCounts: { h3_cell_id: string | null; count: number }[] = [];
  let helperCounts: { h3_current_cell_id: string | null; count: number }[] = [];
  let existingCells: (typeof h3CellsTable.$inferSelect)[] = [];

  try {
    requestCounts = await db
      .select({ h3_cell_id: requestsTable.h3_cell_id, count: sql<number>`COUNT(*)::int` })
      .from(requestsTable)
      .where(and(isNotNull(requestsTable.h3_cell_id), gte(requestsTable.created_at, since24h)))
      .groupBy(requestsTable.h3_cell_id);

    helperCounts = await db
      .select({ h3_current_cell_id: usersTable.h3_current_cell_id, count: sql<number>`COUNT(*)::int` })
      .from(usersTable)
      .where(and(isNotNull(usersTable.h3_current_cell_id), eq(usersTable.helper_mode_active, true)))
      .groupBy(usersTable.h3_current_cell_id);

    // Existing cells must also be reprocessed even with zero current
    // activity — an active zone that's gone quiet needs to be able to decay
    // back to inactive, not stay active forever because nothing prompted a
    // recheck.
    existingCells = await db.select().from(h3CellsTable);
  } catch (err) {
    logger.error({ err }, "zone-activation-worker: failed to query density data");
    return;
  }

  const requestMap = new Map(requestCounts.map(r => [r.h3_cell_id!, r.count]));
  const helperMap = new Map(helperCounts.map(h => [h.h3_current_cell_id!, h.count]));
  const existingMap = new Map(existingCells.map(c => [c.h3_id, c]));

  const allCellIds = new Set<string>([
    ...requestMap.keys(),
    ...helperMap.keys(),
    ...existingMap.keys(),
  ]);

  if (allCellIds.size === 0) return;

  const now = new Date();
  let activated = 0;
  let deactivated = 0;

  for (const h3Id of allCellIds) {
    const requestCount = requestMap.get(h3Id) ?? 0;
    const helperCount = helperMap.get(h3Id) ?? 0;
    const existing = existingMap.get(h3Id);
    const zoneStatus = computeZoneStatus(requestCount, helperCount);

    const wasActive = existing?.is_active_zone ?? false;
    const lastChange = existing?.last_state_change_at ?? now;
    const dwellSatisfied = now.getTime() - lastChange.getTime() >= MIN_DWELL_MS;

    let isActive = wasActive;
    if (!wasActive && dwellSatisfied &&
        requestCount >= ACTIVATE_REQUEST_THRESHOLD && helperCount >= ACTIVATE_HELPER_THRESHOLD) {
      isActive = true;
      activated++;
    } else if (wasActive && dwellSatisfied &&
        (requestCount < DEACTIVATE_REQUEST_THRESHOLD || helperCount < DEACTIVATE_HELPER_THRESHOLD)) {
      isActive = false;
      deactivated++;
    }
    // Otherwise: either thresholds weren't crossed, or dwell time blocks the
    // flip — isActive stays exactly as it was. This is the hysteresis +
    // dwell protection in action.

    const stateChanged = isActive !== wasActive;
    const centroid = existing
      ? { lat: existing.centroid_lat, lng: existing.centroid_lng }
      : h3CellCentroid(h3Id);

    await db.insert(h3CellsTable).values({
      h3_id: h3Id,
      centroid_lat: centroid.lat,
      centroid_lng: centroid.lng,
      is_active_zone: isActive,
      zone_status: zoneStatus,
      request_count_24h: requestCount,
      helper_count_now: helperCount,
      last_calculated_at: now,
      last_state_change_at: stateChanged ? now : (existing?.last_state_change_at ?? now),
    }).onConflictDoUpdate({
      target: h3CellsTable.h3_id,
      set: {
        is_active_zone: isActive,
        zone_status: zoneStatus,
        request_count_24h: requestCount,
        helper_count_now: helperCount,
        last_calculated_at: now,
        ...(stateChanged ? { last_state_change_at: now } : {}),
      },
    });
  }

  if (activated > 0 || deactivated > 0) {
    logger.info({ activated, deactivated, cellsProcessed: allCellIds.size }, "zone-activation-worker: zone state changes");
  }
}


export function startZoneActivationWorker(): () => void {
  recalculateZones().catch(err => logger.error({ err }, "zone-activation-worker: initial run failed"));
  const interval = setInterval(() => {
    recalculateZones().catch(err => logger.error({ err }, "zone-activation-worker: run failed"));
  }, POLL_INTERVAL_MS);

  logger.info({ intervalMs: POLL_INTERVAL_MS, minDwellMs: MIN_DWELL_MS }, "zone-activation-worker: started");

  return () => {
    clearInterval(interval);
    logger.info("zone-activation-worker: stopped");
  };
}
