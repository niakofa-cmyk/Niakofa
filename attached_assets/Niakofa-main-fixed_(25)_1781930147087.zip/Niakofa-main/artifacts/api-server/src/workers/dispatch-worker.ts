/**
 * Dispatch Offer Expiry Worker
 *
 * Polls every 5 seconds for offers whose expires_at has passed and is still
 * "pending". Marks them expired, tells the helper's UI to clear it, and
 * cascades to the next candidate for that request (if it's still open).
 *
 * Deliberately a short-interval DB poll rather than a BullMQ delayed job —
 * offer timeouts are only ~15s, and this needs to work identically whether
 * or not REDIS_URL is configured (same reasoning as scheduler.ts).
 */
import { db, requestOffersTable } from "@workspace/db";
import { eq, and, lte } from "drizzle-orm";
import { sendToUser } from "../lib/ws-hub";
import { dispatchNext } from "../lib/dispatch";
import { logger } from "../lib/logger";

const POLL_INTERVAL_MS = 5_000;

async function processExpiredOffers(): Promise<void> {
  const cutoff = new Date();
  let expired: (typeof requestOffersTable.$inferSelect)[] = [];
  try {
    expired = await db
      .select()
      .from(requestOffersTable)
      .where(and(
        eq(requestOffersTable.status, "pending"),
        lte(requestOffersTable.expires_at, cutoff),
      ));
  } catch (err) {
    logger.error({ err }, "dispatch-worker: failed to query expired offers");
    return;
  }

  if (expired.length === 0) return;

  await db.update(requestOffersTable)
    .set({ status: "expired", responded_at: new Date() })
    .where(and(eq(requestOffersTable.status, "pending"), lte(requestOffersTable.expires_at, cutoff)));

  logger.info({ count: expired.length }, "dispatch-worker: offers expired");

  const affectedRequestIds = new Set<number>();
  for (const offer of expired) {
    sendToUser(offer.helper_id, {
      type: "dispatch_offer_resolved",
      payload: { offerId: offer.id, requestId: offer.request_id, reason: "expired" },
    });
    affectedRequestIds.add(offer.request_id);
  }

  // Cascade to the next candidate for each affected request, one at a time.
  for (const requestId of affectedRequestIds) {
    await dispatchNext(requestId).catch(err => logger.warn({ err, request_id: requestId }, "dispatch: non-fatal failure"));
  }
}

export function startDispatchWorker(): () => void {
  processExpiredOffers().catch(() => {});
  const interval = setInterval(() => {
    processExpiredOffers().catch(() => {});
  }, POLL_INTERVAL_MS);

  logger.info({ intervalMs: POLL_INTERVAL_MS }, "dispatch-worker: started");

  return () => {
    clearInterval(interval);
    logger.info("dispatch-worker: stopped");
  };
}
