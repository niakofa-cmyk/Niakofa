/**
 * Niakofa Rate Limiting Middleware
 *
 * Philosophy from the product doc: protect good people, never punish them.
 * All error messages are SOFT — informative, not hostile.
 * Limits escalate from gentle warnings to hard stops only when necessary.
 *
 * Trust model (future): high-trust/verified users get higher limits.
 * Today: IP-based and userId-based limits that are generous but enforceable.
 *
 * STORE: When REDIS_URL is configured, every limiter below shares counters
 * through Redis instead of process memory. This matters the moment there's
 * more than one server instance (Railway autoscale, multi-region, etc.) —
 * with the default in-memory store, each instance has its own counters, so
 * a "10 requests / 15 min" limit silently becomes "10 × N instances" and
 * resets completely on every redeploy. Falls back to in-memory automatically
 * when Redis isn't configured (e.g. local dev), same graceful-degradation
 * pattern already used for BullMQ in lib/queue.ts.
 */
import { rateLimit, type Store } from "express-rate-limit";
import { RedisStore } from "rate-limit-redis";
import { getRedisConnection } from "../lib/queue";
import { logger } from "../lib/logger";

let _loggedStoreChoice = false;

function sharedStore(prefix: string): Store | undefined {
  const redis = getRedisConnection();
  if (!redis) {
    if (!_loggedStoreChoice) {
      logger.warn("rate-limit: REDIS_URL not set — using in-memory store (per-instance, resets on restart)");
      _loggedStoreChoice = true;
    }
    return undefined; // express-rate-limit defaults to its built-in MemoryStore
  }
  if (!_loggedStoreChoice) {
    logger.info("rate-limit: using shared Redis store across all limiters");
    _loggedStoreChoice = true;
  }
  return new RedisStore({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    sendCommand: (...args: string[]) => {
      const [command, ...rest] = args;
      return redis.call(command, ...rest) as any;
    },
    prefix: `rl:${prefix}:`,
  });
}

// ── 1. Auth Routes (10 / 15 min) ─────────────────────────────────────────────
// Protects: login, signup, password reset against brute-force / credential stuffing.
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  store: sharedStore("auth"),
  message: {
    error:
      "Too many sign-in attempts from this device. Please wait 15 minutes and try again. " +
      "If you're having trouble, contact support@niakofa.com.",
  },
});

// ── 2. Request Creation (10 / hour per requester) ────────────────────────────
// Protects against spam help requests, troll floods, fake emergencies.
// Keyed by requester_id from body (not IP) — prevents VPN bypass while
// allowing multiple users behind a shared NAT.
export const requestCreationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  store: sharedStore("req-create"),
  keyGenerator: (req) => {
    // Key on the authenticated userId set by parseAuth (runs before all routes).
    // Never key on req.body.requester_id — unauthenticated body data can be spoofed
    // to rotate around the limit.
    const userId = req.authenticatedUserId;
    return userId ? `req-create-${userId}` : `req-create-ip-${req.ip ?? "unknown"}`;
  },
  message: {
    error:
      "You've created several requests recently. " +
      "Please wait a few minutes before creating another — this keeps the map clear for people who need help most.",
  },
});

// ── 3. GPS Location Updates (1 / 3 seconds per user) ─────────────────────────
// Prevents battery drain, server overload, and GPS stream abuse.
// Keyed by userId from URL params so one user can't block another.
export const gpsLimiter = rateLimit({
  windowMs: 3_000,
  limit: 1,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  store: sharedStore("gps"),
  keyGenerator: (req) =>
    `gps-${req.authenticatedUserId ?? req.ip ?? "unknown"}`,
  message: {
    error:
      "Location updates are throttled to protect the network. " +
      "Your app will automatically retry — no action needed.",
  },
});

// ── 4. Payment Endpoints (20 / 15 min) ───────────────────────────────────────
// Protects: payout triggers, payment-intent creation, wallet operations
// against replay attacks and spam triggers.
export const paymentLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  store: sharedStore("payment"),
  message: {
    error:
      "Too many payment requests in a short period. " +
      "Please wait a few minutes before trying again.",
  },
});

// ── 5. General API (200 / 15 min) ────────────────────────────────────────────
// Broad protection on all /api routes. High enough that normal users never hit it.
// Blocks only clearly automated abuse (scrapers, bots, DoS).
export const generalApiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 200,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  store: sharedStore("general"),
  message: {
    error:
      "Too many requests from this address. " +
      "Please slow down and try again in a few minutes.",
  },
});

// ── 6. Chat Messages (30 / min per user) ─────────────────────────────────────
// Key on the authenticated userId (set by parseAuth before this runs).
// Falls back to IP only when there is no verified token (should not happen
// on POST chat since requireAuth runs first, but defensive).
export const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  store: sharedStore("chat"),
  keyGenerator: (req) => {
    const r = req as typeof req & { authenticatedUserId?: number };
    return `chat-${r.authenticatedUserId ?? req.ip ?? "unknown"}`;
  },
  message: { error: "You're sending messages too fast. Slow down a little." },
});
