/**
 * Niakofa Dispatch — exclusive offer model
 *
 * Layered on top of (not replacing) the existing public claim flow:
 *  - A request stays visible and claimable on the public map the whole time.
 *  - In parallel, dispatch sends an exclusive, short-lived offer to the best
 *    untried candidate. If they accept, they win the same atomic claim the
 *    public "claim" button uses. If they decline or the offer times out,
 *    dispatch immediately tries the next-best candidate.
 *  - If dispatch runs out of candidates (or no one is online nearby), the
 *    request simply stays "open" — exactly today's behavior — so dispatch
 *    can never make a request harder to fulfil than it already was.
 */
import { db, requestsTable, usersTable, requestOffersTable, userSettingsTable, h3CellsTable } from "@workspace/db";
import { eq, and, inArray, sql } from "drizzle-orm";
import { sendToUser } from "./ws-hub";
import { sendPushToUser } from "../routes/push";
import { logger } from "./logger";
import { h3CellAndNeighbors } from "./h3";

export const OFFER_TIMEOUT_MS = 15_000; // 15 seconds to accept/decline

// Expanding search tiers, in miles. Starts local (the actual product intent
// — a nearby neighbor), and only widens when nobody closer is available,
// rather than searching the full radius every time. Capped at 100 miles —
// past that, "nearby help" stops being a meaningful concept for most request
// types (groceries, errands), and a request is better served by staying
// open on the public map than by offering it to someone three states away.
const SEARCH_RADIUS_TIERS_MILES = [15, 30, 60, 100];

function distanceMiles(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Marks all still-pending offers for a request as superseded (someone else
 * claimed it, it got cancelled, etc.) and tells each affected helper's UI to
 * clear the offer so they're not left staring at a dead countdown.
 */
export async function supersedePendingOffers(requestId: number, exceptOfferId?: number): Promise<void> {
  const conditions = [eq(requestOffersTable.request_id, requestId), eq(requestOffersTable.status, "pending")];
  const pending = await db.select().from(requestOffersTable).where(and(...conditions));
  const toSupersede = pending.filter(o => o.id !== exceptOfferId);
  if (toSupersede.length === 0) return;

  await db.update(requestOffersTable)
    .set({ status: "superseded", responded_at: new Date() })
    .where(inArray(requestOffersTable.id, toSupersede.map(o => o.id)));

  for (const offer of toSupersede) {
    sendToUser(offer.helper_id, { type: "dispatch_offer_resolved", payload: { offerId: offer.id, requestId, reason: "superseded" } });
  }
}

/**
 * Zone-based candidate search — the "structured" half of the hybrid model.
 * Only runs when the request's H3 cell is currently an active zone (set by
 * zone-activation-worker.ts with hysteresis). Searches the cell itself plus
 * its immediate ring of neighbors, so a helper just across a hex boundary
 * isn't ignored — the specific "boundary problem" the hybrid proposal flags
 * with naive single-cell matching.
 *
 * Returns null (not an error) whenever zone dispatch isn't applicable or
 * finds nobody — the caller always falls through to the radius-based search
 * in that case. This null-means-fall-through behavior IS the failover
 * mechanism described in the proposal: there's no separate timer or retry
 * loop needed, because every dispatchNext() call (initial + every cascade
 * on decline/expiry) re-runs this check fresh.
 */
async function findZoneCandidate(
  request: typeof requestsTable.$inferSelect,
  excludeIds: Set<number>
): Promise<{ helperId: number; distanceMiles: number } | null> {
  if (!request.h3_cell_id) return null;

  const [cell] = await db.select().from(h3CellsTable).where(eq(h3CellsTable.h3_id, request.h3_cell_id)).limit(1);
  if (!cell?.is_active_zone) return null;

  const searchCells = h3CellAndNeighbors(request.h3_cell_id);

  const candidates = await db
    .select({ user: usersTable, dispatch_opt_in: userSettingsTable.dispatch_opt_in })
    .from(usersTable)
    .leftJoin(userSettingsTable, eq(userSettingsTable.user_id, usersTable.id))
    .where(and(
      eq(usersTable.helper_mode_active, true),
      inArray(usersTable.h3_current_cell_id, searchCells),
    ));

  const ranked = candidates
    .filter(c => c.dispatch_opt_in !== false)
    .map(c => c.user)
    .filter(c => c.lat !== null && c.lng !== null && !excludeIds.has(c.id))
    .map(c => ({ ...c, dist: distanceMiles(request.lat, request.lng, c.lat!, c.lng!) }))
    // Within a zone, rank by trust first (this is the "structured" part —
    // zone dispatch is about positioning good helpers where demand is, not
    // just nearest-wins), distance as the tiebreaker.
    .sort((a, b) => {
      const trustDiff = (b.trust_score ?? 0) - (a.trust_score ?? 0);
      if (Math.abs(trustDiff) > 0.01) return trustDiff;
      return a.dist - b.dist;
    });

  if (!ranked[0]) return null;
  return { helperId: ranked[0].id, distanceMiles: ranked[0].dist };
}

/**
 * Picks the best candidate who hasn't already been offered this request
 * (in any status — don't re-offer someone who already declined/timed out),
 * is in helper mode, and has dispatch opted in. Tries each radius tier in
 * order and stops at the first tier with any eligible candidate — so a
 * request only reaches a 60-mile-away helper if literally nobody within 15
 * or 30 miles is available, never as a first choice.
 */
async function findNextCandidate(
  request: typeof requestsTable.$inferSelect,
  excludeIds: Set<number>
): Promise<{ helperId: number; radiusMiles: number } | null> {
  for (const radiusMiles of SEARCH_RADIUS_TIERS_MILES) {
    const latDelta = radiusMiles / 69;
    const lngDelta = radiusMiles / (69 * Math.cos((request.lat * Math.PI) / 180));

    const candidates = await db
      .select({ user: usersTable, dispatch_opt_in: userSettingsTable.dispatch_opt_in })
      .from(usersTable)
      .leftJoin(userSettingsTable, eq(userSettingsTable.user_id, usersTable.id))
      .where(and(
        eq(usersTable.helper_mode_active, true),
        sql`${usersTable.lat} BETWEEN ${request.lat - latDelta} AND ${request.lat + latDelta}`,
        sql`${usersTable.lng} BETWEEN ${request.lng - lngDelta} AND ${request.lng + lngDelta}`,
      ));

    const ranked = candidates
      // No settings row yet (never visited Settings) defaults to opted-in,
      // matching the column's own DB default — only an explicit `false`
      // excludes someone from dispatch.
      .filter(c => c.dispatch_opt_in !== false)
      .map(c => c.user)
      .filter(c => c.lat !== null && c.lng !== null && !excludeIds.has(c.id))
      .map(c => ({ ...c, dist: distanceMiles(request.lat, request.lng, c.lat!, c.lng!) }))
      .filter(c => c.dist <= radiusMiles)
      .sort((a, b) => {
        const distDiff = a.dist - b.dist;
        if (Math.abs(distDiff) > 0.1) return distDiff;
        return (b.trust_score ?? 0) - (a.trust_score ?? 0);
      });

    if (ranked[0]) return { helperId: ranked[0].id, radiusMiles };
  }

  return null;
}

/**
 * Attempts to send the next exclusive offer for a request. Safe to call
 * repeatedly (on creation, on decline, on expiry) — it always re-checks the
 * request is still actually open before doing anything, so a request that
 * got claimed or cancelled in the meantime is simply left alone.
 */
export async function dispatchNext(requestId: number): Promise<void> {
  try {
    const [request] = await db.select().from(requestsTable).where(eq(requestsTable.id, requestId)).limit(1);
    if (!request || request.status !== "open") return;

    const alreadyOffered = await db
      .select({ helper_id: requestOffersTable.helper_id })
      .from(requestOffersTable)
      .where(eq(requestOffersTable.request_id, request.id));
    const excludeIds = new Set(alreadyOffered.map(o => o.helper_id));
    excludeIds.add(request.requester_id);

    // Hybrid dispatch: try the structured zone path first (only "live" when
    // the request's H3 cell is an active zone), and only fall through to
    // the radius-based search if zone dispatch isn't applicable or finds
    // nobody. This fall-through IS the proposal's failover mechanism — no
    // separate timer needed, since dispatchNext re-runs this check on every
    // decline/expiry cascade anyway.
    const zoneCandidate = await findZoneCandidate(request, excludeIds);
    const strategyUsed: "zone_based" | "radius_based" = zoneCandidate ? "zone_based" : "radius_based";
    const candidate = zoneCandidate
      ? { helperId: zoneCandidate.helperId, radiusMiles: Math.round(zoneCandidate.distanceMiles) }
      : await findNextCandidate(request, excludeIds);

    if (!candidate) {
      logger.info({ request_id: requestId }, "dispatch: no candidates in-zone or within 100mi — request stays open for public claim");
      return;
    }
    const { helperId: candidateId, radiusMiles } = candidate;

    // Recorded purely for visibility into which path actually served each
    // request — useful for tuning zone activation thresholds with real data
    // rather than guessing.
    await db.update(requestsTable).set({ dispatch_strategy_used: strategyUsed }).where(eq(requestsTable.id, requestId));

    const [{ count: existingOffers }] = await db
      .select({ count: sql<number>`COUNT(*)::int` })
      .from(requestOffersTable)
      .where(eq(requestOffersTable.request_id, requestId));

    const expiresAt = new Date(Date.now() + OFFER_TIMEOUT_MS);
    const [offer] = await db.insert(requestOffersTable).values({
      request_id: requestId,
      helper_id: candidateId,
      sequence: existingOffers + 1,
      expires_at: expiresAt,
    }).returning();

    sendToUser(candidateId, {
      type: "dispatch_offer",
      payload: {
        offerId: offer.id,
        requestId,
        title: request.title,
        category: request.category,
        urgency: request.urgency,
        paymentType: request.payment_type,
        amount: request.pay_it_forward_amount ?? null,
        expiresAt: expiresAt.toISOString(),
        timeoutMs: OFFER_TIMEOUT_MS,
        // Lets the UI be honest when the match came from an expanded search
        // tier rather than implying "right next door" — e.g. "~45 mi away".
        matchedRadiusMiles: radiusMiles,
        viaZone: strategyUsed === "zone_based",
      },
    });

    sendPushToUser(candidateId, {
      title: "💙 You've got an exclusive offer",
      body: `${request.title} — respond within ${Math.round(OFFER_TIMEOUT_MS / 1000)}s before it goes to someone else.`,
      urgency: request.urgency,
      requestId,
    }).catch(() => {});

    logger.info(
      { request_id: requestId, helper_id: candidateId, strategy: strategyUsed, radius_miles: radiusMiles, sequence: offer.sequence },
      "dispatch: offer sent"
    );
  } catch (err) {
    // Dispatch is best-effort — a failure here must never block the public
    // claim flow, which remains the safety net regardless.
    logger.error({ err, request_id: requestId }, "dispatch: failed to send offer — request remains open for public claim");
  }
}
