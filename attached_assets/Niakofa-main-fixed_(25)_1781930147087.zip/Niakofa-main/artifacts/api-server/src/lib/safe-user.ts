import type { usersTable } from "@workspace/db";

/**
 * Strips password_hash from a user row before it goes to a client.
 *
 * This exists because the same leak kept recurring ad-hoc, one route at a
 * time, in this file — /location, /helper-mode, /avatar, and
 * /panic-contacts all independently forgot to strip it after
 * db.update(usersTable)....returning() shipped the raw row straight back.
 * Use this on every route that returns a user row, rather than remembering
 * to destructure password_hash out by hand each time.
 */
export function toSafeUser(user: typeof usersTable.$inferSelect) {
  const { password_hash: _ph, ...safeUser } = user;
  return safeUser;
}
