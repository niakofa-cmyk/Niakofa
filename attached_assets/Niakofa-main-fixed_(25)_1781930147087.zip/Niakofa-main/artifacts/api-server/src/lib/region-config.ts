/**
 * Region configuration — single source of truth for any user-facing
 * location text. Set via env vars per deployment instead of hardcoding a
 * single city/county anywhere in source.
 */
export const REGION_CITY = process.env["REGION_CITY"] ?? "your city";
export const REGION_COUNTY = process.env["REGION_COUNTY"] ?? "your county";
export const REGION_STATE = process.env["REGION_STATE"] ?? "your state";
export const REGION_LABEL = process.env["REGION_LABEL"] ?? "your community";

export const REGION_EMERGENCY_CONTACTS: Array<{ label: string; phone?: string; url?: string }> = (() => {
  const raw = process.env["REGION_EMERGENCY_CONTACTS_JSON"];
  if (raw) {
    try { return JSON.parse(raw); } catch { /* fall through to default */ }
  }
  return [
    { label: "Local Emergency Management", phone: "" },
    { label: "211 (Community Services)", phone: "211" },
    { label: "Red Cross", url: "https://www.redcross.org" },
  ];
})();
