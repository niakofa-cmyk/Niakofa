import { latLngToCell, cellToLatLng, gridDisk } from "h3-js";

// Resolution 8 ≈ 0.46 km² hexagons (~737m edge-to-edge). Fine enough to
// distinguish real neighborhoods, coarse enough that a request and a nearby
// helper usually land in the same or an adjacent cell rather than scattering
// across dozens of tiny cells. Matches the proposal's suggested 8–9 range.
export const H3_RESOLUTION = 8;

/** Converts a lat/lng into its H3 resolution-8 cell ID. */
export function toH3Cell(lat: number, lng: number): string {
  return latLngToCell(lat, lng, H3_RESOLUTION);
}

/** Returns the centroid lat/lng of an H3 cell. */
export function h3CellCentroid(h3Id: string): { lat: number; lng: number } {
  const [lat, lng] = cellToLatLng(h3Id);
  return { lat, lng };
}

/**
 * Returns the cell itself plus its immediate ring of neighbors (k=1 → 7
 * cells total for a hex grid). Zone-based dispatch searches this small
 * neighborhood rather than just the exact cell, so a helper one hex over
 * from a request isn't ignored purely because of where the grid lines fall
 * — the "boundary problem" the hybrid proposal specifically calls out.
 */
export function h3CellAndNeighbors(h3Id: string): string[] {
  return gridDisk(h3Id, 1);
}
