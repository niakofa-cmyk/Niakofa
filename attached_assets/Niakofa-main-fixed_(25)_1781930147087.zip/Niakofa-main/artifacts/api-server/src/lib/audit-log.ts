import { db, auditLogTable } from "@workspace/db";
import { logger } from "./logger";

interface LogAdminActionInput {
  adminUserId: number;
  action: string;
  targetType?: string;
  targetId?: number;
  details?: Record<string, unknown>;
}

/**
 * Records an admin action to the durable audit_log table. Never throws —
 * a logging failure must not block or roll back the admin action itself,
 * but it's loud in the server logs if it happens so it doesn't go unnoticed.
 */
export async function logAdminAction(input: LogAdminActionInput): Promise<void> {
  try {
    await db.insert(auditLogTable).values({
      admin_user_id: input.adminUserId,
      action: input.action,
      target_type: input.targetType ?? null,
      target_id: input.targetId ?? null,
      details: input.details ?? null,
    });
  } catch (err) {
    logger.error({ err, input }, "audit-log: failed to record admin action");
  }
}
