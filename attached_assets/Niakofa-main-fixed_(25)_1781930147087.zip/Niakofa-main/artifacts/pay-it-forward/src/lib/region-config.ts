/**
 * Region configuration — single source of truth for user-facing location
 * text on the frontend. Configured per-deployment via Vite env vars.
 */
export const REGION_CITY = import.meta.env.VITE_REGION_CITY ?? "your city";
export const REGION_COUNTY = import.meta.env.VITE_REGION_COUNTY ?? "your county";
export const REGION_STATE = import.meta.env.VITE_REGION_STATE ?? "your state";
export const REGION_LABEL = import.meta.env.VITE_REGION_LABEL ?? "your community";
