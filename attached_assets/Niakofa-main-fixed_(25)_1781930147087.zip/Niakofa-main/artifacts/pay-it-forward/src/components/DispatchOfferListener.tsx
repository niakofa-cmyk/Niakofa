import { useEffect, useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { Heart, Clock, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/lib/useWebSocket";
import { useAppContext } from "@/lib/AppContext";
import { authHeaders } from "@/lib/auth";
import { toast } from "@/hooks/use-toast";

interface DispatchOfferPayload {
  offerId: number;
  requestId: number;
  title: string;
  category: string;
  urgency: string;
  paymentType: string;
  amount: number | null;
  expiresAt: string;
  timeoutMs: number;
  matchedRadiusMiles?: number;
  viaZone?: boolean;
}

const CATEGORY_ICONS: Record<string, string> = {
  groceries: "🛒", transportation: "🚗", errands: "📦",
  home_repair: "🔧", medical: "💊", emergency: "🚨", other: "💙",
};

export function DispatchOfferListener() {
  const { currentUser } = useAppContext();
  const [, setLocation] = useLocation();
  const [offer, setOffer] = useState<DispatchOfferPayload | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(1);
  const [responding, setResponding] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearCountdown = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  useWebSocket("dispatch_offer", useCallback((event) => {
    const payload = event.payload as DispatchOfferPayload;
    setOffer(payload);
    setResponding(false);
    const expiresAt = new Date(payload.expiresAt).getTime();
    const remaining = Math.max(0, Math.round((expiresAt - Date.now()) / 1000));
    setSecondsLeft(remaining);
    setTotalSeconds(Math.max(1, Math.round(payload.timeoutMs / 1000)));
  }, []));

  useWebSocket("dispatch_offer_resolved", useCallback((event) => {
    const payload = event.payload as { offerId: number };
    setOffer((current) => (current?.offerId === payload.offerId ? null : current));
  }, []));

  // Countdown ticker — purely visual; the server is the source of truth for
  // actual expiry, so a clock skew here just means the sheet closes a beat
  // early or late, never an incorrect accept/decline outcome.
  useEffect(() => {
    clearCountdown();
    if (!offer) return;
    intervalRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearCountdown();
          setOffer(null);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return clearCountdown;
  }, [offer, clearCountdown]);

  const respond = async (action: "accept" | "decline") => {
    if (!offer || responding) return;
    setResponding(true);
    try {
      const res = await fetch(`/api/requests/${offer.requestId}/offers/${offer.offerId}/${action}`, {
        method: "POST",
        headers: authHeaders(),
      });
      if (action === "accept") {
        if (res.ok) {
          toast({ title: "🎉 You're on it!", description: offer.title });
          setOffer(null);
          setLocation(`/request/${offer.requestId}`);
        } else {
          const data = await res.json().catch(() => ({})) as { error?: string };
          toast({ title: data.error ?? "That offer is no longer available", variant: "destructive" });
          setOffer(null);
        }
      } else {
        setOffer(null);
      }
    } catch {
      toast({ title: "Couldn't reach the server — the offer may still expire on its own", variant: "destructive" });
    } finally {
      setResponding(false);
    }
  };

  if (!currentUser || !offer) return null;

  const progressPct = Math.max(0, Math.min(100, (secondsLeft / totalSeconds) * 100));

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
        />
        <motion.div
          initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 26, stiffness: 220 }}
          className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border rounded-t-3xl p-6"
          style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
        >
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-primary" />
              <h3 className="font-black text-lg">Exclusive Offer</h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setOffer(null)}
              className="rounded-full"
              aria-label="Dismiss"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="flex items-start gap-3 mb-5">
            <div className="text-3xl leading-none">{CATEGORY_ICONS[offer.category] ?? "💙"}</div>
            <div className="min-w-0">
              <p className="font-bold leading-snug break-words">{offer.title}</p>
              <p className="text-sm text-muted-foreground mt-0.5">
                {offer.paymentType === "immediate" && offer.amount
                  ? `Pays $${offer.amount.toFixed(2)}`
                  : "Pay it forward / goodwill"}
              </p>
              {offer.matchedRadiusMiles && offer.matchedRadiusMiles > 15 && !offer.viaZone && (
                <p className="text-xs text-muted-foreground mt-0.5">
                  ~{offer.matchedRadiusMiles} mi away — no one closer was available
                </p>
              )}
              {offer.viaZone && (
                <p className="text-xs text-primary font-bold mt-0.5">
                  📍 You're in a high-demand zone
                </p>
              )}
            </div>
          </div>

          <div className="mb-5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-500 mb-2">
              <Clock className="w-3.5 h-3.5" />
              {secondsLeft}s left before it goes to someone else
            </div>
            <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-amber-500 rounded-full"
                animate={{ width: `${progressPct}%` }}
                transition={{ duration: 0.4, ease: "linear" }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              className="h-12"
              disabled={responding}
              onClick={() => respond("decline")}
            >
              No thanks
            </Button>
            <Button
              className="h-12 font-black"
              disabled={responding}
              onClick={() => respond("accept")}
            >
              Accept
            </Button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}
