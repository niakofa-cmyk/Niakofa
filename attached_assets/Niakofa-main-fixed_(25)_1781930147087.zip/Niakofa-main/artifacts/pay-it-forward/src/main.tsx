import { createRoot } from "react-dom/client";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import App from "./App";
import "./index.css";
import { getToken } from "./lib/auth";

// Without this, every call made through the generated react-query hooks
// (useGetOnlineHelpers, useGetNearbyRequests, etc.) goes out with no
// Authorization header at all — those routes have been relying entirely on
// being unauthenticated themselves to "work." This needs to be registered
// before any component using those hooks mounts.
setAuthTokenGetter(() => getToken());

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js", { scope: "/" })
      .catch(() => {});
  });
}

createRoot(document.getElementById("root")!).render(<App />);
