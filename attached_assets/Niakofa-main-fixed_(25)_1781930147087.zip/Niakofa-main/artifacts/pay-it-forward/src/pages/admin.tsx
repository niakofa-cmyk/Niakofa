import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import {
  Shield, AlertCircle, CheckCircle2, Clock, X, ChevronLeft,
  Eye, Flag, User as UserIcon, RefreshCw, Filter,
  Users, Search, Ban, AlertTriangle, Star, BarChart3,
  TrendingUp, Heart, Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area, CartesianGrid, Legend,
} from "recharts";

// ── Types ─────────────────────────────────────────────────────────────────────

interface Report {
  id: number;
  reporter_id: number;
  reported_user_id: number | null;
  reported_request_id: number | null;
  type: string;
  description: string;
  status: string;
  admin_notes: string | null;
  reviewed_by: number | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
  reporter_name?: string | null;
  reporter_email?: string | null;
  reported_user_name?: string | null;
}

interface AdminUser {
  id: number;
  name: string;
  email: string;
  is_helper: boolean;
  trust_score: number | null;
  help_count: number;
  created_at: string;
}

interface AnalyticsData {
  overview: {
    total_open: number;
    total_completed: number;
    total_helpers_online: number;
    recent_completions_24h: number;
    total_users: number;
    new_users_week: number;
  };
  requests_by_category: { category: string; count: number }[];
  daily_request_volume: { day: string; count: number }[];
  pledge_pool: { total_pledged: number; total_paid: number; pending: number };
  reports_by_status: { status: string; count: number }[];
  reports_by_type: { type: string; count: number }[];
  trust_score_distribution: { bucket: string; count: number }[];
}

// ── Constants ─────────────────────────────────────────────────────────────────

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  pending:             { label: "Pending",      color: "bg-yellow-500/15 text-yellow-500 border-yellow-500/30" },
  under_review:        { label: "Under Review", color: "bg-blue-500/15 text-blue-400 border-blue-500/30" },
  resolved_dismissed:  { label: "Dismissed",    color: "bg-muted text-muted-foreground border-border" },
  resolved_warned:     { label: "Warned",       color: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
  resolved_banned:     { label: "Banned",       color: "bg-destructive/15 text-destructive border-destructive/30" },
};

const TYPE_LABELS: Record<string, string> = {
  suspicious_request: "Suspicious Request",
  suspicious_helper:  "Suspicious Helper",
  fraud:              "Fraud",
  harassment:         "Harassment",
  fake_profile:       "Fake Profile",
  dangerous_behavior: "Dangerous Behavior",
  spam:               "Spam",
  other:              "Other",
};

const CHART_COLORS = ["#06b6d4", "#8b5cf6", "#10b981", "#f59e0b", "#ef4444", "#ec4899", "#3b82f6", "#84cc16"];

const STATUS_FILTERS = ["all", "pending", "under_review", "resolved_dismissed", "resolved_warned", "resolved_banned"];

const SESSION_KEY = "admin_token";
const SESSION_USER_KEY = "admin_user_id";

function fmtDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function getAdminToken(): string | null {
  return sessionStorage.getItem(SESSION_KEY);
}

function getAdminUserId(): number | null {
  const v = sessionStorage.getItem(SESSION_USER_KEY);
  return v ? parseInt(v) : null;
}

function authHeaders(): Record<string, string> {
  const token = getAdminToken();
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  return headers;
}

// ── Login Screen ──────────────────────────────────────────────────────────────

function AdminLogin({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

  const handleLogin = async () => {
    if (!email || !password) { setError("Email and password required"); return; }
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${base}/api/users/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password }),
      });
      const data = await res.json() as { user?: { id: number; is_admin?: boolean }; token?: string; error?: string };
      if (!res.ok) { setError(data.error ?? "Login failed"); return; }
      if (!data.user?.is_admin) { setError("Access denied — admin account required"); return; }
      if (!data.token) { setError("Login error — no token returned"); return; }
      sessionStorage.setItem(SESSION_KEY, data.token);
      sessionStorage.setItem(SESSION_USER_KEY, String(data.user.id));
      onLogin();
    } catch {
      setError("Network error — check your connection");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-background flex flex-col items-center justify-center p-8 gap-6">
      <div className="w-16 h-16 rounded-2xl bg-destructive/10 border border-destructive/30 flex items-center justify-center">
        <Shield className="w-8 h-8 text-destructive" />
      </div>
      <div className="text-center">
        <h1 className="text-2xl font-black">Admin Access</h1>
        <p className="text-sm text-muted-foreground mt-1">Sign in with your admin account</p>
      </div>
      <div className="w-full max-w-xs space-y-3">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleLogin()}
          className="w-full px-4 py-3 rounded-xl border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          autoFocus
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleLogin()}
          className="w-full px-4 py-3 rounded-xl border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {error && (
          <div className="flex items-center gap-2 text-destructive text-sm">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
        <Button
          onClick={handleLogin}
          disabled={loading}
          className="w-full h-11 font-black"
        >
          {loading ? <span className="flex items-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" />Signing in…</span> : "Enter Admin"}
        </Button>
      </div>
    </div>
  );
}

// ── Report Detail Sheet ───────────────────────────────────────────────────────

function ReportDetailSheet({ report, onClose, onReviewed }: {
  report: Report;
  onClose: () => void;
  onReviewed: (updated: Report) => void;
}) {
  const [status, setStatus] = useState<string>(report.status === "pending" ? "under_review" : report.status);
  const [notes, setNotes] = useState(report.admin_notes ?? "");
  const [saving, setSaving] = useState(false);
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

  const handleReview = async () => {
    const actionableStatuses = ["under_review", "resolved_dismissed", "resolved_warned", "resolved_banned"];
    if (!actionableStatuses.includes(status)) return;
    setSaving(true);
    try {
      const res = await fetch(`${base}/api/reports/${report.id}/review`, {
        method: "PATCH",
        headers: authHeaders(),
        body: JSON.stringify({ status, admin_notes: notes || null }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? "Failed");
      }
      const updated = await res.json() as Report;
      onReviewed(updated);
      toast({ title: "Report updated", description: `Status set to: ${STATUS_LABELS[status]?.label ?? status}` });
      onClose();
    } catch (e: unknown) {
      toast({ title: (e as Error).message ?? "Failed to update report", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 26, stiffness: 220 }}
        className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border rounded-t-3xl max-h-[92dvh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 pb-3 border-b border-border">
          <div className="flex items-center gap-2">
            <Flag className="w-5 h-5 text-destructive" />
            <h3 className="font-black text-lg">Report #{report.id}</h3>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-background rounded-xl p-3 border border-border">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Type</div>
              <div className="text-sm font-bold">{TYPE_LABELS[report.type] ?? report.type}</div>
            </div>
            <div className="bg-background rounded-xl p-3 border border-border">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Filed</div>
              <div className="text-sm font-bold">{fmtDate(report.created_at)}</div>
            </div>
            {report.reporter_name && (
              <div className="bg-background rounded-xl p-3 border border-border">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Reporter</div>
                <div className="text-sm font-bold">{report.reporter_name}</div>
                {report.reporter_email && <div className="text-[10px] text-muted-foreground">{report.reporter_email}</div>}
              </div>
            )}
            {report.reported_user_name && (
              <div className="bg-background rounded-xl p-3 border border-border">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Reported User</div>
                <div className="text-sm font-bold">{report.reported_user_name}</div>
              </div>
            )}
            {report.reported_request_id && (
              <div className="bg-background rounded-xl p-3 border border-border">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Request ID</div>
                <div className="text-sm font-bold">#{report.reported_request_id}</div>
              </div>
            )}
          </div>

          <div className="bg-background rounded-xl p-4 border border-border">
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Description</div>
            <p className="text-sm leading-relaxed">{report.description}</p>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">Admin Action</div>
            <div className="grid grid-cols-2 gap-2">
              {(["under_review", "resolved_dismissed", "resolved_warned", "resolved_banned"] as const).map(s => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                    status === s
                      ? STATUS_LABELS[s].color + " ring-2 ring-offset-1 ring-offset-card ring-current"
                      : "bg-background border-border text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  {STATUS_LABELS[s].label}
                </button>
              ))}
            </div>
            <textarea
              placeholder="Admin notes (optional)…"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
              className="w-full text-sm bg-background border border-border rounded-xl p-3 resize-none focus:outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
            />
            <Button className="w-full h-11 font-black" onClick={handleReview} disabled={saving}>
              {saving ? <span className="flex items-center gap-2"><RefreshCw className="w-4 h-4 animate-spin" />Saving…</span> : "Submit Review"}
            </Button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

// ── Reports Tab ───────────────────────────────────────────────────────────────

function ReportsTab() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

  const fetchReports = useCallback(async (status?: string) => {
    setLoading(true);
    try {
      const url = status && status !== "all"
        ? `${base}/api/reports?status=${status}`
        : `${base}/api/reports`;
      const res = await fetch(url, { headers: authHeaders() });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json() as Report[];
      setReports(data);
    } catch {
      toast({ title: "Could not load reports", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [base]);

  useEffect(() => { fetchReports(statusFilter); }, [statusFilter]);

  const openDetail = async (report: Report) => {
    setDetailLoading(true);
    try {
      const res = await fetch(`${base}/api/reports/${report.id}`, { headers: authHeaders() });
      setSelectedReport(res.ok ? await res.json() as Report : report);
    } catch {
      setSelectedReport(report);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleReviewed = (updated: Report) => {
    setReports(prev => prev.map(r => r.id === updated.id ? { ...r, ...updated } : r));
  };

  const pendingCount = reports.filter(r => r.status === "pending").length;
  const filteredReports = statusFilter === "all" ? reports : reports.filter(r => r.status === statusFilter);

  return (
    <div className="space-y-3">
      {/* Header stats */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">{reports.length} total</span>
        {pendingCount > 0 && (
          <span className="text-[10px] font-black bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 px-2 py-0.5 rounded-full">
            {pendingCount} pending
          </span>
        )}
        <button
          onClick={() => fetchReports(statusFilter)}
          disabled={loading}
          className="ml-auto p-1.5 rounded-lg hover:bg-muted transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Filter chips */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
        {STATUS_FILTERS.map(s => {
          const meta = STATUS_LABELS[s];
          const isActive = statusFilter === s;
          return (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`shrink-0 text-[11px] font-bold px-3 py-1.5 rounded-full border transition-all ${
                isActive
                  ? s === "all" ? "bg-primary text-primary-foreground border-primary" : (meta?.color ?? "bg-primary text-primary-foreground border-primary")
                  : "bg-background border-border text-muted-foreground hover:border-primary/40"
              }`}
            >
              {s === "all" ? "All" : meta?.label ?? s}
            </button>
          );
        })}
      </div>

      {loading && (
        <div className="flex items-center justify-center py-16 gap-2 text-muted-foreground">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading reports…</span>
        </div>
      )}

      {!loading && filteredReports.length === 0 && (
        <div className="text-center py-16">
          <CheckCircle2 className="w-10 h-10 mx-auto mb-3 text-green-400/40" />
          <div className="font-bold text-sm text-muted-foreground">
            {statusFilter === "all" ? "No reports yet" : `No ${STATUS_LABELS[statusFilter]?.label?.toLowerCase() ?? statusFilter} reports`}
          </div>
          <div className="text-xs text-muted-foreground/60 mt-1">The queue is clear</div>
        </div>
      )}

      {!loading && filteredReports.map(report => {
        const statusMeta = STATUS_LABELS[report.status] ?? { label: report.status, color: "bg-muted text-muted-foreground border-border" };
        return (
          <motion.button
            key={report.id}
            layout
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => openDetail(report)}
            disabled={detailLoading}
            className="w-full text-left bg-card border border-border rounded-2xl p-4 hover:border-primary/40 transition-all"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${statusMeta.color}`}>
                    {statusMeta.label}
                  </span>
                  <span className="text-[10px] font-semibold bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                    {TYPE_LABELS[report.type] ?? report.type}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">{report.description}</p>
                <div className="flex items-center gap-3 mt-2 flex-wrap">
                  {report.reported_user_id && (
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <UserIcon className="w-3 h-3" /> User #{report.reported_user_id}
                    </span>
                  )}
                  {report.reported_request_id && (
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Flag className="w-3 h-3" /> Request #{report.reported_request_id}
                    </span>
                  )}
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {fmtDate(report.created_at)}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {report.status === "pending" && <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />}
                <Eye className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
            {report.admin_notes && (
              <div className="mt-3 pt-3 border-t border-border">
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Admin Notes</div>
                <p className="text-xs text-muted-foreground line-clamp-2">{report.admin_notes}</p>
              </div>
            )}
          </motion.button>
        );
      })}

      {selectedReport && (
        <ReportDetailSheet
          report={selectedReport}
          onClose={() => setSelectedReport(null)}
          onReviewed={handleReviewed}
        />
      )}
    </div>
  );
}

// ── Users Tab ─────────────────────────────────────────────────────────────────

function UsersTab() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [actionUser, setActionUser] = useState<AdminUser | null>(null);
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

  useEffect(() => {
    fetch(`${base}/api/users`, { headers: authHeaders() })
      .then(r => r.json())
      .then((data) => { if (Array.isArray(data)) setUsers(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = users.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const handleAction = async (userId: number, action: "warn" | "ban") => {
    try {
      const res = await fetch(`${base}/api/users/${userId}/moderation`, {
        method: "PATCH",
        headers: authHeaders(),
        body: JSON.stringify({ action }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({})) as { error?: string };
        throw new Error(err.error ?? "Action failed");
      }
      toast({ title: action === "ban" ? "User banned" : "Warning issued" });
      setActionUser(null);
      setUsers(prev => prev.map(u => {
        if (u.id !== userId) return u;
        return { ...u, trust_score: action === "ban" ? -1 : Math.max(0, (u.trust_score ?? 5) - 10) };
      }));
    } catch (e: unknown) {
      toast({ title: (e as Error).message ?? "Action failed", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="search"
          placeholder="Search users..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none focus:ring-1 focus:ring-primary transition-all"
        />
      </div>

      {loading && (
        <div className="flex items-center justify-center py-12 gap-2 text-muted-foreground">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading users…</span>
        </div>
      )}

      {filtered.map(user => (
        <motion.div
          key={user.id}
          layout
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-2xl p-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 font-black text-primary">
              {user.name[0]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-black text-sm truncate">{user.name}</div>
              <div className="text-[10px] text-muted-foreground truncate">{user.email}</div>
              <div className="flex items-center gap-2 mt-1">
                {user.is_helper && (
                  <span className="text-[10px] bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-full font-bold">Helper</span>
                )}
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Star className="w-3 h-3" />{(user.trust_score ?? 0).toFixed(1)}
                </span>
                <span className="text-[10px] text-muted-foreground">{user.help_count} helps</span>
              </div>
            </div>
            <button
              onClick={() => setActionUser(user)}
              className="p-2 rounded-xl border border-border active:bg-muted transition-colors"
            >
              <AlertTriangle className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </motion.div>
      ))}

      <AnimatePresence>
        {actionUser && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 z-50 backdrop-blur-sm"
              onClick={() => setActionUser(null)}
            />
            <motion.div
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border rounded-t-3xl p-5"
              style={{ paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" }}
              onClick={e => e.stopPropagation()}
            >
              <div className="text-center mb-5">
                <div className="w-12 h-12 rounded-full bg-muted mx-auto flex items-center justify-center font-black text-lg mb-2">
                  {actionUser.name[0]}
                </div>
                <div className="font-black">{actionUser.name}</div>
                <div className="text-xs text-muted-foreground">{actionUser.email}</div>
              </div>
              <div className="space-y-2">
                <button
                  onClick={() => handleAction(actionUser.id, "warn")}
                  className="w-full flex items-center gap-3 p-4 bg-orange-500/10 border border-orange-500/30 rounded-2xl active:scale-[0.98] transition-all"
                >
                  <AlertTriangle className="w-5 h-5 text-orange-400" />
                  <div className="text-left">
                    <div className="font-black text-sm text-orange-400">Issue Warning</div>
                    <div className="text-xs text-muted-foreground">User receives a community guidelines warning</div>
                  </div>
                </button>
                <button
                  onClick={() => handleAction(actionUser.id, "ban")}
                  className="w-full flex items-center gap-3 p-4 bg-destructive/10 border border-destructive/30 rounded-2xl active:scale-[0.98] transition-all"
                >
                  <Ban className="w-5 h-5 text-destructive" />
                  <div className="text-left">
                    <div className="font-black text-sm text-destructive">Ban User</div>
                    <div className="text-xs text-muted-foreground">Remove from platform permanently</div>
                  </div>
                </button>
                <button
                  onClick={() => setActionUser(null)}
                  className="w-full p-3 text-sm text-muted-foreground active:text-foreground transition-colors"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Analytics Tab ─────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, icon: Icon, color = "text-primary" }: {
  label: string; value: string | number; sub?: string; icon: React.ElementType; color?: string;
}) {
  return (
    <div className="bg-card border border-border rounded-2xl p-4">
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className={`p-2 rounded-xl bg-muted ${color}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="text-2xl font-black">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
      {sub && <div className="text-[10px] text-primary mt-1">{sub}</div>}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-xl px-3 py-2 text-xs shadow-lg">
      {label && <div className="font-bold mb-1 text-foreground">{label}</div>}
      {payload.map((p, i) => (
        <div key={i} className="text-muted-foreground">{p.name ?? "Count"}: <span className="font-bold text-foreground">{p.value}</span></div>
      ))}
    </div>
  );
};

function AnalyticsTab() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");

  const fetchAnalytics = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${base}/api/admin/analytics`, { headers: authHeaders() });
      if (!res.ok) throw new Error("Failed to load analytics");
      setData(await res.json() as AnalyticsData);
    } catch {
      toast({ title: "Could not load analytics", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [base]);

  useEffect(() => { fetchAnalytics(); }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 gap-2 text-muted-foreground">
        <RefreshCw className="w-5 h-5 animate-spin" />
        <span className="text-sm">Loading analytics…</span>
      </div>
    );
  }

  if (!data) return null;

  const { overview, requests_by_category, daily_request_volume, pledge_pool, reports_by_type, trust_score_distribution } = data;

  const categoryData = requests_by_category.map(d => ({
    name: d.category.charAt(0).toUpperCase() + d.category.slice(1),
    count: d.count,
  }));

  const reportTypeData = reports_by_type.map(d => ({
    name: TYPE_LABELS[d.type] ?? d.type,
    value: d.count,
  }));

  const trustData = [...trust_score_distribution].sort((a, b) => a.bucket.localeCompare(b.bucket));

  const pledgePct = pledge_pool.total_pledged > 0
    ? Math.round((pledge_pool.total_paid / pledge_pool.total_pledged) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* Refresh */}
      <div className="flex items-center justify-between">
        <div className="text-xs font-black uppercase tracking-wider text-muted-foreground">Platform Health</div>
        <button onClick={fetchAnalytics} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
          <RefreshCw className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
      </div>

      {/* Overview stat cards */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Open Requests" value={overview.total_open} icon={Activity} color="text-yellow-500" />
        <StatCard label="Completed" value={overview.total_completed} icon={CheckCircle2} color="text-green-500" />
        <StatCard label="Online Helpers" value={overview.total_helpers_online} icon={Users} color="text-primary" />
        <StatCard label="Completions (24h)" value={overview.recent_completions_24h} icon={TrendingUp} color="text-purple-400" />
        <StatCard label="Total Users" value={overview.total_users} sub={`+${overview.new_users_week} this week`} icon={UserIcon} color="text-blue-400" />
        <StatCard
          label="Pledge Pool"
          value={`$${(pledge_pool.total_paid / 100).toFixed(0)}`}
          sub={`${pledgePct}% paid · $${(pledge_pool.pending / 100).toFixed(0)} pending`}
          icon={Heart}
          color="text-pink-400"
        />
      </div>

      {/* Daily request volume */}
      {daily_request_volume.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-4">Request Volume — Last 7 Days</div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={daily_request_volume} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
              <defs>
                <linearGradient id="volGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="count" name="Requests" stroke="#06b6d4" strokeWidth={2} fill="url(#volGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Requests by category */}
      {categoryData.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-4">Requests by Category</div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={categoryData} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" name="Requests" radius={[6, 6, 0, 0]}>
                {categoryData.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Trust score distribution */}
      {trustData.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-4">Trust Score Distribution</div>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={trustData} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="bucket" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" name="Users" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Report type breakdown */}
      {reportTypeData.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-4">Reports by Type</div>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width="50%" height={140}>
              <PieChart>
                <Pie
                  data={reportTypeData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={36}
                  outerRadius={60}
                  paddingAngle={3}
                >
                  {reportTypeData.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-1.5">
              {reportTypeData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }} />
                    <span className="text-[10px] text-muted-foreground truncate">{d.name}</span>
                  </div>
                  <span className="text-[10px] font-black text-foreground">{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Pledge pool health bar */}
      <div className="bg-card border border-border rounded-2xl p-4">
        <div className="text-xs font-black uppercase tracking-wider text-muted-foreground mb-3">Pledge Pool Health</div>
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">Paid</span>
            <span className="font-bold">${(pledge_pool.total_paid / 100).toFixed(2)} / ${(pledge_pool.total_pledged / 100).toFixed(2)}</span>
          </div>
          <div className="h-2.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary to-green-500 rounded-full transition-all"
              style={{ width: `${pledgePct}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-muted-foreground">
            <span>{pledgePct}% fulfilled</span>
            <span>${(pledge_pool.pending / 100).toFixed(2)} outstanding</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main Admin Screen ─────────────────────────────────────────────────────────

type TabId = "reports" | "users" | "analytics";

const TABS: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: "reports", label: "Reports", icon: Flag },
  { id: "users",   label: "Users",   icon: Users },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
];

export default function AdminScreen() {
  const [authed, setAuthed] = useState(!!getAdminToken());
  const [activeTab, setActiveTab] = useState<TabId>("reports");
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_USER_KEY);
    setAuthed(false);
  };

  if (!authed) {
    return <AdminLogin onLogin={() => setAuthed(true)} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col pb-24">
      {/* Header */}
      <div
        className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-border p-4"
        style={{ paddingTop: "max(1rem, env(safe-area-inset-top))" }}
      >
        <div className="flex items-center gap-3">
          <button onClick={() => setLocation("/profile")} className="p-1.5 rounded-xl hover:bg-muted transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-black uppercase tracking-widest flex items-center gap-2">
              <Shield className="w-5 h-5 text-destructive" /> Admin
            </h1>
          </div>
          <button
            onClick={handleLogout}
            className="text-[10px] font-black text-muted-foreground hover:text-destructive transition-colors px-2 py-1 rounded-lg hover:bg-destructive/10"
          >
            Sign out
          </button>
        </div>

        {/* Tab bar */}
        <div className="flex gap-1 mt-3 bg-muted rounded-xl p-1">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-black transition-all ${
                activeTab === tab.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 max-w-lg mx-auto w-full p-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === "reports"   && <ReportsTab />}
            {activeTab === "users"     && <UsersTab />}
            {activeTab === "analytics" && <AnalyticsTab />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
