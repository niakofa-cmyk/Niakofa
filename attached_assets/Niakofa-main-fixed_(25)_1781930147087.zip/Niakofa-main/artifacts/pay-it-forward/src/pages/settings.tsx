import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { authHeaders } from "@/lib/auth";
import {
  ChevronLeft,
  ChevronRight,
  Bell,
  Lock,
  Sliders,
  CreditCard,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Globe,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAppContext } from "@/lib/AppContext";
import { toast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";
import i18n from "../i18n";

// ── API helpers (kept in sync with profile.tsx) ───────────────────────────────

async function fetchSettings(userId: number) {
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
  const res = await fetch(`${base}/api/users/${userId}/settings`, { headers: authHeaders() });
  if (!res.ok) return null;
  return res.json();
}

async function saveSettings(
  userId: number,
  updates: Record<string, boolean | number | string>
) {
  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
  const res = await fetch(`${base}/api/users/${userId}/settings`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(updates),
  });
  if (!res.ok) throw new Error("Failed to save settings");
  return res.json();
}

// ── Notification Preferences ──────────────────────────────────────────────────

function NotificationPreferences({ userId }: { userId: number }) {
  const [prefs, setPrefs] = useState({
    notif_nearby_requests: true,
    notif_emergency: true,
    notif_task_accepted: true,
    notif_wallet_updates: true,
    notif_community_activity: false,
    notif_pledge_reminders: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings(userId)
      .then((data) => {
        if (data)
          setPrefs({
            notif_nearby_requests: data.notif_nearby_requests ?? true,
            notif_emergency: data.notif_emergency ?? true,
            notif_task_accepted: data.notif_task_accepted ?? true,
            notif_wallet_updates: data.notif_wallet_updates ?? true,
            notif_community_activity: data.notif_community_activity ?? false,
            notif_pledge_reminders: data.notif_pledge_reminders ?? true,
          });
      })
      .finally(() => setLoading(false));
  }, [userId]);

  const toggle = (key: keyof typeof prefs) =>
    setPrefs((p) => ({ ...p, [key]: !p[key] }));

  const labels: Record<keyof typeof prefs, string> = {
    notif_nearby_requests: "Nearby help requests",
    notif_emergency: "Emergency alerts",
    notif_task_accepted: "Task accepted / en route",
    notif_wallet_updates: "Wallet & pledge updates",
    notif_community_activity: "Community activity feed",
    notif_pledge_reminders: "Niakofa reminders",
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveSettings(userId, prefs);
      toast({ title: "Notification preferences saved" });
    } catch {
      toast({ title: "Failed to save", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Notification Preferences</h2>
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          <div className="pt-1 border-t border-border/60">
            <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider font-bold">
              In-App Notification Types
            </p>
            {(Object.keys(prefs) as (keyof typeof prefs)[]).map((key) => (
              <div
                key={key}
                className="flex items-center justify-between p-3 bg-background rounded-xl border border-border mb-2"
              >
                <span className="text-sm">{labels[key]}</span>
                <Switch
                  checked={prefs[key]}
                  onCheckedChange={() => toggle(key)}
                />
              </div>
            ))}
          </div>
          <Button
            className="w-full mt-2"
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? "Saving…" : "Save Preferences"}
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Account Privacy ───────────────────────────────────────────────────────────

function LanguageSwitcher(_: { userId: number }) {
  const [lang, setLang] = useState(i18n.language ?? "en");

  const languages = [
    { code: "en", label: "English", flag: "🇺🇸" },
    { code: "es", label: "Español", flag: "🇲🇽" },
  ];

  const handleChange = (code: string) => {
    i18n.changeLanguage(code);
    localStorage.setItem("niakofa_lang", code);
    setLang(code);
    toast({ title: code === "es" ? "Idioma cambiado a Español" : "Language changed to English" });
  };

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        Choose your preferred language for the Niakofa app.
      </p>
      {languages.map(l => (
        <button
          key={l.code}
          onClick={() => handleChange(l.code)}
          className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-colors text-left ${
            lang === l.code
              ? "border-primary bg-primary/10 text-primary"
              : "border-border bg-card text-foreground hover:border-primary/40"
          }`}
        >
          <span className="text-2xl">{l.flag}</span>
          <div className="flex-1">
            <div className="font-semibold text-sm">{l.label}</div>
          </div>
          {lang === l.code && <CheckCircle2 className="w-4 h-4 text-primary" />}
        </button>
      ))}
    </div>
  );
}

function AccountPrivacy({ userId }: { userId: number }) {
  const [prefs, setPrefs] = useState({
    privacy_profile_visible: true,
    privacy_live_location: false,
    privacy_activity_sharing: true,
    privacy_anonymous_giving: false,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings(userId)
      .then((data) => {
        if (data)
          setPrefs({
            privacy_profile_visible: data.privacy_profile_visible ?? true,
            privacy_live_location: data.privacy_live_location ?? false,
            privacy_activity_sharing: data.privacy_activity_sharing ?? true,
            privacy_anonymous_giving: data.privacy_anonymous_giving ?? false,
          });
      })
      .finally(() => setLoading(false));
  }, [userId]);

  const toggle = (key: keyof typeof prefs) =>
    setPrefs((p) => ({ ...p, [key]: !p[key] }));

  const items: { key: keyof typeof prefs; label: string; desc: string }[] = [
    {
      key: "privacy_profile_visible",
      label: "Profile discoverable",
      desc: "Others can find your profile when searching for helpers",
    },
    {
      key: "privacy_live_location",
      label: "Share live location",
      desc: "Show your real-time position to requesters when helping",
    },
    {
      key: "privacy_activity_sharing",
      label: "Activity sharing",
      desc: "Show recent help activity on your public profile",
    },
    {
      key: "privacy_anonymous_giving",
      label: "Anonymous giving",
      desc: "Niakofa contributions appear as anonymous",
    },
  ];

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveSettings(userId, prefs);
      toast({ title: "Privacy settings saved" });
    } catch {
      toast({ title: "Failed to save", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Account Privacy</h2>
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.key}
              className="p-3 bg-background rounded-xl border border-border mb-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm">{item.label}</span>
                <Switch
                  checked={prefs[item.key]}
                  onCheckedChange={() => toggle(item.key)}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
            </div>
          ))}
          <Button
            className="w-full mt-2"
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? "Saving…" : "Save Preferences"}
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Helper Settings ───────────────────────────────────────────────────────────

function HelperSettings({ userId }: { userId: number }) {
  const [prefs, setPrefs] = useState({
    service_radius_miles: 5,
    max_travel_miles: 10,
    dispatch_opt_in: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings(userId)
      .then((data) => {
        if (data)
          setPrefs({
            service_radius_miles: data.service_radius_miles ?? 5,
            max_travel_miles: data.max_travel_miles ?? 10,
            dispatch_opt_in: data.dispatch_opt_in ?? true,
          });
      })
      .finally(() => setLoading(false));
  }, [userId]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveSettings(userId, prefs);
      toast({ title: "Helper settings saved" });
    } catch {
      toast({ title: "Failed to save", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Helper Settings</h2>
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          <div className="p-3 bg-background rounded-xl border border-border mb-2">
            <label
              htmlFor="service_radius"
              className="text-sm font-semibold"
            >
              Service Radius (miles)
            </label>
            <input
              id="service_radius"
              type="number"
              min={1}
              max={50}
              value={prefs.service_radius_miles}
              onChange={(e) =>
                setPrefs((p) => ({
                  ...p,
                  service_radius_miles: parseInt(e.target.value) || 1,
                }))
              }
              className="w-full bg-muted border border-border rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-1 focus:ring-primary transition-all mt-2"
            />
          </div>
          <div className="p-3 bg-background rounded-xl border border-border mb-2">
            <label
              htmlFor="max_travel"
              className="text-sm font-semibold"
            >
              Max Travel Distance (miles)
            </label>
            <input
              id="max_travel"
              type="number"
              min={1}
              max={100}
              value={prefs.max_travel_miles}
              onChange={(e) =>
                setPrefs((p) => ({
                  ...p,
                  max_travel_miles: parseInt(e.target.value) || 1,
                }))
              }
              className="w-full bg-muted border border-border rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-1 focus:ring-primary transition-all mt-2"
            />
          </div>
          <div className="p-3 bg-background rounded-xl border border-border mb-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold">Exclusive dispatch offers</span>
              <Switch
                checked={prefs.dispatch_opt_in}
                onCheckedChange={(checked) =>
                  setPrefs((p) => ({ ...p, dispatch_opt_in: checked }))
                }
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
              When on, you may get a short-lived exclusive offer for a nearby
              request before it's shown to anyone else. Turn this off if you'd
              rather just browse the map and claim requests yourself — helper
              mode stays on either way.
            </p>
          </div>
          <Button
            className="w-full mt-2"
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? "Saving…" : "Save Helper Settings"}
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Payout Setup ──────────────────────────────────────────────────────────────

function PayoutSetup({ userId }: { userId: number }) {
  const [loading, setLoading] = useState(false);
  const [stripeAccountStatus, setStripeAccountStatus] = useState<string | null>(
    null
  );

  useEffect(() => {
    const fetchStripeStatus = async () => {
      setLoading(true);
      try {
        const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
        const res = await fetch(
          `${base}/api/stripe/connect/status/${userId}`,
          { headers: authHeaders() }
        );
        if (res.ok) {
          const data = await res.json();
          setStripeAccountStatus(data.status);
        } else {
          setStripeAccountStatus("not_connected");
        }
      } catch {
        setStripeAccountStatus("error");
      } finally {
        setLoading(false);
      }
    };
    fetchStripeStatus();
  }, [userId]);

  const handleConnectStripe = async () => {
    setLoading(true);
    try {
      const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
      const res = await fetch(
        `${base}/api/stripe/connect/onboard/${userId}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
        }
      );
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast({
          title: data.error || "Failed to connect Stripe",
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "Could not connect to Stripe — please try again",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Payout Setup</h2>
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          {stripeAccountStatus === "connected" ? (
            <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-xl border border-green-500/30">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
              <span className="text-sm font-semibold text-green-400">
                Stripe Connected
              </span>
            </div>
          ) : stripeAccountStatus === "pending_requirements" ? (
            <div className="flex items-center gap-2 p-3 bg-yellow-500/10 rounded-xl border border-yellow-500/30">
              <AlertCircle className="w-5 h-5 text-yellow-400" />
              <span className="text-sm font-semibold text-yellow-400">
                Action Required: Complete Stripe Onboarding
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={handleConnectStripe}
                disabled={loading}
                className="ml-auto"
              >
                Continue Setup
              </Button>
            </div>
          ) : (
            <Button
              className="w-full"
              onClick={handleConnectStripe}
              disabled={loading}
            >
              Connect with Stripe
            </Button>
          )}
          <p className="text-xs text-muted-foreground">
            Connect your Stripe account to receive payouts for completed help
            requests.
          </p>
        </div>
      )}
    </div>
  );
}

// ── Section type ──────────────────────────────────────────────────────────────

type SectionComponent = React.ComponentType<{ userId: number }>;

interface SettingsSection {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  component: SectionComponent | null;
}

// ── Main Settings Page ────────────────────────────────────────────────────────

export default function SettingsPage() {
  const [, setLocation] = useLocation();
  const { currentUser } = useAppContext();

  // Read ?section= query param to allow deep-linking from profile page
  const initialSection = new URLSearchParams(window.location.search).get("section");
  const [activeSection, setActiveSection] = useState<string | null>(initialSection);

  if (!currentUser) {
    setLocation("/login");
    return null;
  }

  const sections: SettingsSection[] = [
    {
      id: "notifications",
      title: "Notification Preferences",
      icon: Bell,
      component: NotificationPreferences,
    },
    {
      id: "privacy",
      title: "Account Privacy",
      icon: Lock,
      component: AccountPrivacy,
    },
    {
      id: "language",
      title: "Language / Idioma",
      icon: Globe,
      component: LanguageSwitcher,
    },
    {
      id: "delete-account",
      title: "Delete Account",
      icon: Trash2,
      component: null,
    },
  ];

  if (currentUser.is_helper) {
    sections.splice(2, 0,
      {
        id: "helper-settings",
        title: "Helper Settings",
        icon: Sliders,
        component: HelperSettings,
      },
      {
        id: "payout-setup",
        title: "Payout Setup",
        icon: CreditCard,
        component: PayoutSetup,
      }
    );
  }

  const activeEntry = sections.find((s) => s.id === activeSection) ?? null;
  const CurrentComponent = activeEntry?.component ?? null;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center p-4 border-b border-border">
        <Button
          variant="ghost"
          size="icon"
          onClick={() =>
            activeSection ? setActiveSection(null) : setLocation("/profile")
          }
          className="rounded-full"
        >
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-black ml-2">
          {activeSection ? (activeEntry?.title ?? "Settings") : "Settings"}
        </h1>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4">
        {!activeSection ? (
          /* Section list */
          <div className="space-y-2">
            {sections.map((section) => (
              <Button
                key={section.id}
                variant="ghost"
                className="w-full flex items-center justify-between p-4 h-auto text-sm hover:bg-muted/50 transition-colors rounded-xl"
                onClick={() => {
                  if (section.id === "delete-account") {
                    setActiveSection("delete-account");
                  } else {
                    setActiveSection(section.id);
                  }
                }}
              >
                <div className="flex items-center gap-3">
                  <section.icon className="w-4 h-4 text-muted-foreground" />
                  <span>{section.title}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </Button>
            ))}
          </div>
        ) : (
          /* Active subsection */
          <div className="py-2">
            {CurrentComponent && (
              <CurrentComponent userId={currentUser.id} />
            )}

            {activeSection === "delete-account" && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold">Delete Account</h2>
                <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-4">
                  <p className="text-sm text-destructive font-bold mb-1">
                    This cannot be undone.
                  </p>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Deleting your account will permanently remove your profile,
                    transaction history, goodwill score, and benevolence wallet
                    balance. Scheduled payments will be cancelled. This action
                    is irreversible and cannot be recovered.
                  </p>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Under GDPR/CCPA regulations, you have the right to request
                  deletion of your personal data. Your data will be removed
                  within 30 days of confirmation. To request deletion, contact:
                </p>
                <a
                  href="mailto:privacy@niakofa.community?subject=Account%20Deletion%20Request"
                  className="block bg-card border border-border rounded-xl p-3 text-sm text-primary hover:border-primary/50 transition-colors"
                >
                  privacy@niakofa.community
                </a>
                <Button
                  variant="destructive"
                  className="w-full"
                  onClick={() => {
                    toast({
                      title: "Deletion request submitted",
                      description:
                        "You will receive a confirmation email within 24 hours.",
                    });
                  }}
                >
                  Request Deletion
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
