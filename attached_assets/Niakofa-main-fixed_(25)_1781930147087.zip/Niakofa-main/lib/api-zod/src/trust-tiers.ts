export type TrustTier = "member" | "verified" | "trusted" | "elite" | "anchor";

/**
 * Single source of truth for trust tier thresholds. Previously this exact
 * logic was hand-duplicated in routes/leaderboard.ts (backend) and
 * components/TrustTierBadge.tsx (frontend) with no shared definition —
 * changing one without the other silently desyncs tier labels between the
 * leaderboard API and the badge UI.
 */
export function getTrustTier(trustScore: number, helpCount: number): TrustTier {
  if (helpCount >= 50 && trustScore >= 97) return "anchor";
  if (helpCount >= 30 && trustScore >= 95) return "elite";
  if (helpCount >= 15 && trustScore >= 90) return "trusted";
  if (helpCount >= 5 || trustScore >= 85) return "verified";
  return "member";
}
