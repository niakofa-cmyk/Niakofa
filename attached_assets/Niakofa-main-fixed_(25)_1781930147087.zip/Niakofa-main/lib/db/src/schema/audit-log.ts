import { pgTable, serial, integer, text, jsonb, timestamp, index } from "drizzle-orm/pg-core";

/**
 * Append-only record of every admin action taken on the platform.
 *
 * Previously there was no durable trail of who reviewed which report, who
 * banned/warned a user, who activated crisis mode, or who triggered a manual
 * Stripe payout — only scattered logger.warn() calls that vanish once log
 * retention expires. Once real money and multiple jurisdictions are
 * involved, "who did what, when, and why" needs to be queryable from the
 * database itself, not reconstructed from logs after the fact.
 */
export const auditLogTable = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  admin_user_id: integer("admin_user_id").notNull(),
  action: text("action").notNull(), // e.g. "report_review", "user_moderation", "crisis_activate", "manual_payout"
  target_type: text("target_type"), // e.g. "report", "user", "request"
  target_id: integer("target_id"),
  details: jsonb("details"), // arbitrary structured context (old/new values, amounts, notes)
  created_at: timestamp("created_at").defaultNow().notNull(),
}, (t) => [
  index("audit_log_admin_user_id_idx").on(t.admin_user_id),
  index("audit_log_action_idx").on(t.action),
  index("audit_log_created_at_idx").on(t.created_at),
]);

export type AuditLogEntry = typeof auditLogTable.$inferSelect;
export type InsertAuditLogEntry = typeof auditLogTable.$inferInsert;
