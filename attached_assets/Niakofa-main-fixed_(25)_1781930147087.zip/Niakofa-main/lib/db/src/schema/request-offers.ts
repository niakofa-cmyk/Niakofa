import { pgTable, serial, integer, text, timestamp, index } from "drizzle-orm/pg-core";

/**
 * One row per exclusive offer sent to a candidate helper for a request.
 *
 * Dispatch flow: when a request is created (or a prior offer expires/declines),
 * the dispatch worker picks the best untried candidate and creates a "pending"
 * offer with a short expiry. The targeted helper gets a push + WS event and a
 * short window to accept or decline. If they don't respond in time, the offer
 * expires and the worker cascades to the next candidate. The request always
 * remains visible and claimable on the public map throughout — dispatch is a
 * fast-path nudge to the best candidate, not a replacement for the existing
 * public claim flow, which still works as a fallback once dispatch is
 * exhausted (or immediately, since either path can win the underlying atomic
 * claim on the request row).
 */
export const requestOffersTable = pgTable("request_offers", {
  id: serial("id").primaryKey(),
  request_id: integer("request_id").notNull(),
  helper_id: integer("helper_id").notNull(),
  // pending | accepted | declined | expired | superseded
  status: text("status").notNull().default("pending"),
  sequence: integer("sequence").notNull().default(1), // Nth offer made for this request
  offered_at: timestamp("offered_at").defaultNow().notNull(),
  expires_at: timestamp("expires_at").notNull(),
  responded_at: timestamp("responded_at"),
}, (t) => [
  index("request_offers_request_id_idx").on(t.request_id),
  index("request_offers_helper_id_idx").on(t.helper_id),
  index("request_offers_status_expires_idx").on(t.status, t.expires_at),
]);

export type RequestOffer = typeof requestOffersTable.$inferSelect;
export type InsertRequestOffer = typeof requestOffersTable.$inferInsert;
