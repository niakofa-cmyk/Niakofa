import { pgTable, text, jsonb, timestamp } from "drizzle-orm/pg-core";

/**
 * Durable key-value store for singleton server state that must survive
 * restarts and be consistent across multiple instances — e.g. crisis mode.
 *
 * Previously, crisis mode lived in a plain `let` module variable in
 * crisis.ts. That meant a redeploy or restart during an active emergency
 * silently reset the banner to "inactive" with no record of it ever having
 * happened, and a second server instance would never see an activation
 * made on the first. This table fixes both problems.
 */
export const systemStateTable = pgTable("system_state", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
});

export type SystemState = typeof systemStateTable.$inferSelect;
export type InsertSystemState = typeof systemStateTable.$inferInsert;
