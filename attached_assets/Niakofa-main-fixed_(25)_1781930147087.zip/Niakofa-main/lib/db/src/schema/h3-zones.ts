import { pgTable, text, integer, boolean, real, timestamp, index } from "drizzle-orm/pg-core";

/**
 * One row per H3 cell (resolution 8, ~0.46 km² hexagons) that has had any
 * request or helper activity. A cell becomes an "active zone" — eligible for
 * zone-based dispatch instead of radius-based — only once it sustains real
 * density, and only flips back off after sustaining real low density. This
 * table is intentionally simple: one H3 cell IS one zone. Clustering
 * adjacent cells into larger named zones (e.g. "Downtown") is a real future
 * enhancement but adds a second layer of aggregation that isn't needed to
 * get the actual hybrid-dispatch mechanism working correctly first.
 *
 * Hysteresis / anti-flapping fields:
 *   - is_active_zone only flips when a threshold is crossed AND enough time
 *     has passed since the last flip (last_state_change_at + MIN_DWELL_MS).
 *   - Activation and deactivation use DIFFERENT thresholds (deactivation is
 *     meaningfully lower than activation) — see zone-activation-worker.ts.
 * Both protections exist specifically to prevent the "threshold flapping"
 * failure mode called out in the hybrid dispatch proposal: a cell hovering
 * right at one single threshold value flipping active/inactive every worker
 * cycle, which would be a confusing, inconsistent experience for helpers.
 */
export const h3CellsTable = pgTable("h3_cells", {
  h3_id: text("h3_id").primaryKey(),
  resolution: integer("resolution").notNull().default(8),
  centroid_lat: real("centroid_lat").notNull(),
  centroid_lng: real("centroid_lng").notNull(),

  is_active_zone: boolean("is_active_zone").notNull().default(false),
  // 'busy' | 'moderate' | 'slow' — informational display label, free to
  // update every cycle regardless of hysteresis (only the active/inactive
  // transition itself needs flap protection, not this label).
  zone_status: text("zone_status").notNull().default("slow"),

  request_count_24h: integer("request_count_24h").notNull().default(0),
  helper_count_now: integer("helper_count_now").notNull().default(0),

  last_calculated_at: timestamp("last_calculated_at").defaultNow().notNull(),
  // Timestamp of the last is_active_zone flip — the dwell-time anchor.
  last_state_change_at: timestamp("last_state_change_at").defaultNow().notNull(),
}, (t) => [
  index("h3_cells_is_active_zone_idx").on(t.is_active_zone),
]);

export type H3Cell = typeof h3CellsTable.$inferSelect;
export type InsertH3Cell = typeof h3CellsTable.$inferInsert;
