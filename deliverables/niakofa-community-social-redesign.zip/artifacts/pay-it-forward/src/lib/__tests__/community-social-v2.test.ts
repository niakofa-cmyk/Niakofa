import { describe, test } from "node:test";
import * as assert from "node:assert";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

describe("Community Social V2 Architecture", () => {
  const communityFile = fs.readFileSync(
    path.join(__dirname, "../../pages/community.tsx"),
    "utf8"
  );
  
  const shellFile = fs.readFileSync(
    path.join(__dirname, "../../components/community/CommunitySocialShell.tsx"),
    "utf8"
  );

  const discoveryFile = fs.readFileSync(
    path.join(__dirname, "../../components/community/CommunityDiscoveryViews.tsx"),
    "utf8"
  );
  
  const moreFile = fs.readFileSync(
    path.join(__dirname, "../../components/community/CommunityMoreDirectory.tsx"),
    "utf8"
  );

  const appFile = fs.readFileSync(
    path.join(__dirname, "../../App.tsx"),
    "utf8"
  );

  const feedFile = fs.readFileSync(
    path.join(__dirname, "../../components/community/HubCommunityFeedPanel.tsx"),
    "utf8"
  );

  test("Community keeps only Feed and Requests as persistent content tabs", () => {
    const match = shellFile.match(/const contentNavItems = \[(.*?)\];/s);
    assert.ok(match);
    const navItems = match[1];
    assert.match(navItems, /key: "home".*label: "Feed"/);
    assert.match(navItems, /key: "requests".*label: "Requests"/);
    const itemCount = (navItems.match(/\{ key:/g) || []).length;
    assert.equal(itemCount, 2, "Only Feed and Requests should remain persistent");
    assert.doesNotMatch(shellFile, /primaryNavItems/);
    assert.match(shellFile, /aria-label="More Community destinations"/);
  });

  test("Home places compact Stories between its composer and feed", () => {
    assert.match(communityFile, /<HubCommunityFeedPanel/);
    assert.match(communityFile, /socialHomeMode={true}/);
    assert.match(communityFile, /homeInterstitial={\(/);
    assert.match(communityFile, /<CommunityStoriesExperience[\s\S]*?compact/);
    assert.match(feedFile, /socialHomeMode && homeInterstitial/);
  });

  test("Home composer starts as a dedicated collapsed social bar", () => {
    assert.match(feedFile, /id="hub-post-composer-trigger"/);
    assert.match(feedFile, /What's on your mind\?/);
    assert.match(feedFile, /composerExpanded &&/);
  });

  test("Stories section includes CommunityStoriesExperience", () => {
    assert.match(communityFile, /normalizedSection === "stories".*?<CommunityStoriesExperience/s);
  });

  test("More directory does not contain fake links like /impact or /civic-resources", () => {
    assert.doesNotMatch(moreFile, /href: "\/impact"/);
    assert.doesNotMatch(moreFile, /href: "\/civic-resources"/);
  });

  test("Default Hub fetch uses /api/community/my-hub", () => {
    assert.match(communityFile, /fetch\(\`\$\{base\}\/api\/community\/my-hub\`/);
  });

  test("MediaDiscoveryView fetches media with authHeaders", () => {
    assert.match(discoveryFile, /fetch\(url, \{ headers: authHeaders\(\)/);
  });

  test("Community uses the app-wide icon navigation instead of a duplicate five-item rail", () => {
    assert.match(appFile, /hideGlobalAppNav = isMessages \|\| isDiasporaMessages/);
    assert.doesNotMatch(appFile, /hideGlobalAppNav = .*isCommunitySurface/);
    assert.match(appFile, /showShell && !hideGlobalAppNav && <BottomNav \/>/);
    assert.match(appFile, /showShell && !hideGlobalAppNav && <DesktopSidebar \/>/);
    assert.doesNotMatch(shellFile, /Community mobile navigation/);
  });
});
