import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useLocation, useSearch, useRoute } from "wouter";
import { useIsAnimationSuppressed } from "@/hooks/useAnimationPreference";
import { useNiaStory } from "@/hooks/useNiaStory";
import { authHeaders } from "@/lib/auth";
import { useAppContext } from "@/lib/AppContext";
import { Heart, X, Send, Globe, Mic, MicOff, Loader2, CheckCircle2, PlusCircle, ClipboardList } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useWebSocket } from "@/lib/useWebSocket";
import RequestsCenter from "@/components/RequestsCenter";
import { CommunitySpiralsTab } from "@/components/CommunitySpiralsTab";
import HubCommunityFeedPanel from "@/components/community/HubCommunityFeedPanel";
import { CommunityStoriesExperience } from "@/components/community/CommunityStoriesExperience";
import { CommunitySocialShell, type CommunityNavKey } from "@/components/community/CommunitySocialShell";
import { CommunityMoreDirectory } from "@/components/community/CommunityMoreDirectory";
import { PeopleDiscoveryView, HubsDiscoveryView, MediaDiscoveryView } from "@/components/community/CommunityDiscoveryViews";
import { SkillsMarketplaceTab } from "@/components/community/SkillsMarketplaceTab";

const COMMUNITY_SECTIONS = new Set<CommunityNavKey>([
  "home",
  "people",
  "hubs",
  "stories",
  "more",
  "requests",
  "services",
  "circles",
  "media",
]);

interface GratitudePost {
  id: number;
  author_name: string;
  author_avatar?: string | null;
  diaspora_hub_id?: number | null;
  helper_name?: string | null;
  message: string;
  request_title?: string | null;
  likes: number;
  created_at: string;
}

// ── Phase 7c: NiaStoryModal ────────────────────────────────────────────────
function NiaStoryModal({ onClose, onPosted }: { onClose: () => void; onPosted: (story: string) => void }) {
  const { currentUser } = useAppContext();
  const suppressed = useIsAnimationSuppressed();
  const userName = currentUser?.name ?? "A neighbor";
  const { state, story, error, transcript, startRecording, stopAndSubmit, reset } = useNiaStory(userName);

  const [posting, setPosting] = React.useState(false);
  const [postError, setPostError] = React.useState<string | null>(null);

  const handlePost = async () => {
    if (!story || !currentUser) return;
    setPosting(true);
    setPostError(null);
    try {
      const res = await fetch("/api/gratitude", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({
          message: story.story,
        }),
      });
      if (!res.ok) {
        const data: unknown = await res.json().catch(() => ({}));
        const message = typeof data === "object" && data !== null && "error" in data
          && typeof data.error === "string"
          ? data.error
          : `Post failed (${res.status})`;
        throw new Error(message);
      }
      onPosted(story.story);
      onClose();
    } catch (err: unknown) {
      setPostError(err instanceof Error ? err.message : "Failed to post story. Try again.");
    } finally {
      setPosting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-lg bg-background rounded-t-3xl p-6 pb-10 space-y-4"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="font-black text-base">Share Your Story</div>
            <div className="text-xs text-muted-foreground">Nia will polish your words into a community post</div>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-muted"><X className="w-4 h-4" /></button>
        </div>

        {state === "idle" && (
          <button
            onClick={startRecording}
            className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-2xl py-4 font-bold text-sm"
          >
            <Mic className="w-5 h-5" /> Tap to Record
          </button>
        )}

        {state === "recording" && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-primary font-semibold">
              <span className={`w-2 h-2 rounded-full bg-red-500${suppressed ? "" : " animate-pulse"}`} />
              Recording… speak naturally
            </div>
            {transcript && <p className="text-xs text-muted-foreground italic leading-relaxed">"{transcript}"</p>}
            <button
              onClick={() => stopAndSubmit()}
              className="w-full flex items-center justify-center gap-2 bg-muted border border-border rounded-2xl py-3 font-bold text-sm"
            >
              <MicOff className="w-4 h-4" /> Done — let Nia craft it
            </button>
          </div>
        )}

        {state === "processing" && (
          <div className="flex items-center justify-center gap-2 py-6 text-muted-foreground text-sm">
            <Loader2 className="w-5 h-5 animate-spin" /> Nia is crafting your story…
          </div>
        )}

        {state === "done" && story && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs text-green-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" /> Nia crafted your story
            </div>
            <div className="bg-muted rounded-2xl p-4 text-sm leading-relaxed text-foreground">
              "{story.story}"
            </div>
            <div className="flex gap-2">
              <button
                onClick={reset}
                className="flex-1 border border-border rounded-2xl py-3 text-sm font-bold text-muted-foreground hover:bg-muted"
              >
                Re-record
              </button>
              <button
                onClick={handlePost}
                disabled={posting}
                className="flex-2 bg-primary text-primary-foreground rounded-2xl px-6 py-3 text-sm font-bold flex items-center gap-2 disabled:opacity-70"
              >
                {posting ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Posting…</>
                ) : (
                  <><Send className="w-4 h-4" /> Post to Community</>
                )}
              </button>
              {postError && <p className="text-xs text-destructive mt-1">{postError}</p>}
            </div>
          </div>
        )}

        {state === "error" && (
          <div className="space-y-3">
            <div className="text-xs text-destructive">{error ?? "Something went wrong."}</div>
            <button onClick={reset} className="w-full border border-border rounded-2xl py-3 text-sm font-bold">Try Again</button>
          </div>
        )}
      </div>
    </div>
  );
}


export default function CommunityScreen() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const [match, params] = useRoute("/community/:section");
  const requestedSection = match && params?.section ? params.section : "home";
  const compatibleSection = requestedSection === "spirals" ? "circles" : requestedSection;
  const normalizedSection: CommunityNavKey = COMMUNITY_SECTIONS.has(compatibleSection as CommunityNavKey)
    ? compatibleSection as CommunityNavKey
    : "home";

  const [showNiaStory, setShowNiaStory] = useState(false);
  const [createSheetOpen, setCreateSheetOpen] = useState(false);
  const [storyComposerSignal, setStoryComposerSignal] = useState(0);

  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());
  const [posts, setPosts] = useState<GratitudePost[]>([]);
  const [postsLoading, setPostsLoading] = useState(true);

  const [communitySearch, setCommunitySearch] = useState("");

  const base = (import.meta.env.BASE_URL ?? "/").replace(/\/$/, "");
  const hubContextId = useMemo(() => {
    const value = Number(new URLSearchParams(search).get("hubId"));
    return Number.isSafeInteger(value) && value > 0 ? value : null;
  }, [search]);

  const [defaultHubId, setDefaultHubId] = useState<number | null>(null);
  const [defaultHubResolved, setDefaultHubResolved] = useState(hubContextId !== null);

  useEffect(() => {
    if (hubContextId !== null) {
      setDefaultHubResolved(true);
      return;
    }
    fetch(`${base}/api/community/my-hub`, { headers: authHeaders() })
      .then(r => r.json())
      .then((data: unknown) => {
        if (data && typeof data === "object" && "hub_id" in data && typeof data.hub_id === "number") {
          setDefaultHubId(data.hub_id);
        }
      })
      .catch(() => {})
      .finally(() => setDefaultHubResolved(true));
  }, [base, hubContextId]);

  const effectiveHubId = hubContextId ?? defaultHubId;

  const { niaEnabled } = useAppContext();

  const gratitudeFeedUrl = `${base}/api/gratitude${effectiveHubId ? `?hub_id=${effectiveHubId}` : ""}`;

  useEffect(() => {
    if (normalizedSection !== "stories") return;
    setPostsLoading(true);
    fetch(gratitudeFeedUrl, { headers: authHeaders() })
      .then(r => r.json())
      .then((data: unknown) => {
        if (Array.isArray(data)) setPosts(data as GratitudePost[]);
      })
      .catch(() => {})
      .finally(() => setPostsLoading(false));
  }, [gratitudeFeedUrl, normalizedSection]);

  useWebSocket("gratitude_created", useCallback((event) => {
    if (normalizedSection !== "stories") return;
    const payload = event.payload as GratitudePost;
    if (effectiveHubId && payload.diaspora_hub_id !== effectiveHubId) return;
    setPosts(prev => [payload, ...prev]);
  }, [effectiveHubId, normalizedSection]));

  const toggleLike = (id: number) => {
    setLikedPosts(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleCreate = () => {
    if (normalizedSection === "home") {
      const composerTrigger = document.getElementById("hub-post-composer-trigger");
      if (composerTrigger) {
        composerTrigger.click();
        document.getElementById("hub-post-composer-textarea")?.focus();
        composerTrigger.scrollIntoView({ behavior: "smooth", block: "center" });
      } else {
        setCreateSheetOpen(true);
      }
    } else {
      setCreateSheetOpen(true);
    }
  };

  return (
    <CommunitySocialShell
      active={normalizedSection as CommunityNavKey}
      onNavigate={(key) => setLocation(key === "home" ? "/community" : `/community/${key}`)}
      onRoute={setLocation}
      onCreate={handleCreate}
      onSearch={setCommunitySearch}
      searchValue={communitySearch}
    >
      <div className="space-y-3">
        {normalizedSection === "home" && (
          <div className="space-y-3">
            {defaultHubResolved && effectiveHubId !== null && (
              <HubCommunityFeedPanel
                hubId={effectiveHubId}
                socialHomeMode={true}
                onOpenStoryComposer={() => setStoryComposerSignal(prev => prev + 1)}
                homeInterstitial={(
                  <CommunityStoriesExperience
                    hubId={effectiveHubId}
                    openComposerSignal={storyComposerSignal}
                    compact
                  />
                )}
              />
            )}
            {defaultHubResolved && effectiveHubId === null && (
              <>
                <CommunityStoriesExperience
                  hubId={null}
                  openComposerSignal={storyComposerSignal}
                  compact
                />
                <div className="border-y border-border bg-card p-6 text-center sm:rounded-2xl sm:border">
                 <Globe className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
                 <h3 className="text-lg font-black">No Hub Selected</h3>
                 <p className="text-sm text-muted-foreground mt-1">Join a Hub in Diaspora to see community posts here.</p>
               </div>
              </>
            )}
          </div>
        )}

        {normalizedSection === "people" && <PeopleDiscoveryView hubId={effectiveHubId} />}

        {normalizedSection === "hubs" && <HubsDiscoveryView hubId={effectiveHubId} />}

        {normalizedSection === "stories" && (
          <div className="space-y-4">
            <CommunityStoriesExperience hubId={effectiveHubId} openComposerSignal={storyComposerSignal} />
            <div className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground">Gratitude &amp; Stories</h3>
              {niaEnabled === true ? (
                <button
                  onClick={() => setShowNiaStory(true)}
                  className="flex items-center gap-1.5 text-xs font-bold text-primary bg-primary/10 hover:bg-primary/20 px-3 py-1.5 rounded-full transition-colors"
                >
                  <Mic className="w-3.5 h-3.5" /> Share with Nia
                </button>
              ) : niaEnabled === false ? (
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground/50 px-3 py-1.5 rounded-full cursor-default select-none" title="Nia AI is currently resting — share your story in text below">
                  <Mic className="w-3.5 h-3.5" /> Nia resting
                </span>
              ) : null}
            </div>

            {postsLoading ? (
              <div className="flex justify-center items-center py-10">
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }}>
                  <Heart className="w-6 h-6 text-primary/40" />
                </motion.div>
              </div>
            ) : posts.length === 0 ? (
              <div className="flex flex-col items-center gap-3 py-10 text-center">
                <Heart className="w-8 h-8 text-muted-foreground/30" />
                <div className="text-sm text-muted-foreground leading-relaxed">
                  No gratitude posts yet.<br />
                  <span className="text-primary font-semibold">Complete a request</span> to add the first one!
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence initial={false}>
                  {posts.map(post => (
                    <motion.div
                      key={post.id}
                      initial={{ opacity: 0, y: -16 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-card border border-border rounded-2xl p-4"
                    >
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center border border-border shrink-0">
                          <span className="text-sm font-black text-muted-foreground">
                            {post.author_name[0]?.toUpperCase() ?? "?"}
                          </span>
                        </div>
                        <div>
                          <div className="font-bold text-sm">{post.author_name}</div>
                          <div className="text-[10px] text-muted-foreground flex items-center gap-1 flex-wrap">
                            {post.helper_name && (
                              <>
                                <span className="text-primary font-medium">Thanks to {post.helper_name}</span>
                                <span>·</span>
                              </>
                            )}
                            <span>{new Date(post.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
                          </div>
                        </div>
                      </div>
                      {post.request_title && (
                        <div className="text-[10px] font-semibold text-primary/80 bg-primary/10 rounded-lg px-2 py-1 mb-2.5 inline-block max-w-full truncate">
                          {post.request_title}
                        </div>
                      )}
                      <p className="text-sm text-muted-foreground leading-relaxed mb-3">"{post.message}"</p>
                      <button
                        onClick={() => toggleLike(post.id)}
                        className={`flex items-center gap-1.5 text-xs transition-colors ${likedPosts.has(post.id) ? "text-primary" : "text-muted-foreground hover:text-primary"}`}
                      >
                        <Heart className={`w-4 h-4 ${likedPosts.has(post.id) ? "fill-current" : ""}`} />
                        {post.likes + (likedPosts.has(post.id) ? 1 : 0)}
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
          </div>
        )}

        {normalizedSection === "requests" && <RequestsCenter embedded />}
        {normalizedSection === "circles" && <CommunitySpiralsTab />}
        {normalizedSection === "media" && <MediaDiscoveryView hubId={effectiveHubId} />}
        {normalizedSection === "more" && <CommunityMoreDirectory />}

        {/* Legacy redirect logic or additional sections can be added here if needed */}
        {normalizedSection === "services" && <SkillsMarketplaceTab />}

      </div>

      {createSheetOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-6"
          onClick={() => setCreateSheetOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Create in Community"
            className="w-full max-w-md rounded-t-3xl border border-border bg-background p-5 shadow-2xl sm:rounded-3xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-black">Create in Community</p>
                <p className="mt-0.5 text-xs text-muted-foreground">Share an update, Story, or request for help.</p>
              </div>
              <button
                type="button"
                onClick={() => setCreateSheetOpen(false)}
                aria-label="Close create menu"
                className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-4 grid gap-2">
              <button
                type="button"
                onClick={() => {
                  setCreateSheetOpen(false);
                  setLocation("/community");
                  window.setTimeout(() => document.getElementById("hub-post-composer-trigger")?.click(), 0);
                }}
                className="flex items-center gap-3 rounded-2xl border border-border p-3 text-left hover:border-primary/50 hover:bg-muted"
              >
                <Send className="h-5 w-5 text-primary" />
                <span><span className="block text-sm font-bold">Post</span><span className="block text-xs text-muted-foreground">Share with your Hub feed</span></span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setCreateSheetOpen(false);
                  setLocation("/community");
                  setStoryComposerSignal((signal) => signal + 1);
                }}
                className="flex items-center gap-3 rounded-2xl border border-border p-3 text-left hover:border-primary/50 hover:bg-muted"
              >
                <PlusCircle className="h-5 w-5 text-primary" />
                <span><span className="block text-sm font-bold">Story</span><span className="block text-xs text-muted-foreground">Share a photo, video, or moment</span></span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setCreateSheetOpen(false);
                  setLocation("/request/new");
                }}
                className="flex items-center gap-3 rounded-2xl border border-border p-3 text-left hover:border-primary/50 hover:bg-muted"
              >
                <ClipboardList className="h-5 w-5 text-primary" />
                <span><span className="block text-sm font-bold">Request</span><span className="block text-xs text-muted-foreground">Ask your community for help</span></span>
              </button>
            </div>
          </div>
        </div>
      )}

      {showNiaStory && (
        <NiaStoryModal
          onClose={() => setShowNiaStory(false)}
          onPosted={(_story: string) => {
            setShowNiaStory(false);
            if (normalizedSection === "stories") {
              setPostsLoading(true);
              fetch(gratitudeFeedUrl, { headers: authHeaders() })
                .then(r => r.json())
                .then((data: unknown) => { if (Array.isArray(data)) setPosts(data as GratitudePost[]); })
                .catch(() => {})
                .finally(() => setPostsLoading(false));
            }
          }}
        />
      )}
    </CommunitySocialShell>
  );
}
