import { useState, type ReactNode } from "react";
import { Menu, MessageCircle, Plus, Search } from "lucide-react";

export type CommunityNavKey =
  | "home"
  | "people"
  | "hubs"
  | "stories"
  | "more"
  | "requests"
  | "services"
  | "circles"
  | "media";

interface CommunitySocialShellProps {
  active: CommunityNavKey;
  onNavigate: (key: CommunityNavKey) => void;
  onRoute: (path: string) => void;
  onCreate: () => void;
  onSearch: (value: string) => void;
  searchValue?: string;
  children: ReactNode;
}

const contentNavItems = [
  { key: "home" as const, label: "Feed" },
  { key: "requests" as const, label: "Requests" },
];

export function CommunitySocialShell({
  active,
  onNavigate,
  onRoute,
  onCreate,
  onSearch,
  searchValue = "",
  children,
}: CommunitySocialShellProps) {
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  return (
    <div className="min-h-[100dvh] bg-muted/20 pb-24 text-foreground lg:pb-8">
      <header className="sticky top-0 z-30 border-b border-border/80 bg-background/95 backdrop-blur-xl">
        <div className="mx-auto flex h-14 max-w-[680px] items-center justify-between gap-3 px-4 pl-16 lg:pl-4">
          <div className="flex min-w-0 items-center">
            <button
              type="button"
              onClick={() => onNavigate("home")}
              className="truncate text-left text-2xl font-black tracking-[-0.04em] text-primary"
              aria-label="Go to Community home"
            >
              niakofa
            </button>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={onCreate}
              aria-label="Create"
              className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-muted/70"
            >
              <Plus className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => setMobileSearchOpen((open) => !open)}
              aria-label={mobileSearchOpen ? "Close Community search" : "Search Community"}
              aria-expanded={mobileSearchOpen}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-muted/70"
            >
              <Search className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => onRoute("/messages")}
              aria-label="Open messages"
              className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-muted/70"
            >
              <MessageCircle className="h-5 w-5" />
            </button>
          </div>
        </div>
        {mobileSearchOpen && (
          <div className="mx-auto max-w-[680px] px-4 pb-3">
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={searchValue}
                onChange={(event) => onSearch(event.target.value)}
                placeholder="Search Community"
                aria-label="Search Community"
                autoFocus
                className="h-10 w-full rounded-full border border-border bg-muted/70 pl-10 pr-4 text-sm outline-none transition focus:border-primary focus:bg-background"
              />
            </label>
          </div>
        )}
        <nav className="mx-auto flex h-11 max-w-[680px] items-stretch border-t border-border/70 px-4" aria-label="Community content">
          {contentNavItems.map((item) => {
            const selected = active === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => onNavigate(item.key)}
                aria-current={selected ? "page" : undefined}
                className={`relative flex flex-1 items-center justify-center text-sm font-bold transition ${
                  selected ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {item.label}
                {selected && <span className="absolute inset-x-5 bottom-0 h-0.5 rounded-full bg-primary" />}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => onNavigate("more")}
            aria-label="More Community destinations"
            aria-current={active !== "home" && active !== "requests" ? "page" : undefined}
            className={`flex w-14 items-center justify-center transition ${
              active !== "home" && active !== "requests" ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Menu className="h-5 w-5" />
          </button>
        </nav>
      </header>

      <main className="mx-auto w-full max-w-[680px] min-w-0 py-3 sm:px-4">
        {children}
      </main>
    </div>
  );
}
