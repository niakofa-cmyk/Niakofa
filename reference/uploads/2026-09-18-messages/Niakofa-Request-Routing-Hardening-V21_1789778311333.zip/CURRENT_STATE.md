# Current State — 2026-09-18

## GitHub main

Latest commits inspected:

1. `3f589583beb2f1a93d9f4b5cddc6a16a895e6797` — Document ESM focused test invocation
2. `1c4c105a37754125d025782b9741cda3bd2cc817` — Fix requester tracking and helper navigation flows
3. `1c75215daf52285a0d7e98ae37ec5f2ca44ea9f1` — Document mobile attachment acceptance boundary
4. `be585a06ab235ad0a97382cbefaec48a71b9eb45` — Add private direct message attachments

## Railway

Production service:
- project: `precious-abundance`
- service: `zesty-ambition`
- latest deployment: SUCCESS
- deployed commit: `3f589583beb2f1a93d9f4b5cddc6a16a895e6797`

## Request routing

Canonical role-aware paths:
- helper: `/request/:id`
- requester: `/request/:id/track`
- observer/open detail: `/request/:id/view`

## Navigation API

`GET /api/navigation/route`
- authentication required;
- driving/walking/cycling allowlist;
- coordinate range validation;
- <=15m arrival short-circuit;
- Mapbox Directions integration;
- route cache;
- circuit breaker;
- traffic-aware driving mode.

## Testing limitation

The connected tools do not expose disposable authenticated requester/helper sessions. Therefore a production mutation test was intentionally not performed.

Do not interpret Railway SUCCESS as a browser-level two-account E2E pass.
