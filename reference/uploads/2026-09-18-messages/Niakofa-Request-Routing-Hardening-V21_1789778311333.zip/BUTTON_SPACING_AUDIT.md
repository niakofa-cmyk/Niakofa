# Button / Tab Spacing Audit

Current Request Center implementation already uses a consistent mobile-safe action model:

- tabs: `min-h-11`, `px-4`, `gap-2`, horizontal scrolling;
- card actions: `grid`, `gap-2`, `sm:grid-cols-2`;
- action buttons: `min-h-11`, centered icon/text;
- requester action: `Track helper`;
- helper action: `Start navigation`;
- secondary helper detail action: `Open navigation`.

This is preferable to putting multiple full-width buttons in one crowded horizontal row on phones.

Recommended invariant:
- minimum interactive height: 44px;
- horizontal/vertical gap: at least 8px;
- never allow two primary actions to visually merge;
- keep requester tracking as one obvious primary action;
- keep helper navigation as one obvious primary action;
- use a second action only when it performs a genuinely different task.

No blind spacing rewrite is included because the current main implementation already meets these constraints.
