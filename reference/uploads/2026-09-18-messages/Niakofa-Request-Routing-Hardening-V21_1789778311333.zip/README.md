# Niakofa Request / Helper Routing Hardening V21

This package is based on the current Niakofa `main` state inspected on 2026-09-18.

## Important: previous PR is superseded

The earlier PR #78 is NOT needed anymore. Current `main` already contains the equivalent requester/helper navigation fix in commit `1c4c105a37754125d025782b9741cda3bd2cc817` and that commit is already deployed to Railway through the subsequent `3f589583beb2f1a93d9f4b5cddc6a16a895e6797` deployment chain.

PR #78 was closed without merging.

## Current canonical flow

Requester:
`/request/:id/view` -> `/request/:id/track`

Helper:
`/request/:id/view` -> `/request/:id` -> en-route -> arrived -> complete

Request Center role routing:
- assigned helper + active request -> `/request/:id`
- requester + active request -> `/request/:id/track`
- everyone else -> `/request/:id/view`
- open requests remain on detail/view

## Included drop-in code

- `request-navigation.ts`
- `eta.ts`
- `request-navigation.test.ts`
- `multi-city-yard-work.contract.test.mjs`
- `BUTTON_SPACING_AUDIT.md`
- `CURRENT_STATE.md`

The package deliberately does not contain credentials, production database dumps, or secrets.

## What was actually verified

Repository inspection confirms:
- request lifecycle API routes exist;
- role-aware Request Center navigation is implemented;
- requester tracking route exists;
- helper active navigation route exists;
- `/api/navigation/route` is authenticated;
- routing profiles are allowlisted;
- zero-distance / <=15m routes short-circuit safely;
- coordinate bounds are validated;
- ETA parsing supports minute/hour formats;
- `yard_work` exists in the request creation flow.

Railway:
- latest production deployment for `main` is SUCCESS;
- latest deployed commit is `3f589583beb2f1a93d9f4b5cddc6a16a895e6797`.

A real two-account production request mutation was NOT performed. No disposable authenticated requester/helper sessions were exposed to the connected tools, and creating production requests without disposable test accounts would create real user data.

The multi-city test included here is therefore a deterministic contract test of role routing and request-category coverage, not a claim that real production requests were created in those cities.

## Apply

If your current checkout already matches current `main`, these files are reference/hardening artifacts and do not need to replace existing code.

If your checkout is behind current `main`, update from GitHub first. Do not merge the old PR #78.
