export function parseEtaSeconds(etaText: string): number {
  const hourMatch = etaText.match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?|h)(?=\s|\d|$)/i);
  const minuteMatch = etaText.match(/(\d+(?:\.\d+)?)\s*(?:minutes?|mins?|m)(?=\s|$)/i);

  const hours = hourMatch ? Number.parseFloat(hourMatch[1]) : 0;
  const minutes = minuteMatch ? Number.parseFloat(minuteMatch[1]) : 0;
  const seconds = Math.round(hours * 3600 + minutes * 60);

  return Number.isFinite(seconds) ? seconds : 0;
}
