const ACTIVE_REQUEST_STATUSES = new Set(["claimed", "en_route", "arrived"]);

export type RequestNavigationInput = {
  id: number;
  status: string;
  requesterId: number;
  helperId: number | null;
  currentUserId: number;
};

/**
 * Role-aware request navigation:
 * helper -> active job/navigation screen
 * requester -> live helper tracking
 * everyone else -> read-only request detail
 */
export function getRequestNavigationPath({
  id,
  status,
  requesterId,
  helperId,
  currentUserId,
}: RequestNavigationInput): string {
  if (ACTIVE_REQUEST_STATUSES.has(status) && helperId === currentUserId) {
    return `/request/${id}`;
  }

  if (ACTIVE_REQUEST_STATUSES.has(status) && requesterId === currentUserId) {
    return `/request/${id}/track`;
  }

  return `/request/${id}/view`;
}
