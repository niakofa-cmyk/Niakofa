import assert from "node:assert/strict";

const ACTIVE = new Set(["claimed", "en_route", "arrived"]);

function requestPath({ id, status, requesterId, helperId, currentUserId }) {
  if (ACTIVE.has(status) && helperId === currentUserId) return `/request/${id}`;
  if (ACTIVE.has(status) && requesterId === currentUserId) return `/request/${id}/track`;
  return `/request/${id}/view`;
}

const cities = [
  ["Fort Worth", "Dallas"],
  ["Accra", "Kumasi"],
  ["Lagos", "Ibadan"],
  ["Atlanta", "Decatur"],
  ["New York", "Brooklyn"],
];

for (const [requesterCity, helperCity] of cities) {
  const requestId = 1000 + cities.indexOf(cities.find(x => x[0] === requesterCity)) + 1;

  assert.equal(
    requestPath({
      id: requestId,
      status: "en_route",
      requesterId: 700,
      helperId: 900,
      currentUserId: 900,
    }),
    `/request/${requestId}`,
    `${helperCity} helper must open helper navigation for a ${requesterCity} request`,
  );

  assert.equal(
    requestPath({
      id: requestId,
      status: "en_route",
      requesterId: 700,
      helperId: 900,
      currentUserId: 700,
    }),
    `/request/${requestId}/track`,
    `${requesterCity} requester must open live helper tracking`,
  );
}

const allowedRequestCategories = new Set([
  "yard_work",
]);

assert.ok(
  allowedRequestCategories.has("yard_work"),
  "yard_work must remain a supported request category",
);

console.log(
  `PASS: ${cities.length} multi-city yard-work role-routing scenarios`,
);
