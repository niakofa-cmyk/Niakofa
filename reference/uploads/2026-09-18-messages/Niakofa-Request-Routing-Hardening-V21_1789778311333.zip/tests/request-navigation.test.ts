import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { getRequestNavigationPath } from "../src/request-navigation";

const base = {
  id: 42,
  status: "en_route",
  requesterId: 7,
  helperId: 9,
};

describe("request role navigation", () => {
  it("opens live navigation for the assigned helper", () => {
    assert.equal(
      getRequestNavigationPath({ ...base, currentUserId: 9 }),
      "/request/42",
    );
  });

  it("opens live tracking for the requester", () => {
    assert.equal(
      getRequestNavigationPath({ ...base, currentUserId: 7 }),
      "/request/42/track",
    );
  });

  it("uses read-only details for a non-participant", () => {
    assert.equal(
      getRequestNavigationPath({ ...base, currentUserId: 11 }),
      "/request/42/view",
    );
  });

  it("keeps open requests on the detail screen", () => {
    assert.equal(
      getRequestNavigationPath({ ...base, status: "open", currentUserId: 7 }),
      "/request/42/view",
    );
  });

  it("does not give a requester the helper screen", () => {
    assert.notEqual(
      getRequestNavigationPath({ ...base, currentUserId: 7 }),
      "/request/42",
    );
  });
});
