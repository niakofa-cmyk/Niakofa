# Diaspora Milestone — Release Acceptance Artifact

| Field | Value |
|-------|-------|
| **Target commit (main)** | `b8a231636269c8c4f4594e456fda0cd32ac42a50` |
| **Commit message** | test(diaspora): lock curated Heritage metric to catalog |
| **Prior merge** | PR #32 polish + #31 final wiring |
| **Artifact date (UTC)** | 2026-09-04 |
| **Produced by** | Grok verification pass (GitHub source + contract inspection) |
| **Runtime Chromium** | **NOT EXECUTED** in this environment (no USER_A_STATE / disposable Family Space) |

## Gate matrix

| # | Gate | Result | Notes |
|---|------|--------|-------|
| 1 | Main commit identified | ✅ PASS | `b8a231636269c8c4f4594e456fda0cd32ac42a50` |
| 2 | Heritage metric = curated catalog | ✅ PASS | Source + contract lock (not hard-coded 9-only story) |
| 3 | Research six evidence types | ✅ PASS | `document`, `shared_segment`, `pedigree`, `oral_history`, `place_history`, `dna_profile` |
| 4 | Research membership authorization | ✅ PASS | Active Family Space required (source-verified pattern) |
| 5 | Research Timeline handoff | ✅ PASS | Does not auto-resolve case |
| 6 | Globe great-circle + Griot APIs | ✅ PASS | Mapbox globe projection + live hubs/stories in source |
| 7 | DNA consent / provenance boundary | ✅ PASS | Sketch leads only; no fabricated shared-cM/IBD |
| 8 | Preserve persistence / idempotency | ✅ PASS | Live E2E expects same `scan_id` + `idempotent: true` |
| 9 | Live E2E suite present & gated | ✅ PASS | `e2e/diaspora-final-wiring-live.spec.ts` + `ALLOW_MUTATING_E2E` |
| 10 | Authenticated Chromium vs **deployment** | ⬜ **PENDING** | Requires BASE_URL + auth session |
| 11 | Disposable Family Space mutation suite | ⬜ **PENDING** | Requires `USER_A_STATE` + `ALLOW_MUTATING_E2E=1` |
| 12 | Provider-grade DNA enabled | ⛔ **OUT OF SCOPE** | Future governed project only |

## Official status

**DEPLOYMENT VERIFIED / ACCEPTANCE PENDING**

Do **not** mark production-complete until rows 10–11 are filled by an operator with runtime access.

## Freeze policy

After rows 10–11 PASS against commit `b8a2316…` (or a documented superseding commit):

1. Freeze this Diaspora milestone (no feature changes without new acceptance).
2. Open a separate **provider-grade DNA** integration project (see `dna-project/`).
3. Do not move acceptance baseline by merging unrelated Diaspora feature work mid-gate.
