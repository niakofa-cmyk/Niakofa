# Operator runbook — complete acceptance (fill PENDING gates)

## 0. Environment

```bash
export BASE_URL="https://YOUR_DEPLOYED_ORIGIN"   # Railway or prod
export USER_A_STATE="playwright/.auth/disposable-a.json"
export ALLOW_MUTATING_E2E=1
# Optional:
export EXPECTED_COMMIT="b8a231636269c8c4f4594e456fda0cd32ac42a50"
```

Create Playwright storage state for a **disposable** Family Space account only.

## 1. Confirm deployed revision

Prefer exposing commit via `/status` or build meta. If available:

```bash
curl -s "$BASE_URL/status" | tee acceptance-status.json
# Confirm deployed SHA matches EXPECTED_COMMIT (or document the actual SHA)
```

Record **actual deployed SHA** in `RESULTS_TEMPLATE.md` even if it differs.

## 2. Non-mutating Chromium smoke

```bash
npx playwright test e2e/diaspora-journeys.spec.ts  # if present
# Or manual:
# /diaspora, /diaspora/heritage/globe, /diaspora/research,
# /diaspora/preserve, /diaspora/dna, /diaspora/family, /diaspora/tree, /diaspora/timeline
```

Globe checks:
- Mapbox canvas renders **or** explicit missing-token UI (not a white crash)
- Select hub → live hub fields
- Open story → details
- Play audio if `audio_url` present

## 3. Gated mutation suite

```bash
npx playwright test e2e/diaspora-final-wiring-live.spec.ts
```

Covers:
1. Research evidence create with `evidence_type: oral_history` → 201 + type persisted  
2. Preserve same QR twice → identical `scan_id`, `idempotent: true`  
3. DNA opt-in → revoke → status `opted_in: false`

## 4. Extended manual checks (recommended)

| Check | How |
|-------|-----|
| Research survives reload | Create evidence in UI → hard reload → still listed |
| Preserve → recorder → memory | Scan → record oral history → confirm link via GET preserve/links/:id |
| DNA refresh while opted in | Opt in → refresh → candidates array shape / empty honest → revoke → candidates gone |

## 5. Sign-off

Copy `RESULTS_TEMPLATE.md` → fill PASS/FAIL → attach Playwright report + screenshots → store with release notes.
