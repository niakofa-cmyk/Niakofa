#!/usr/bin/env bash
# Run from Niakofa monorepo root with deployment credentials.
set -euo pipefail

: "${BASE_URL:?Set BASE_URL to deployed origin}"
: "${USER_A_STATE:?Set USER_A_STATE to Playwright storage state JSON}"
export ALLOW_MUTATING_E2E=1

echo "BASE_URL=$BASE_URL"
echo "USER_A_STATE=$USER_A_STATE"
echo "EXPECTED_COMMIT=${EXPECTED_COMMIT:-b8a231636269c8c4f4594e456fda0cd32ac42a50}"
echo "Starting gated live suite…"

npx playwright test e2e/diaspora-final-wiring-live.spec.ts --reporter=list

echo "Live mutation suite finished with exit code $?."
echo "Fill acceptance/RESULTS_TEMPLATE.md and attach playwright-report/."
