# Project: Provider-Grade DNA Integration (separate from Diaspora milestone)

## Status
**Not part of Diaspora production acceptance.**

## Current production boundary (immutable for this milestone)
- Derived DNA sketch / similarity = **discovery lead only**
- shared-cM / IBD = **unavailable** until independently sourced and validated
- Matching may remain feature-gated off

## In scope for this new project
1. Legal / privacy review for genotype vector retention
2. Engine mode `ibd_v1` with real segment calling **or** licensed partner API
3. Provenance + `algorithm_version` on every match row
4. Independent validation dataset and false-positive analysis
5. UI that never implies legal kinship from DNA alone

## Out of scope
- Fabricating cM from sketch hashes
- Blocking Diaspora freeze on this work
- Coupling releases to Ancestry/23andMe unless a real contract exists

## Governance
Separate repo board / milestone; requires explicit product + legal sign-off before enabling in production env.
