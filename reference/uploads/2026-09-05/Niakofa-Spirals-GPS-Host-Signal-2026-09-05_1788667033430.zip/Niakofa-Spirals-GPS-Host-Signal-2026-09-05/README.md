# Spiral GPS host signal + city-match fix (2026-09-05)

Deploy already includes PR #34 (Mapbox v6). Live probes still get
`CIRCLE_START_WRONG_CITY` for Fort Worth coordinates because match is exact
`city_key` only and denials omit what GPS resolved to.

This package:
1. Documents root cause
2. Enhances `verifyCircleStartLocation` (display names, aliases, resolved_* fields)
3. Enriches `/location-check` with **host_signal** for UI
4. Provides `SpiralHostSignal` React badge

**Policy unchanged:** host only in Spiral city; join from anywhere.
