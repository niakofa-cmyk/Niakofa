# Spirals wiring (main 50f7254)

| Layer | Status |
|-------|--------|
| UI routes `/audio-spirals`, `/audio-spiral/:id` | Present |
| Legacy `/audio-circles` | Present |
| API rewrite spiral→circle | In routes/index.ts |
| Browse by city → neighborhoods | Working (10 FW circles live) |
| START requires GPS same city | Enforced server-side |
| JOIN without GPS | By design |
| Mapbox v6 reverse | PR #34 merged + deployed |
| Host signal UI | **This package adds** |
| Exact city match edge cases | **This package softens + exposes resolved city** |

Circles → Spirals is a **compatibility migration**, not a full DB rename.
