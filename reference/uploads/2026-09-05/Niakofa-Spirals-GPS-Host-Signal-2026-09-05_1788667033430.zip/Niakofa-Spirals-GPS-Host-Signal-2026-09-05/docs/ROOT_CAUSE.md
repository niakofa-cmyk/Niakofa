# Why Spiral start fails (verified 2026-09-06 against deploy 50f7254)

## Observed errors
1. **CIRCLE_START_LOCATION_UNVERIFIED** — "could not verify… Refresh GPS"  
   Fixed on main by PR #34 (Mapbox Geocoding **v6** reverse; invalid v5 limit+types caused HTTP 422).
2. **CIRCLE_START_WRONG_CITY** — "You can only start this Spiral from inside fort worth…"  
   Still reproduces on production with legitimate Fort Worth coordinates against `city_key=fort_worth`.

## Live probes
- Deploy commit: `50f725458887aa9707e06fcb049f4d9688bbfd94`
- `GET /api/audio-circles?city=Fort+Worth` → 10 neighborhood + city-wide Spirals
- `POST /api/audio-circles/1/location-check` with FW lat/lng accuracy 12–15m → **403 WRONG_CITY**
- Same for multiple FW-area points (downtown, east, mid-cities)

## Design intent (correct)
- **START/host** requires GPS in the Spiral’s **city** (server-authoritative).
- **JOIN** is location-independent.
- Neighborhoods each have a Spiral channel under that city’s `city_key`.

## Gaps
1. Denial text uses raw `city_key` (`fort worth`) instead of display name (`Fort Worth`).
2. Error payload does **not** return `resolved_city_key` / `resolved_city_display`, so the UI cannot show “You’re in X; this Spiral is Y”.
3. City match is **exact `cityKey` equality** only. Mapbox may return a place/locality that normalizes differently (e.g. suburb name, “Fort Worth Metro”, dual-city edge).
4. No **Host eligibility signal** on the discovery list (“You can host in: Downtown / Fort Worth”).
5. `/api/audio-spirals` without trailing path can 404 depending on Express mount; `/api/audio-spirals/` and rewrite middleware exist — clients should call paths that survive rewrite.

## Not a product bug
Being blocked from **starting** a Fort Worth Spiral while physically outside Fort Worth is intentional.  
Users may still **join** from anywhere.
