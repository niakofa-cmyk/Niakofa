# Apply host-signal + city-match fix

1. Diff `api-server/src/lib/circleLocationPolicy.enhanced.ts` into
   `artifacts/api-server/src/lib/circleLocationPolicy.ts` (keep export names).
2. Merge `circle-location.host-signal.ts` response shape into
   `artifacts/api-server/src/routes/circle-location.ts`.
3. Add `SpiralHostSignal` to the Spiral start sheet / discovery card.
4. Client location-check body **must** be:
   `{ latitude, longitude, accuracy_meters, captured_at }` (ISO-8601 with offset).
5. Prefer API paths: `/api/audio-circles/...` or ensure spiral rewrite hits
   (`/api/audio-spirals/?city=` trailing path is safer than bare `/api/audio-spirals`).
6. Railway: confirm `MAPBOX_TOKEN` is set (runtime). Without it every start fails closed.
7. Deploy, then re-test location-check with a real on-device GPS fix.

## Expected behavior after patch
- Outside Fort Worth: clear message with **your city** vs **Spiral city**; join still works.
- Inside Fort Worth (matched city or alias): `can_host: true` + host signal badge.
- Neighborhood Spirals still share the parent **city_key** for host authorization
  (by design — host city, not sub-block fencing, unless you add Phase-2 geofences).
