/**
 * Badge shown on Spiral discovery / start sheet after location-check.
 * Wire: call POST /api/audio-circles/:id/location-check (or /api/audio-spirals/:id/ via alias)
 * with fresh GPS body, then pass the JSON into this component.
 */
import React from "react";

export type HostSignalPayload = {
  can_host?: boolean;
  allowed?: boolean;
  host_signal?: { status: string; message: string };
  spiral_city_display?: string | null;
  spiral_neighborhood?: string | null;
  resolved_city_display?: string | null;
  resolved_neighborhood_hint?: string | null;
  code?: string;
  error?: string;
};

export function SpiralHostSignal({ signal }: { signal: HostSignalPayload | null }) {
  if (!signal) {
    return (
      <div className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/60">
        Checking GPS for host eligibility…
      </div>
    );
  }

  const ready = signal.can_host || signal.allowed || signal.host_signal?.status === "ready";
  const msg =
    signal.host_signal?.message ||
    signal.error ||
    (ready ? "GPS verified for hosting" : "Cannot host here");

  return (
    <div
      className={`rounded-xl border px-3 py-2 text-xs ${
        ready
          ? "border-teal-300/30 bg-teal-300/10 text-teal-100"
          : "border-amber-300/30 bg-amber-300/10 text-amber-100"
      }`}
      role="status"
    >
      <p className="font-semibold tracking-wide uppercase text-[10px] opacity-80">
        {ready ? "Host signal · verified" : "Host signal · blocked"}
      </p>
      <p className="mt-1 leading-relaxed">{msg}</p>
      {(signal.spiral_neighborhood || signal.resolved_city_display) && (
        <p className="mt-1 text-[11px] opacity-70">
          {signal.spiral_neighborhood ? `Spiral neighborhood: ${signal.spiral_neighborhood}. ` : ""}
          {signal.resolved_city_display ? `GPS city: ${signal.resolved_city_display}` : ""}
          {signal.resolved_neighborhood_hint ? ` · near ${signal.resolved_neighborhood_hint}` : ""}
        </p>
      )}
      <p className="mt-1 text-[10px] opacity-50">Joining never requires GPS. Only starting a Spiral does.</p>
    </div>
  );
}
