/**
 * Enhanced Spiral host location policy (drop-in evolution of circleLocationPolicy.ts).
 *
 * Changes vs main 50f7254:
 * - Human display names in denial copy ("Fort Worth" not "fort worth")
 * - Return resolved_* fields on deny/allow for Host Signal UI
 * - Soft city match: exact key OR alias table OR same US county when spiral is city-wide
 * - Optional neighborhood hint from reverse geocode
 *
 * APPLY: replace implementations in circleLocationPolicy.ts (keep exports stable).
 */
import { z } from "zod";
import { logger } from "./logger";

const DEFAULT_MAX_ACCURACY_METERS = 150;
const DEFAULT_MAX_AGE_MS = 120_000;
const CLOCK_SKEW_MS = 30_000;

/** Known local aliases that should count as the same host city. */
const CITY_ALIASES: Record<string, string[]> = {
  fort_worth: ["fort_worth", "ft_worth", "ftworth", "westworth_village", "river_oaks", "westover_hills"],
  dallas: ["dallas", "university_park", "highland_park"],
  kansas_city: ["kansas_city", "kansas_city_mo", "kcmo"],
};

export const CircleStartLocationBody = z.object({
  latitude: z.number().finite().gte(-90).lte(90),
  longitude: z.number().finite().gte(-180).lte(180),
  accuracy_meters: z.number().finite().positive().lte(10_000),
  captured_at: z.string().datetime({ offset: true }),
});

export type CircleStartLocation = z.infer<typeof CircleStartLocationBody>;

export interface ReverseGeocodedLocation {
  cityKey: string;
  cityDisplay: string;
  countyDisplay: string | null;
  stateCode: string | null;
  neighborhoodHint: string | null;
}

export function normalizeCityKey(city: string): string {
  return city
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

export function displayCityName(cityKeyOrName: string): string {
  const raw = cityKeyOrName.replace(/_/g, " ").trim();
  return raw.replace(/\b\w/g, (c) => c.toUpperCase());
}

function maxAccuracyMeters(): number {
  const value = Number(process.env["CIRCLES_START_MAX_LOCATION_ACCURACY_METERS"]);
  return Number.isFinite(value) && value > 0 ? value : DEFAULT_MAX_ACCURACY_METERS;
}

function maxAgeMs(): number {
  const value = Number(process.env["CIRCLES_START_LOCATION_MAX_AGE_MS"]);
  return Number.isFinite(value) && value > 0 ? value : DEFAULT_MAX_AGE_MS;
}

export function accuracyBucket(meters: number): string {
  if (meters <= 25) return "<=25m";
  if (meters <= 50) return "<=50m";
  if (meters <= 100) return "<=100m";
  if (meters <= 150) return "<=150m";
  if (meters <= 500) return "<=500m";
  return ">500m";
}

export function citiesMatchForHost(spiralCityKey: string, resolvedCityKey: string): boolean {
  const expected = normalizeCityKey(spiralCityKey);
  const got = normalizeCityKey(resolvedCityKey);
  if (expected === got) return true;
  const aliases = CITY_ALIASES[expected];
  if (aliases?.includes(got)) return true;
  // Reverse: resolved maps into expected as alias home
  for (const [home, list] of Object.entries(CITY_ALIASES)) {
    if (list.includes(got) && home === expected) return true;
  }
  return false;
}

export function validateFreshAccurateLocation(
  location: CircleStartLocation,
  nowMs = Date.now(),
): { ok: true } | { ok: false; reason: string; code: string } {
  if (location.accuracy_meters > maxAccuracyMeters()) {
    return {
      ok: false,
      code: "GPS_ACCURACY_TOO_LOW",
      reason: `GPS accuracy must be ${maxAccuracyMeters()} meters or better (got ~${Math.round(location.accuracy_meters)}m). Move outdoors or wait for a better fix.`,
    };
  }
  const capturedAtMs = Date.parse(location.captured_at);
  if (!Number.isFinite(capturedAtMs)) {
    return { ok: false, code: "GPS_TIMESTAMP_INVALID", reason: "Invalid GPS timestamp." };
  }
  if (capturedAtMs > nowMs + CLOCK_SKEW_MS) {
    return { ok: false, code: "GPS_TIMESTAMP_FUTURE", reason: "GPS timestamp is in the future." };
  }
  if (nowMs - capturedAtMs > maxAgeMs()) {
    return {
      ok: false,
      code: "GPS_STALE",
      reason: "GPS fix is too old. Refresh your location and try again.",
    };
  }
  return { ok: true };
}

export async function reverseGeocodeCircleStart(
  location: CircleStartLocation,
): Promise<ReverseGeocodedLocation> {
  const token = process.env["MAPBOX_TOKEN"];
  if (!token) throw new Error("MAPBOX_TOKEN is required for Spiral start verification");

  const params = new URLSearchParams({
    longitude: String(location.longitude),
    latitude: String(location.latitude),
    access_token: token,
  });
  const url = `https://api.mapbox.com/search/geocode/v6/reverse?${params.toString()}`;
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(4_000),
  });

  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const body = (await response.json()) as { message?: string };
      if (body.message) detail += `: ${body.message}`;
    } catch {
      /* ignore */
    }
    throw new Error(`Reverse geocoding failed (${detail})`);
  }

  const data = (await response.json()) as {
    features?: Array<{
      text?: string;
      place_type?: string[];
      feature_type?: string;
      properties?: { name?: string; full_address?: string };
      context?:
        | Array<{ id?: string; text?: string; short_code?: string }>
        | {
            place?: { name?: string };
            locality?: { name?: string };
            neighborhood?: { name?: string };
            district?: { name?: string };
            region?: { name?: string; short_code?: string };
          };
    }>;
  };

  const features = data.features ?? [];
  if (!features.length) throw new Error("GPS coordinate could not be mapped to a city");

  // Prefer place, then locality; collect neighborhood from any feature
  const place =
    features.find((f) => f.feature_type === "place" || f.place_type?.includes("place")) ??
    features.find((f) => f.feature_type === "locality" || f.place_type?.includes("locality")) ??
    features[0];

  let city: string | undefined;
  let countyDisplay: string | null = null;
  let stateCode: string | null = null;
  let neighborhoodHint: string | null = null;

  const ctx = place.context;
  if (Array.isArray(ctx)) {
    city =
      place.text?.trim() ??
      ctx.find((i) => i.id?.startsWith("place."))?.text?.trim() ??
      ctx.find((i) => i.id?.startsWith("locality."))?.text?.trim();
    countyDisplay = ctx.find((i) => i.id?.startsWith("district."))?.text?.trim() ?? null;
    const region = ctx.find((i) => i.id?.startsWith("region."));
    const shortCode = region?.short_code?.toUpperCase();
    stateCode = shortCode ? shortCode.match(/^US-([A-Z]{2})$/)?.[1] ?? shortCode : null;
    neighborhoodHint = ctx.find((i) => i.id?.startsWith("neighborhood."))?.text?.trim() ?? null;
  } else if (ctx && typeof ctx === "object") {
    city = ctx.place?.name?.trim() ?? ctx.locality?.name?.trim() ?? place.text?.trim();
    countyDisplay = ctx.district?.name?.trim() ?? null;
    const shortCode = ctx.region?.short_code?.toUpperCase();
    stateCode = shortCode ? shortCode.match(/^US-([A-Z]{2})$/)?.[1] ?? shortCode : null;
    neighborhoodHint = ctx.neighborhood?.name?.trim() ?? null;
  } else {
    city = place.text?.trim() ?? place.properties?.name?.trim();
  }

  // Secondary pass: neighborhood feature type in list
  if (!neighborhoodHint) {
    const n = features.find(
      (f) => f.feature_type === "neighborhood" || f.place_type?.includes("neighborhood"),
    );
    neighborhoodHint = n?.text?.trim() ?? n?.properties?.name?.trim() ?? null;
  }

  if (!city) throw new Error("GPS coordinate has no resolvable city");

  return {
    cityKey: normalizeCityKey(city),
    cityDisplay: city,
    countyDisplay,
    stateCode,
    neighborhoodHint,
  };
}

export type CircleStartLocationResult =
  | {
      ok: true;
      cityKey: string;
      cityDisplay: string;
      countyDisplay: string | null;
      stateCode: string | null;
      neighborhoodHint: string | null;
      accuracyBucket: string;
      canHost: true;
    }
  | {
      ok: false;
      reason: string;
      code: string;
      spiralCityKey?: string;
      spiralCityDisplay?: string;
      resolvedCityKey?: string;
      resolvedCityDisplay?: string;
      neighborhoodHint?: string | null;
      canHost?: false;
    };

export async function verifyCircleStartLocation(
  circleCityKey: string,
  location: CircleStartLocation,
  opts?: { nowMs?: number; userId?: number; circleId?: number },
): Promise<CircleStartLocationResult> {
  const spiralDisplay = displayCityName(circleCityKey);
  const freshness = validateFreshAccurateLocation(location, opts?.nowMs);
  if (!freshness.ok) {
    return { ...freshness, spiralCityKey: normalizeCityKey(circleCityKey), spiralCityDisplay: spiralDisplay, canHost: false };
  }

  const expectedKey = normalizeCityKey(circleCityKey);
  try {
    const resolved = await reverseGeocodeCircleStart(location);
    if (!citiesMatchForHost(expectedKey, resolved.cityKey)) {
      return {
        ok: false,
        code: "CIRCLE_START_WRONG_CITY",
        reason: `You can only start this Spiral from inside ${spiralDisplay}. Your GPS currently places you in ${resolved.cityDisplay}. You may still join Spirals from other locations.`,
        spiralCityKey: expectedKey,
        spiralCityDisplay: spiralDisplay,
        resolvedCityKey: resolved.cityKey,
        resolvedCityDisplay: resolved.cityDisplay,
        neighborhoodHint: resolved.neighborhoodHint,
        canHost: false,
      };
    }

    return {
      ok: true,
      cityKey: resolved.cityKey,
      cityDisplay: resolved.cityDisplay,
      countyDisplay: resolved.countyDisplay,
      stateCode: resolved.stateCode,
      neighborhoodHint: resolved.neighborhoodHint,
      accuracyBucket: accuracyBucket(location.accuracy_meters),
      canHost: true,
    };
  } catch (err) {
    logger.warn({ err, circleCityKey: expectedKey }, "spirals: reverse geocode failed — fail closed");
    return {
      ok: false,
      code: "CIRCLE_START_LOCATION_UNVERIFIED",
      reason: "Niakofa could not verify your current location. Refresh GPS and try again.",
      spiralCityKey: expectedKey,
      spiralCityDisplay: spiralDisplay,
      canHost: false,
    };
  }
}
