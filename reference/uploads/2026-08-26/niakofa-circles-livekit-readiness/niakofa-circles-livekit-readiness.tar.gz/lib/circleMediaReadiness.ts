export type MediaDeviceKind = "microphone" | "camera";

export type MediaReadinessCode =
  | "secure_context_required"
  | "api_unavailable"
  | "permission_denied"
  | "device_not_found"
  | "device_busy"
  | "constraint_failed"
  | "connectivity_error"
  | "unknown";

export interface MediaReadiness {
  secureContext: boolean;
  mediaDevicesAvailable: boolean;
  hasMicrophone: boolean;
  hasCamera: boolean;
  microphonePermission: PermissionState | "unknown";
  cameraPermission: PermissionState | "unknown";
}

export interface MediaReadinessFailure {
  ok: false;
  device: MediaDeviceKind;
  code: MediaReadinessCode;
  message: string;
}

export interface MediaReadinessSuccess {
  ok: true;
  stream: MediaStream;
}

export type MediaAcquireResult = MediaReadinessSuccess | MediaReadinessFailure;

async function queryPermission(name: PermissionName): Promise<PermissionState | "unknown"> {
  try {
    if (!navigator.permissions?.query) return "unknown";
    return (await navigator.permissions.query({ name } as PermissionDescriptor)).state;
  } catch {
    return "unknown";
  }
}

export async function getCircleMediaReadiness(): Promise<MediaReadiness> {
  const secureContext = typeof window !== "undefined" && window.isSecureContext;
  const mediaDevicesAvailable =
    typeof navigator !== "undefined" &&
    !!navigator.mediaDevices &&
    typeof navigator.mediaDevices.enumerateDevices === "function";

  if (!mediaDevicesAvailable) {
    return {
      secureContext,
      mediaDevicesAvailable: false,
      hasMicrophone: false,
      hasCamera: false,
      microphonePermission: "unknown",
      cameraPermission: "unknown",
    };
  }

  const devices = await navigator.mediaDevices.enumerateDevices();
  return {
    secureContext,
    mediaDevicesAvailable,
    hasMicrophone: devices.some(d => d.kind === "audioinput"),
    hasCamera: devices.some(d => d.kind === "videoinput"),
    microphonePermission: await queryPermission("microphone"),
    cameraPermission: await queryPermission("camera"),
  };
}

/**
 * Classifies a caught error from acquiring OR publishing a device. Exported
 * so callers who acquire media through a transport (e.g. LiveKit's
 * `createLocalTracks`/`publishTrack`, not the raw `getUserMedia()` this
 * module calls directly) can still get consistent messaging — a single
 * taxonomy instead of each call site inventing its own error copy.
 *
 * Camera hardware working locally but LiveKit's publish/connect step
 * failing (bad ICE/TURN path, SFU unreachable, token expired mid-call) is
 * a distinct, real failure mode from a permission or hardware problem —
 * telling the user to "check camera permissions" when the camera opened
 * fine and the network path to the SFU is what failed sends them
 * troubleshooting the wrong thing.
 */
export function classifyMediaError(error: unknown, device: MediaDeviceKind): MediaReadinessFailure {
  if (error instanceof DOMException) return mapError(error, device);
  const message = error instanceof Error ? error.message : "";
  if (/livekit|sfu|ice|turn|publish|connect|token/i.test(message)) {
    return {
      ok: false,
      device,
      code: "connectivity_error",
      message: `Your ${device} opened, but the live connection to the Circle failed. Check your network and try again.`,
    };
  }
  return {
    ok: false,
    device,
    code: "unknown",
    message: `Niakofa could not access the ${device}. Check browser permissions and device availability.`,
  };
}

function mapError(error: unknown, device: MediaDeviceKind): MediaReadinessFailure {
  const name = error instanceof DOMException ? error.name : "";
  if (name === "NotAllowedError" || name === "SecurityError")
    return { ok: false, device, code: "permission_denied",
      message: `Allow ${device} access for Niakofa in your browser/site settings, then try again.` };
  if (name === "NotFoundError" || name === "DevicesNotFoundError")
    return { ok: false, device, code: "device_not_found",
      message: `No ${device} was found. Connect or enable a ${device} and try again.` };
  if (name === "NotReadableError" || name === "TrackStartError")
    return { ok: false, device, code: "device_busy",
      message: `The ${device} appears to be busy or unavailable. Close other apps/tabs using it and retry.` };
  if (name === "OverconstrainedError")
    return { ok: false, device, code: "constraint_failed",
      message: `The selected ${device} does not support the requested settings.` };
  return { ok: false, device, code: "unknown",
    message: `Niakofa could not access the ${device}. Check browser permissions and device availability.` };
}

/** Acquire ONLY the requested device. Camera acquisition never requests audio. */
export async function acquireCircleDevice(device: MediaDeviceKind): Promise<MediaAcquireResult> {
  const readiness = await getCircleMediaReadiness();

  if (!readiness.secureContext)
    return { ok: false, device, code: "secure_context_required",
      message: "Live camera/microphone access requires HTTPS (or localhost during development)." };

  if (!readiness.mediaDevicesAvailable)
    return { ok: false, device, code: "api_unavailable",
      message: "This browser does not expose the required media APIs." };

  if (device === "camera" && !readiness.hasCamera)
    return { ok: false, device, code: "device_not_found",
      message: "No camera is available to this browser/device." };

  if (device === "microphone" && !readiness.hasMicrophone)
    return { ok: false, device, code: "device_not_found",
      message: "No microphone is available to this browser/device." };

  try {
    const stream = await navigator.mediaDevices.getUserMedia(
      device === "camera"
        ? { video: {
            width: { ideal: 1280, max: 1280 },
            height: { ideal: 720, max: 720 },
            frameRate: { ideal: 30, max: 30 },
            facingMode: "user",
          }, audio: false }
        : { audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          }, video: false }
    );
    return { ok: true, stream };
  } catch (error) {
    return mapError(error, device);
  }
}
