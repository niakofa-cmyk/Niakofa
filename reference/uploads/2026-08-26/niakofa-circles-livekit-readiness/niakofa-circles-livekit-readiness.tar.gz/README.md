# Niakofa Circles — LiveKit-Always + Media Readiness (verified)

Applied and test-verified against the live niakofa-cmyk/Niakofa repo on
2026-08-27, on top of the previously-integrated LiveKit SFU work.

## What changed

### 1. `selectMediaTransportKind()` now always returns `"livekit"`
Room size stopped being a safe proxy the moment listeners could publish
video — a "small" 4-speaker/20-listener Circle can still have a dozen
simultaneous camera publishers on mesh. `audio-circle-room.tsx` already
falls back to mesh automatically on a 503 from the token endpoint, so this
stays safe for local dev / any environment without LiveKit provisioned —
no room-size heuristic needed to decide when mesh is "safe enough."

### 2. `circleMediaReadiness.ts` — consolidated device readiness + error taxonomy
- `getCircleMediaReadiness()`: secure-context, API-availability, and
  hardware-presence checks with zero permission prompts — safe to call on
  page load.
- `acquireCircleDevice(device)`: the actual `getUserMedia()` call, gated by
  the checks above (never prompts for a camera that doesn't exist or a page
  that isn't HTTPS), camera-only requests never touch audio, structured
  `MediaReadinessCode` per failure (`secure_context_required`,
  `permission_denied`, `device_not_found`, `device_busy`,
  `constraint_failed`, `connectivity_error`, `unknown`).
- `classifyMediaError(error, device)`: exported so any call site (not just
  raw `getUserMedia()`) gets identical error copy — including a new
  `connectivity_error` bucket for the case the source doc specifically
  called out: camera opens fine locally, but the LiveKit/ICE/TURN publish
  step fails. That is not a permission problem and telling a user to
  "check camera permissions" for it sends them troubleshooting the wrong
  thing.

`audio-circle-room.tsx`'s existing `mediaErrorMessage()` now delegates to
`classifyMediaError()` instead of maintaining a second, parallel error
taxonomy — one source of truth for "why did the camera/mic fail," used
everywhere in the page (9 call sites), see `docs/audio-circle-room.tsx.diff`.

## What I did NOT take from the uploaded package as-is
The uploaded bundle's own test file
(`circleMediaReadiness.test.ts`) never imports the module it claims to
test — both of its assertions check hardcoded literals, so they'd pass
even if `circleMediaReadiness.ts` were deleted. I replaced it with tests
that actually import and exercise `getCircleMediaReadiness`,
`acquireCircleDevice`, and `classifyMediaError` — including asserting
`getUserMedia` is never called when secure-context or hardware checks
should short-circuit first.

## Verified, not just written
- `node --import tsx/esm --test` (the repo's real client test runner):
  **14/14 passing** — `circleMediaTransport.test.ts` (selector),
  `circleMediaPolicy.test.ts` (unchanged, still green),
  `circleMediaReadiness.test.ts` (new, genuine tests).
- `npx jest` (the repo's real server test runner):
  **2/2 passing** — `circle-media-config.test.ts` (unchanged).
- `tsc --noEmit` on the client workspace: same 99 pre-existing errors as
  before this change, all in unrelated files (`lib/api-client-react`
  unbuilt-workspace-output issue) — **zero new errors**, zero errors in
  any circle/livekit/media file.
