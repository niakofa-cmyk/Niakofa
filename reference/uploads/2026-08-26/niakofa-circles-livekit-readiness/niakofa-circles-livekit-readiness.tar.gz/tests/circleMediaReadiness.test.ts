import test from "node:test";
import assert from "node:assert/strict";
import {
  getCircleMediaReadiness,
  acquireCircleDevice,
  classifyMediaError,
} from "../circleMediaReadiness";

function withGlobals<T>(overrides: {
  isSecureContext?: boolean;
  mediaDevices?: any;
  permissionsQuery?: (desc: { name: string }) => Promise<{ state: string }>;
}, fn: () => Promise<T>): Promise<T> {
  const g = globalThis as any;
  const prevWindow = Object.getOwnPropertyDescriptor(g, "window");
  const prevNavigator = Object.getOwnPropertyDescriptor(g, "navigator");
  Object.defineProperty(g, "window", {
    value: { isSecureContext: overrides.isSecureContext ?? true },
    configurable: true,
  });
  Object.defineProperty(g, "navigator", {
    value: {
      mediaDevices: overrides.mediaDevices,
      permissions: overrides.permissionsQuery ? { query: overrides.permissionsQuery } : undefined,
    },
    configurable: true,
  });
  return fn().finally(() => {
    if (prevWindow) Object.defineProperty(g, "window", prevWindow); else delete g.window;
    if (prevNavigator) Object.defineProperty(g, "navigator", prevNavigator); else delete g.navigator;
  });
}

test("getCircleMediaReadiness reports insecure context without probing devices", async () => {
  const result = await withGlobals({ isSecureContext: false, mediaDevices: undefined }, () =>
    getCircleMediaReadiness(),
  );
  assert.equal(result.secureContext, false);
  assert.equal(result.mediaDevicesAvailable, false);
});

test("getCircleMediaReadiness detects camera/mic hardware independently of permission state", async () => {
  const result = await withGlobals(
    {
      isSecureContext: true,
      mediaDevices: {
        enumerateDevices: async () => [{ kind: "audioinput" }],
      },
      permissionsQuery: async () => ({ state: "prompt" }),
    },
    () => getCircleMediaReadiness(),
  );
  assert.equal(result.hasMicrophone, true);
  assert.equal(result.hasCamera, false);
});

test("acquireCircleDevice refuses on insecure context before touching getUserMedia", async () => {
  let called = false;
  const result = await withGlobals(
    {
      isSecureContext: false,
      mediaDevices: { getUserMedia: async () => { called = true; return {}; }, enumerateDevices: async () => [] },
    },
    () => acquireCircleDevice("camera"),
  );
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.code, "secure_context_required");
  assert.equal(called, false, "getUserMedia must never be called on an insecure context");
});

test("acquireCircleDevice requests camera without audio", async () => {
  let capturedConstraints: any = null;
  const result = await withGlobals(
    {
      isSecureContext: true,
      mediaDevices: {
        enumerateDevices: async () => [{ kind: "videoinput" }],
        getUserMedia: async (constraints: any) => {
          capturedConstraints = constraints;
          return { id: "fake-stream" };
        },
      },
    },
    () => acquireCircleDevice("camera"),
  );
  assert.equal(result.ok, true);
  assert.equal(capturedConstraints.audio, false);
  assert.ok(capturedConstraints.video);
});

test("acquireCircleDevice maps NotAllowedError to permission_denied", async () => {
  const result = await withGlobals(
    {
      isSecureContext: true,
      mediaDevices: {
        enumerateDevices: async () => [{ kind: "videoinput" }],
        getUserMedia: async () => { throw new DOMException("denied", "NotAllowedError"); },
      },
    },
    () => acquireCircleDevice("camera"),
  );
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.code, "permission_denied");
});

test("acquireCircleDevice maps NotReadableError to device_busy (e.g. Zoom/another tab holding the camera)", async () => {
  const result = await withGlobals(
    {
      isSecureContext: true,
      mediaDevices: {
        enumerateDevices: async () => [{ kind: "videoinput" }],
        getUserMedia: async () => { throw new DOMException("busy", "NotReadableError"); },
      },
    },
    () => acquireCircleDevice("camera"),
  );
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.code, "device_busy");
});

test("acquireCircleDevice short-circuits with device_not_found when hardware is absent, without prompting", async () => {
  let called = false;
  const result = await withGlobals(
    {
      isSecureContext: true,
      mediaDevices: {
        enumerateDevices: async () => [{ kind: "audioinput" }], // no videoinput
        getUserMedia: async () => { called = true; return {}; },
      },
    },
    () => acquireCircleDevice("camera"),
  );
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.code, "device_not_found");
  assert.equal(called, false);
});

test("classifyMediaError distinguishes SFU/network failure from a permission problem", () => {
  const result = classifyMediaError(new Error("LiveKit media session ended while publishing the camera"), "camera");
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.code, "connectivity_error");
});

test("classifyMediaError still routes real DOMExceptions through the standard taxonomy", () => {
  const result = classifyMediaError(new DOMException("x", "NotFoundError"), "microphone");
  assert.equal(result.ok, false);
  if (!result.ok) assert.equal(result.code, "device_not_found");
});
