# Niakofa Diaspora Globe — hardening package

## Product decision

The `/diaspora` landing experience should be:

    Diaspora → Globe → Hub → Action

The Globe is the doorway, not another dashboard.

### Geography contract

- Non-U.S. Diaspora Hubs are country Hubs: Brazil, Ghana, Nigeria, Jamaica, Canada, France, UK, Dominican Republic, etc.
- The United States is the exception: the Globe represents individual U.S. states.
- City/local communities such as Salvador, Recife, São Luís, and São Paulo remain useful internal/local data, but they should not become separate canonical Globe markers when grouped under a country Hub.
- `Home Hub` is not a Globe geography. A user's home can be represented as user context/member affinity and resolved to the appropriate country/state Hub.

## Included

1. `lib/db/migrations/0138_diaspora_hub_geography_invariants.sql`
   - Normalizes known U.S./non-U.S. canonical geography.
   - Adds a database geography CHECK constraint.
   - Prevents duplicate approved canonical country/state Globe markers.
   - Preserves historical/local Hub rows through `primary_hub_id`.

2. `DiasporaGlobeFirst.home-hub-removal.patch`
   - Removes legacy `Home hub` presentation.
   - Removes Home Hub marker styling.
   - Removes the redundant "full globe" navigation button.
   - Tightens copy around canonical Hubs.

## Recommended architecture

Keep these capabilities, but move them behind Hub selection:

- Live presence → Hub activity / Live now
- Relationships → Hub Community / Connections
- Spirals → Hub Spirals
- Family memory → Hub Stories / Family
- Hub-to-Hub messaging → Hub Message action
- Pool → Hub More menu

Do not delete the underlying systems just to simplify the landing page.

## Important backend recommendation

The database constraint is necessary but not sufficient. The Globe API should return only canonical Globe Hubs:

- `primary_hub_id IS NULL`
- approved/visible status
- `hub_scope = country` for non-U.S.
- `hub_scope = us_state` and `country_code = US` for U.S. state Hubs

Local/legacy rows should be attached as `local_hubs`, not emitted as independent Globe markers.

## Validation after upload

Run:

- migrations
- typecheck
- tests
- lint
- route audit
- release validation
- browser smoke test for `/diaspora`

Then verify manually:

1. Brazil shows one Globe marker.
2. Ghana shows one Globe marker.
3. Nigeria shows one Globe marker.
4. Texas shows one state marker.
5. California shows one state marker.
6. Searching Recife resolves to Brazil without creating a Recife Globe marker.
7. Selecting Brazil opens Community / Message Hub / Spirals.
8. Stories and Pool are behind "More".
9. No Home Hub label or special Home marker remains on the Globe.
10. `/diaspora` contains no old dashboard sections.

## Important safety note

Do not run the SQL migration against production manually unless the repository's normal migration runner is the approved deployment path. Upload the migration, let CI validate it, and deploy through the normal Railway release process.
