# Repository review and integration plan — checked against main on 2026-09-29

## Confirmed source-level findings
- `docs/reference/niakofa-moments-sparks/product-decision.txt` establishes Sparks as individual posts, Moments as the viewing destination, Stories as enduring narratives, Spirals as groups, and Griot/Legacy as preserved family/cultural memory.
- `CommunityStoryRail.tsx` has Story-backed grouping/viewing, camera/gallery selection, an edit/destination studio, overlays, draft persistence, progress/cancel state, metrics/reactions, and legacy story client calls.
- `CommunityExchangeSparkComposer.tsx` has a separate listing-linked video draft/upload/processing/publish lifecycle. Keep Exchange media tied to the listing's lifecycle.
- `docs/reference/niakofa-sparks-workflow-2026-09-27.md` says ordinary Community/Hub Moments still use legacy Story API/Base64 media and a dedicated vertical Moments browser is separate work. It also explicitly says production media is not certified.
- `docs/PRODUCTION_ACCEPTANCE_MATRIX.md` has incomplete production gates for worker/runtime, storage variants, failure cleanup, deployed Studio acceptance, and device evidence. Green CI/healthy deploy does not equal media certification.

## Recommendations
1. Add a dedicated Moments destination and make it consume approved, server-authorized Spark data; keep old Story routes/IDs/deep links backward compatible.
2. Unify the entry-point and visual shell, not the underlying media state machines. Reuse existing Story Studio and Exchange upload clients.
3. Add a distinct Family Stories/Griot Family Stories landing and creation path within Family Vault/Legacy. Include title, narrative, oral-history audio/video, transcripts/captions, family contributors, dates, people/relationships, access roles, preservation/pinning, and export/deletion controls.
4. Keep family media private by default and use explicit family roles/invitations. Community audience access must never imply Family Vault access.
5. Wire likes/comments/shares/remix/audio/profile/discovery controls to authorized server actions. UI controls in the scaffold are callbacks or integration events, not complete backend features.
6. Don't show music as playable without rights; don't claim trimming/effects are rendered unless processing creates the actual output. Enforce server-side size/type/duration limits, idempotent publishing, upload retry/cancel, and durable cleanup.
7. Preserve separate lifecycles: Community Moments expire at 24 hours; Exchange listing media follows the listing lifecycle; preserved family narratives remain in the family archive until governed by family retention/deletion policy.
8. Complete `docs/PRODUCTION_ACCEPTANCE_MATRIX.md`, including actual approved-account tests and physical iOS/Android camera/gallery/playback/accessibility checks before any media-platform activation or production certification.

## Acceptance checklist
- [ ] Mobile full-screen portrait, vertical navigation, pause/mute, loading/error/empty states.
- [ ] Personalized/local/Spiral/topic feeds backed by real server queries.
- [ ] Creator profiles, comments, likes, shares, report, audio and remix permissions wired end-to-end.
- [ ] Multi-clip capture, trim, text, captions, stickers, drawing, licensed/original audio, drafts, preview, cover selection, templates.
- [ ] Story expiration/archive and audience controls; family preservation is not ephemeral.
- [ ] Mute/block/report/moderation, deletion plus object cleanup, and rights/remix controls.
- [ ] Watch-time/retention analytics, creator growth analytics, upload retry/recovery, transcoding/variants, accessible captions.
- [ ] Typecheck/lint/tests/boundary checks and production/device acceptance all green on exact served commit.
