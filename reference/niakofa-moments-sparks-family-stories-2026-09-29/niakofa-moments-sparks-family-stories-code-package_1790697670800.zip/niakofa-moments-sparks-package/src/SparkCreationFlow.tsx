import React, { useState } from 'react';
import './niakofa-moments-sparks.css';

type Props = {
  open: boolean; onClose: () => void; files: File[]; onFiles: (files: File[]) => void;
  caption: string; onCaption: (value: string) => void;
  audience: 'community'|'spiral'; onAudience: (value:'community'|'spiral')=>void;
  onSaveDraft: ()=>void|Promise<void>; onPublish: ()=>void|Promise<void>; onRemove: (index:number)=>void;
  progress?: number|null; status?: string; error?: string|null; busy?: boolean;
};

/** Visual shell only. Connect to existing Niakofa studio/draft/upload handlers. */
export function SparkCreationFlow(p: Props) {
  const [step,setStep] = useState<'media'|'edit'|'share'>('media');
  const [preview,setPreview] = useState(0);
  if (!p.open) return null;
  const choose=(list:FileList|null)=>{ if(list?.length){p.onFiles(Array.from(list));setPreview(0);setStep('edit');} };
  const file=p.files[preview];
  return <div className="nia-studio-backdrop"><section className="nia-studio" role="dialog" aria-modal="true" aria-labelledby="nia-studio-title">
    <header className="nia-studio__header"><button className="nia-icon" onClick={p.onClose} aria-label="Close">×</button><div><small>MAKE SOMETHING THAT CONNECTS</small><h2 id="nia-studio-title">Create a Spark</h2></div><button className="nia-text" onClick={()=>void p.onSaveDraft()} disabled={p.busy}>Save draft</button></header>
    <div className="nia-steps"><span className={step==='media'?'current':''}>1 · Add media</span><span className={step==='edit'?'current':''}>2 · Make it yours</span><span className={step==='share'?'current':''}>3 · Audience</span></div>
    {step==='media' && <div className="nia-source-grid"><label className="nia-source"><span>▣</span><strong>Capture photo or video</strong><small>Open your camera</small><input type="file" accept="image/*,video/*" capture="environment" multiple onChange={e=>choose(e.currentTarget.files)}/></label><label className="nia-source"><span>▧</span><strong>Choose from gallery</strong><small>Select one or more items</small><input type="file" accept="image/*,video/*" multiple onChange={e=>choose(e.currentTarget.files)}/></label></div>}
    {step==='edit' && <><div className="nia-preview">{file && (file.type.startsWith('video/')?<video src={URL.createObjectURL(file)} controls playsInline/>:<img src={URL.createObjectURL(file)} alt="Spark preview"/>)}{!file&&'Select media to preview'}</div><div className="nia-thumbs">{p.files.map((f,i)=><button className={i===preview?'selected':''} key={`${f.name}-${i}`} onClick={()=>setPreview(i)}>{f.type.startsWith('video/')?'▶':'▧'} {i+1}<span onClick={e=>{e.stopPropagation();p.onRemove(i)}}>×</span></button>)}</div><label className="nia-caption">Caption<textarea value={p.caption} maxLength={2200} onChange={e=>p.onCaption(e.target.value)} placeholder="What would you like your community to know?"/></label><div className="nia-tool-row"><button disabled>Text & stickers <small>Connect editor</small></button><button disabled>Sound <small>Licensed/original audio only</small></button><button disabled>Trim <small>Only when rendered</small></button></div><footer><button className="nia-secondary" onClick={()=>setStep('media')}>Back</button><button className="nia-primary" disabled={!p.files.length} onClick={()=>setStep('share')}>Next: audience</button></footer></>}
    {step==='share' && <><h3>Who should see your Spark?</h3><p className="nia-note">Private family memories belong in Family Stories, not public Moments.</p><div className="nia-audience"><button className={p.audience==='community'?'selected':''} onClick={()=>p.onAudience('community')}><strong>Niakofa Community</strong><small>Share with your permitted community audience</small></button><button className={p.audience==='spiral'?'selected':''} onClick={()=>p.onAudience('spiral')}><strong>A Spiral</strong><small>Share with an eligible Spiral</small></button></div>{p.error&&<p role="alert" className="nia-error">{p.error}</p>}{p.status&&<div role="status" className="nia-upload">{p.status}{typeof p.progress==='number'&&<progress max="100" value={p.progress}/>}</div>}<footer><button className="nia-secondary" onClick={()=>setStep('edit')}>Back</button><button className="nia-primary" disabled={p.busy||!p.files.length} onClick={()=>void p.onPublish()}>{p.busy?'Publishing…':'Share Spark'}</button></footer><p className="nia-note">Publishing remains subject to Niakofa's authorization, moderation, media-processing, and rights rules.</p></>}
  </section></div>;
}
