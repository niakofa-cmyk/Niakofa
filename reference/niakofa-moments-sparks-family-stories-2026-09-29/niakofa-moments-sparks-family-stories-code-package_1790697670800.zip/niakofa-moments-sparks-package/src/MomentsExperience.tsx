import React, { useEffect, useRef, useState } from 'react';
import './niakofa-moments-sparks.css';

export type SparkItem = {
  id: string;
  creator: { id: string; name: string; avatarUrl?: string | null; handle?: string };
  media: { kind: 'video' | 'image'; playbackUrl: string; posterUrl?: string | null; alt?: string };
  caption: string;
  neighborhood?: string;
  spiral?: string;
  audioLabel?: string;
  likes?: number;
  comments?: number;
  likedByMe?: boolean;
};

type Props = {
  sparks: SparkItem[];
  loading?: boolean;
  onCreateSpark: () => void;
  onLike: (spark: SparkItem) => void | Promise<void>;
  onComment: (spark: SparkItem) => void;
  onShare: (spark: SparkItem) => void;
  onCreator: (creatorId: string) => void;
  onAudio?: (spark: SparkItem) => void;
  onReport?: (spark: SparkItem) => void;
};

/** Feed presentation only. Pass authorized, short-lived playback URLs from Niakofa's server. */
export function MomentsExperience({ sparks, loading, onCreateSpark, onLike, onComment, onShare, onCreator, onAudio, onReport }: Props) {
  const root = useRef<HTMLDivElement>(null);
  const videos = useRef<Record<string, HTMLVideoElement | null>>({});
  const [active, setActive] = useState(0);
  const [muted, setMuted] = useState(true);
  const [busyLike, setBusyLike] = useState<string | null>(null);

  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const observer = new IntersectionObserver(entries => {
      const best = entries.filter(e => e.isIntersecting).sort((a,b) => b.intersectionRatio-a.intersectionRatio)[0];
      if (best) setActive(Number((best.target as HTMLElement).dataset.index));
    }, { root: el, threshold: [0.6, 0.8] });
    el.querySelectorAll<HTMLElement>('[data-index]').forEach(n => observer.observe(n));
    return () => observer.disconnect();
  }, [sparks.length]);

  useEffect(() => {
    sparks.forEach((spark, i) => {
      const v = videos.current[spark.id];
      if (!v) return;
      v.muted = muted;
      if (i === active) void v.play().catch(() => {}); else v.pause();
    });
  }, [active, muted, sparks]);

  async function like(spark: SparkItem) {
    if (busyLike) return;
    setBusyLike(spark.id);
    try { await onLike(spark); } finally { setBusyLike(null); }
  }

  return <main className="nia-moments">
    <header className="nia-moments__header">
      <div><small>THE GLOBAL VILLAGE IN MOTION</small><h1>Moments</h1></div>
      <div className="nia-moments__head-actions"><button className="nia-icon" aria-label="Search Moments" onClick={() => document.dispatchEvent(new CustomEvent('niakofa:moments-search'))}>⌕</button><button className="nia-primary" onClick={onCreateSpark}>＋ Create a Spark</button></div>
    </header>
    <nav className="nia-filters" aria-label="Discover Sparks"><button className="active">For You</button><button onClick={() => document.dispatchEvent(new CustomEvent('niakofa:moments-local'))}>Near Me</button><button onClick={() => document.dispatchEvent(new CustomEvent('niakofa:moments-spirals'))}>My Spirals</button><button onClick={() => document.dispatchEvent(new CustomEvent('niakofa:moments-topics'))}>Topics</button></nav>
    <section className="nia-moments__feed" ref={root} aria-label="Vertical Sparks feed">
      {!sparks.length && !loading && <div className="nia-empty"><span>✳</span><h2>Your community is full of stories waiting to spark.</h2><p>Share a moment from your life, neighborhood, or Spiral.</p><button className="nia-primary" onClick={onCreateSpark}>Create the first Spark</button></div>}
      {sparks.map((s,i) => <article className="nia-spark" data-index={i} key={s.id}>
        {s.media.kind === 'video' ? <video ref={n => { videos.current[s.id] = n; }} src={s.media.playbackUrl} poster={s.media.posterUrl ?? undefined} muted={muted} playsInline loop preload={i <= active+1 ? 'metadata':'none'} aria-label={s.media.alt || `Spark by ${s.creator.name}`} /> : <img src={s.media.playbackUrl} alt={s.media.alt || `Spark by ${s.creator.name}`} loading={i < 2 ? 'eager':'lazy'} />}
        <div className="nia-spark__shade" />
        <div className="nia-spark__actions"><button onClick={() => void like(s)} disabled={busyLike===s.id} aria-label="Like Spark"><b className={s.likedByMe?'liked':''}>♥</b><small>{s.likes ?? 0}</small></button><button onClick={() => onComment(s)} aria-label="Comments"><b>▤</b><small>{s.comments ?? 0}</small></button><button onClick={() => onShare(s)} aria-label="Share Spark"><b>↗</b><small>Share</small></button>{onAudio && <button onClick={() => onAudio(s)} aria-label="Explore audio"><b>♫</b><small>Audio</small></button>}{onReport && <button onClick={() => onReport(s)} aria-label="Report Spark"><b>•••</b></button>}</div>
        <div className="nia-spark__meta"><button className="nia-creator" onClick={() => onCreator(s.creator.id)}><span className="nia-avatar">{s.creator.avatarUrl ? <img src={s.creator.avatarUrl} alt=""/> : s.creator.name.slice(0,1)}</span><span><strong>{s.creator.name}</strong><small>{s.creator.handle ? '@'+s.creator.handle : 'Niakofa Creator'}</small></span><em>Profile</em></button><p>{s.caption}</p><div className="nia-context">{s.neighborhood && <span>⌖ {s.neighborhood}</span>}{s.spiral && <span>◎ {s.spiral}</span>}</div>{s.audioLabel && <button className="nia-audio" onClick={() => onAudio?.(s)}>♫ {s.audioLabel}</button>}</div>
        <button className="nia-sound" onClick={() => setMuted(v=>!v)} aria-label={muted?'Unmute':'Mute'}>{muted?'♪̸':'♫'}</button><span className="nia-count">{i+1} / {sparks.length}</span>
      </article>)}
      {loading && <p role="status">Loading more Sparks…</p>}
    </section>
  </main>;
}
