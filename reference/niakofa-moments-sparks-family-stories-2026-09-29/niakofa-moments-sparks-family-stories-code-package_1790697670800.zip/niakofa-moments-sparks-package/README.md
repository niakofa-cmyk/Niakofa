# Niakofa Moments + Sparks + Family Stories — Visual Package

## Canonical language
- **Moments** is the immersive vertical viewing/discovery destination.
- **Spark** is an individual short-form photo/video/response post. CTA: **Create a Spark**.
- **Niakofa Family Stories / Griot Family Stories** is the enduring family narrative and legacy experience inside Family Vault / Legacy—not the ephemeral short-form feed.
- Preserve existing Story API records and deep links. Keep Exchange listing media on its approved durable listing lifecycle, separate from 24-hour Community Moments.

## Integration
This is an additive visual scaffold. Wire props to existing Niakofa APIs and state machines. Do not create a second media backend, bypass auth/audience checks, expose storage keys, or couple Nia AI to media processing. The repository's current CommunityStoryRail already owns legacy Story-backed composition and studio state; ExchangeSparkComposer owns listing-linked secure video drafts and publishing. Adapt/reuse these instead of duplicating upload logic.

See `docs/REPO_REVIEW_AND_INTEGRATION.md` for verified gaps and acceptance gates.
