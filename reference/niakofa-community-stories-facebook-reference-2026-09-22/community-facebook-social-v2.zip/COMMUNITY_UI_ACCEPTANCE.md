# Community UI acceptance contract

The Community landing surface is a social feed, not an app directory.

## Primary chrome
- Five icon-only destinations: Home, Stories, People, Hubs, Notifications.
- Messages and Menu are header actions.
- No primary Create button.
- No Profile primary tab.
- No Requests/Services/Spirals/Media/Diaspora primary tabs.

## Content hierarchy
1. Stories rail
2. What's on your mind? composer
3. Community feed
4. Secondary Niakofa systems only when explicitly opened

## Preservation
All existing Community APIs, Hub feed behavior, Story behavior, Messages routing, Hub membership logic, Requests, Spirals, Diaspora and realtime infrastructure remain untouched.
