# Niakofa Community — Facebook-style Social Chrome V2

Baseline audited: `main` at `0d010da463b37b37b169fbe100f952bfcb73faa3`.

## What this package changes

The current Community implementation already has the important social foundations:
- real Hub-scoped feed
- collapsed `What's on your mind?` composer
- Community Stories rail and Story composer/viewer
- post reactions/comments/sharing
- Hub context and Niakofa-specific backend systems

The remaining visual problem is the shell: it still presents Community as a dashboard with too many competing destinations.

This package replaces only `CommunitySocialShell.tsx` and intentionally preserves the existing route contract.

### New shell rules

1. **Exactly five primary social icons:** Home, Stories, People, Hubs, Notifications.
2. **No Profile tab.** Profile moves into the single menu.
3. **No Create button in the global header.** Posting remains in the feed; Story creation remains in the Story rail.
4. **Messages stays a single top-right icon**, matching the communication-first separation.
5. **Requests, Services, Spirals, Media, Diaspora and Profile are secondary destinations behind one menu.**
6. **The main feed narrows to ~700px** so the content reads like a social feed rather than an application dashboard.
7. **No backend/API/data-model changes.**
8. **No removal of Niakofa-specific capabilities.** They are moved behind progressive disclosure instead of competing with Feed/Stories.

## Why this is closer to the target

The uploaded Facebook-style reference is organized around a quiet app header, icon-first social navigation, Stories, a lightweight composer, and a chronological feed. Niakofa now follows that interaction hierarchy while retaining Niakofa-specific Community, Hub, Request, Spiral, Diaspora and messaging systems.

## Apply

```bash
git apply community-facebook-social-v2.patch
```

The patch is limited to the Community shell. It does not modify authentication, Hub membership, feed APIs, Story APIs, Messages, Nia, Railway configuration, or database migrations.

## Acceptance checklist

- [ ] Community opens directly into Feed.
- [ ] Five icon destinations are the only primary Community navigation.
- [ ] Profile/Requests/Services/Spirals/Media/Diaspora are reachable from one menu.
- [ ] Messages is reachable from one header icon.
- [ ] `What's on your mind?` remains in the feed.
- [ ] Stories remain immediately above the feed.
- [ ] Existing Community routes continue to resolve.
- [ ] No duplicate global Community tab bar appears.
- [ ] No Niakofa backend system is removed.
